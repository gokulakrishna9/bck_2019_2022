exports.mvcPage = function (paramObject) {
  return [
    // all filters here
    // column filter
    // table filter, have a nest attribute and set it to true
    // scope {db, entity, page, ..., filter_name}, scope can be any array, nest under filter name
    {
      entity: { entity_name: 'a_column', entity_label: 'data_point' },
      action_object: paramObject, action: 'fieldObj', db: true
    },
    {
      entity: { entity_label: 'entity', entity_name: 'table' },
      scope: 'a_column', action_object: paramObject, action: 'uniqueTable', db: true
    },
    /*
    {
      entity: { entity_name: 'a_primary_column', entity_label: 'data_point' },
      entity_filter: { entity_name: 'a_column', primary_column: true }, db: false
    },
    {
      entity: { entity_name: 'a_int_column', entity_label: 'data_point', },
      entity_filter: { entity_name: 'a_column', column_type: 'int' }, db: false
    },
    {
      entity: { entity_name: 'a_label_column', entity_label: 'data_point', },
      entity_filter: { entity_name: 'a_column', label_column: true }, db: false
    },
    {
      entity: { entity_name: 'a_date_column', entity_label: 'data_point', },
      entity_filter: { entity_name: 'a_column', column_type: 'date' }, db: false
    }, */
    // GET ENTITY NAME INTO PROPERTY
    {
      entity: { entity_name: 'column', entity_label: 'ref_data_point', object_type: 'ref_object' },
      entity_filter: { entity_name: 'a_column' },
      chunk: { entity_name: 'table', chunk_on: 'table_name', chunk_type: 'parent' }, db: true
    },
    {
      entity: { entity_name: 'int_column', entity_label: 'ref_data_point', object_type: 'ref_object' },
      entity_filter: { entity_name: 'a_column', column_type: 'int' },
      chunk: { entity_name: 'table', chunk_on: 'table_name', chunk_type: 'parent' }, db: true
    },
    {
      entity: { entity_name: 'label_column', entity_label: 'ref_data_point', object_type: 'ref_object' },
      entity_filter: { entity_name: 'a_column', label_column: true },
      chunk: { entity_name: 'table', chunk_on: 'table_name', chunk_type: 'parent' }, db: true
    },
    {
      entity: { entity_name: 'date_column', entity_label: 'ref_data_point', object_type: 'ref_object' },
      entity_filter: { entity_name: 'a_column', column_type: 'date' }, chunk: { entity_name: 'table', chunk_on: 'table_name', chunk_type: 'parent' }, db: true
    },
    {
      entity: { entity_name: 'primary_column', entity_label: 'ref_data_point' },
      entity_filter: { entity_name: 'a_column', primary_column: true }, chunk: { entity_name: 'table', chunk_on: 'table_name', chunk_type: 'parent' }, db: true
    },
    {
      entity: { entity_name: 'derived_relation', entity_label: 'relation' },
      entity_filter: { entity_one: 'primary_column', entity_two: 'int_column', property_one: 'column_name', property_two: 'column_name' },
      chunk: { entity_name: 'table', chunk_type: 'parent' },
      property: [
        { entity_name: 'primary_column', property_list: [{ property_on: 'parent', property_name: 'table_name' }, 'column_name'] },
        { entity_name: 'int_column', property_list: [{ property_on: 'parent', property_name: 'table_name' }, 'column_name', { property_on: 'sibling', property_name: 'label_column', property_value: 'true' }] }
      ]
    },
    {
      entity: { entity_name: 'master_relation', entity_label: 'relation' },
      entity_filter: { entity_one: 'int_column', entity_two: 'primary_column', property_one: 'column_name', property_two: 'column_name' },
      chunk: { entity_name: 'table', chunk_type: 'parent' },
      property: [
        { entity_name: 'primary_column', property_list: [{ property_on: 'parent', property_name: 'table_name' }, 'column_name'] },
        { entity_name: 'int_column', property_list: [{ property_on: 'parent', property_name: 'table_name' }, 'column_name', { property_on: 'sibling', property_name: 'label_column', property_value: 'true' }] }
      ]
    },
  ];
}