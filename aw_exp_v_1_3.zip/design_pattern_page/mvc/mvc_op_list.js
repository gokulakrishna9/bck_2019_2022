exports.mvcOpList = function () {
  let entityNL = {
    table: 'table', column: 'column', relation: 'relation', database: 'database', application: 'application',
    operator: 'operator', template: 'template', template_name: 'template_name', variable_name: 'variable_name', method_name: 'method_name'
  }
  let property_on = { parent: 'parent', self: 'self' };
  let propertyNL = {
    entity_name: 'entity_name', table_name: 'table_name', column_type: 'column_type', column_size: 'column_size',
    column_key: 'column_key', column_label: 'column_label', label_column: 'label_column',
    column_name: 'column_name', column_comment: 'column_comment',
    one_table: 'one_table', one_column: 'one_column', two_table: 'two_table', two_column: 'two_column',
    property: 'property', string: 'string', integer: 'integer', reference: 'reference', double_reference: 'double_reference'
  };
  let component_name_obj = {
    find_entity_table: 'find_entity_table', input_field: 'input_field', declare_array: 'declare_array',
    insert_query: 'insert_query', return_result: 'return_result', default_add_m: 'default_add_m',
    primary_key_input_filter: 'primary_key_input_filter',
    update_query: 'update_query', default_update_m: 'default_update_m',
    where_input_filter: 'where_input_filter', default_delete_m: 'default_delete_m', delete_query: 'delete_query',
    having_input_filter: 'having_input_filter', grouping_input_filter: 'grouping_input_filter',
    order_by_filter: 'order_by_filter', write_select: 'write_select', write_join: 'write_join',
    write_where: 'write_where', write_having: 'write_having', write_grouping: 'write_grouping',
    write_order_by: 'write_order_by', default_query_m: 'default_query_m', model: 'model',
    authenticate_user: 'authenticate_user', authorize_user: 'authorize_user', remap: 'remap',
    controller_remap: 'controller_remap', load_model: 'load_model', add_record: 'add_record', valid: 'valid', invalid: 'invalid',
    set_error_message: 'set_error_message', validate_input: 'validate_input', load_form_data: 'load_form_data',
    load_filter_data: 'load_filter_data', load_table_data: 'load_table_data', load_add_view: 'load_add_view',
    default_add: 'default_add', update_record: 'update_record', validate_primary_key_input: 'validate_primary_key_input',
    load_update_view: 'load_update_view', default_update: 'default_update', delete_record: 'delete_record',
    load_delete_view: 'load_delete_view', default_delete: 'default_delete', filter_table_data: 'filter_table_data',
    validate_filter: 'validate_filter', load_query_view: 'load_query_view', default_query: 'default_query', controller: 'controller',
    header: 'header', leftnav: 'leftnav', alert_info: 'alert_info', form: 'form', form_grid: 'form_grid',
    default_filter: 'default_filter', form_grid: 'form_grid', default_pagination: 'default_pagination',
    default_table: 'default_table', tab: 'tab', default_having: 'default_having', form_grid: 'form_grid',
    default_grouping: 'default_grouping', form_grid: 'form_grid', default_order_by: 'default_order_by',
    default_pagination: 'default_pagination', default_summary_table: 'default_summary_table', tab: 'tab',
    tab_group: 'tab_group', content_grid: 'content_grid', page_grid: 'page_grid', view: 'view'
  };
  let execution_seq_obj = {
    model_start: 'model_start', model: 'model', model_end: 'model_end',
    controller_start: 'controller_start', controller: 'controller', controller_end: 'controller_end',
    view_start: 'view_start', view: 'view', view_end: 'view_end',
    controller_view: 'controller_view', final_code: 'final_code'
  };
  let op_object = {
    page_property: [
      {
        action_name: 'db_entity_list',
        action: ['dbObj']
      }
    ],
    page_relation: [
      {
        execution_label: '',
        filter_group_name: '',
        filter_type: 'nested',
        filter: [
          { filter: { entity_label: 'column', column_type: 'int' }, filter_name: 'all_column', filter_scope: 'entity' },
          { reject_object: { entity_label: 'column', primary_column: true }, filter_name: 'integer_column', filter_scope: 'all_column' },
          { filter: { entity_label: 'column', column_name: 'integer_column.column_name', primary_column: true, db: 'integer_column.db' }, filter_name: 'master_primary_column', filter_scope: 'pipeline' },
          { filter: { entity_label: 'table', entity_id: 'master_primary_column.containing_entity_id' }, filter_name: 'master_table', filter_scope: 'pipeline' },
          { filter: { entity_label: 'column', containing_entity_id: 'master_table.entity_id', label_column: true }, filter_name: 'select_column', filter_scope: 'pipeline' }
        ],
        object: [{
          entity: { entity_label: 'master_relation', entity_name: ['entity.table_name', 'master_table.table_name'] },
          property: [
            { property_label: 'property', property_name: 'one_table', property_value: 'entity.table_name' },
            { property_label: 'property', property_name: 'one_column', property_value: 'primary_column.column_name' },
            { property_label: 'property', property_name: 'two_table', property_value: 'master_table.table_name' },
            { property_label: 'property', property_name: 'two_column', property_value: 'master_primary_column.column_name' },
            { property_label: 'property', property_name: 'select_column', property_value: 'select_column.column_name' },
          ]
        }]
      }
    ],
    [component_name_obj.find_entity_table]: [     // NOT REQUIRED

      {
        ce_property_name: 'entity_name',
        ce_property_ref: 'table_name',
        property_on: 'parent'
      },
      {
        ce_property_name: 'model_name',
        ce_property_ref: 'table_name',
        property_on: 'parent'
      }

    ],
    [component_name_obj.input_field]: [
      {
        execution_label: '',
        filter_group_name: '',
        filter_type: '',
        filter: [
          { filter: { entity_label: 'column' }, filter_name: 'column_list', filter_scope: 'entity' },
          { reject_object: {}, filter_name: 'primary_column', filter_scope: 'nest' }
        ],
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'input' },
            property: [
              { property_label: 'property', property_name: 'column_list.column_name' },
              {
                property_on: property_on.parent, property_label: 'property',
                property_name: ce_property_name.variable_name, property_value: 'input_array'
              }
            ]
          }
        ],
        property: [],
        action: []
      }
    ],    // correct
    [component_name_obj.declare_array]: [
      {
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'array_declaration' },
            property: [
              {
                property_label: 'property', property_name: ce_property_name.template_name,
                property_type: 'string', property_value: 'array_declaration'
              }
            ]
          }
        ]
      },
    ],
    [component_name_obj.insert_query]: [
      {
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'insert_query' },
            property: [
              { property_name: ce_property_name.template_name, property_value: 'insert_record_query' },
              { property_name: 'query_result_variable', property_value: 'query_result' },
              { property_name: 'input_array', property_value: '' },
            ]
          }
        ]
      }
    ],
    [component_name_obj.return_result]: [
      {
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'return_result' },
            property: [
              { property_name: ce_property_name.template_name, property_value: 'return_result' },
              { property_name: 'input_array', property_value: '' },
              { property_name: 'query_result' }
            ]
          }
        ]
      },
    ],
    [component_name_obj.default_add_m]: [
      {
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'model_method' },
            property: [
              { property_name: ce_property_name.template_name, property_value: 'model_method' },
              { property_name: 'method_name', property_value: 'add_record' }
            ]
          }
        ]
      }
    ],
    [component_name_obj.primary_key_input_filter]: [
      {
        execution_label: '',
        filter_group_name: '',
        filter_type: '',
        filter: [
          { filter: {}, filter_name: 'primary_column', filter_scope: '' },
        ],
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'primary_key_input_filter' },
            property: [
              { property_label: 'property', property_name: ce_property_name.template_name, property_value: 'input' },
              { property_label: 'property', property_name: 'primary_column.column_name' }
            ]
          }
        ]
      }
    ],  // correct
    [component_name_obj.update_query]: [
      {
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'update_query' },
            property: [
              { property_name: ce_property_name.template_name, property_value: 'update_query' },
              { property_name: 'input_array' },
              { property_name: 'primary_column.column_name' }
            ]
          }
        ]
      }
    ],  // correct
    [component_name_obj.default_update_m]: [
      {
        object: [
          {
            entity: { entity_label: 'code_component', entity_name: 'model_method' },
            property: [
              { property_name: ce_property_value.template_name, property_value: 'model_method' },
              { property_name: 'method_name', property_value: 'update_record' }
            ]
          }
        ]
      }
    ],  // correct
    [component_name_obj.default_delete_m]: {
      entity: { entity_label: 'code_component', entity_name: 'model_method' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'model_method' },
        { property_name: 'method_name', property_value: 'delete_record' }
      ]
    },
    [component_name_obj.delete_query]: {
      entity: { entity_label: 'code_component', entity_name: 'delete_query' },
      property: [
        {
          property_name: ce_property_name.template_name,
          property_value: 'delete_query'
        },
        {
          property_name: 'column_name', property_value: 'primary_column.column_name'
        }
      ]
    },    // correct
    [component_name_obj.where_input_filter]: {
      execution_label: '',
      filter_group_name: '',
      filter_type: '',
      filter: [
        { filter: { entity_label: 'column', property_name: 'label', property_value: 'true' }, filter_name: 'label_filter_input', filter_scope: '' },
        { filter: { entity_label: 'relation', property_name: 'one_column' }, filter_name: 'master_column', filter_scope: '' },
      ],
      object: {
        entity: { entity_label: 'code_component', entity_name: 'where_input_filter' },
        property: [
          { property_name: ce_property_name.template_name, property_value: 'where_input_filter' },
          { property_name: 'column_name', property_value: 'label_filter_input.column_name' },
          { property_name: 'column_name', property_value: 'master_column.column_name' },
          { property_name: 'column_name', property_value: 'primary_column.column_name' },
          {
            property_on: property_on.parent, property_name: ce_property_name.variable_name,
            property_value: 'where_input', execution_label: execution_seq_obj.model_end
          }
        ]
      },
      action: []
    },
    // correct
    [component_name_obj.having_input_filter]: {
      entity: { entity_label: 'code_component', entity_name: 'having_input_filter' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'having_input_filter' },
        { property_name: 'column_name', property_value: 'label_filter_input.column_name' },
        { property_name: 'column_name', property_value: 'master_column.column_name' },
        {
          property_on: property_on.parent, property_name: ce_property_name.variable_name,
          property_value: 'having_input', execution_label: execution_seq_obj.model_end
        }
      ]
    },    // correct
    [component_name_obj.grouping_input_filter]: {
      entity: { entity_label: 'code_component', entity_name: 'grouping_input_filter' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'grouping_input_filter' },
        { property_name: 'column_name', property_value: 'label_filter_input.column_name' },
        { property_name: 'column_name', property_value: 'master_column.column_name' },
        {
          property_on: property_on.parent, property_name: ce_property_name.variable_name,
          property_value: 'grouping_input', execution_label: execution_seq_obj.model_end
        }
      ]
    },    // correct
    [component_name_obj.order_by_filter]: {
      entity: { entity_label: 'code_component', entity_name: 'order_by_input_filter' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'order_by_input_filter' },
        { property_name: 'column_name', property_value: 'label_filter_input.column_name' },
        { property_name: 'column_name', property_value: 'master_column.column_name' },
        {
          property_on: property_on.parent, property_name: ce_property_name.variable_name,
          property_value: 'ordering_input', execution_label: execution_seq_obj.model_end
        }
      ]
    },
    [component_name_obj.write_select]: {
      entity: { entity_label: 'code_component', entity_name: 'select_join' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'select_join' },
        { property_name: 'column_name', property_value: 'label_filter_input.column_name' },
        { property_name: 'column_name', property_value: 'master_column.column_name' },
        { property_name: 'column_name', property_value: 'primary_column.column_name' },
        { property_label: 'entity_ref', property_name: 'order_by_input_filter' },
        { property_label: 'entity_ref', property_name: 'grouping_input_filter' },
        { property_label: 'entity_ref', property_name: 'having_input_filter' },
        { property_label: 'entity_ref', property_name: 'where_input_filter' },
        {
          property_on: property_on.parent, property_name: ce_property_name.variable_name,
          property_value: 'query_result', execution_label: execution_seq_obj.model_end
        }
        // primary key column, master key column
      ]
    },
    [component_name_obj.write_where]: {     // Not required
      execution_label: execution_seq_obj.model,
      property_list: [
        {
          ce_property_name: ce_property_name.template_name,
          ce_property_value: 'where_query'
        },
        {
          filter_name: 'where_filter'
        }
      ]
    },
    [component_name_obj.write_having]: {    // Not required
      execution_label: execution_seq_obj.model,
      property_list: [
        {
          ce_property_name: ce_property_name.template_name,
          ce_property_value: 'having_query'
        },
        {
          filter_name: 'having_filter'
        },
      ]
    },
    [component_name_obj.write_grouping]: {  // Not required
      execution_label: execution_seq_obj.model,
      property_list: [
        {
          ce_property_name: ce_property_name.template_name,
          ce_property_value: 'grouping_query'
        },
        {
          filter_name: 'grouping_filter'
        },
      ]
    },
    [component_name_obj.write_order_by]: {  // Not required
      execution_label: execution_seq_obj.model,
      property_list: [
        {
          ce_property_name: ce_property_name.template_name,
          ce_property_value: 'order_by_query'
        },
        {
          filter_name: 'order_by_filter'
        }
      ]
    },
    [component_name_obj.default_query_m]: { // Not required
      execution_label: execution_seq_obj.model_end,
      property_list: [
        {
          ce_property_name: ce_property_name.template_name,
          ce_property_value: 'model_method'
        },
        {
          ce_property_name: 'method_name',
          ce_property_value: 'query_record'
        }
      ]
    },
    [component_name_obj.model]: {
      entity: { entity_label: 'code_component', entity_name: 'model_class' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'model_class' },
        { property_name: 'model_name', property_value: 'entity.table_name' },
      ],
      execution_label: execution_seq_obj.model_start
    },
    [component_name_obj.authenticate_user]: {
      entity: { entity_label: 'code_component', entity_name: component_name_obj.authenticate_user },
      property: [
        { property_name: ce_property_name.template_name, ce_property_value: 'controller_method' },
        { property_name: 'method_name', property_value: component_name_obj.authenticate_user }
      ]
    },
    [component_name_obj.authorize_user]: {
      entity: { entity_label: 'code_component', entity_name: component_name_obj.authorize_user },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_method' },
        { property_name: 'method_name', property_value: component_name_obj.authenticate_user },
      ]
    },
    [component_name_obj.remap]: {
      entity: {},
      property: []
    },  // Pending
    [component_name_obj.controller_remap]: {
      entity: { entity_label: 'code_component', entity_name: 'controller_remap' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_remap' },
        { property_type: 'entity_ref', property_name: component_name_obj.authorize_user },
        { property_type: 'entity_ref', property_name: component_name_obj.authenticate_user },
      ]
    },      // Correct
    [component_name_obj.load_model]: {
      execution_label: '',
      filter_group_name: '',
      filter_type: '',
      filter: [
        { filter: {}, filter_name: 'master_relation', filter_scope: 'page' },
        { filter: { entity_name: 'model_class', property_name: 'root_entity', property_value: 'master_relation.two_table' }, filter_name: 'master_model_f', filter_scope: 'pipeline' },
        { filter: { entity_name: 'model_method', property_name: 'root_entity', property_value: 'master_relation.two_table' }, filter_name: 'master_model_method_f', filter_scope: 'pipeline' },
        { filter: { entity_name: 'model_class' }, filter_name: 'page_model_f', filter_scope: 'page' },
        { filter: { entity_name: 'model_class' }, filter_name: 'page_model_method_f', filter_scope: 'page' },
      ],
      object: {
        entity: { entity_label: 'code_component', entity_name: 'load_model' },
        property: [
          { property_name: 'master_model', property_value: 'master_model_f.model_name' },
          { property_name: 'page_model', property_value: 'page_model_f.model_name' }
        ]
      }
    },
    [component_name_obj.add_record]: {
      entity: {
        entity_label: 'code_component',
        entity_name: component_name_obj.add_record
      },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'add_record' },
        { property_name: 'method_name', property_value: 'master_model_method_f.method_name->add_record' }
      ]
    },
    [component_name_obj.valid]: {
      entity: { entity_label: 'code_component', entity_name: 'if_condition' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'if_condition' }
      ],
      execution_label: execution_seq_obj.controller,
    },
    [component_name_obj.set_error_message]: {
      entity: { entity_label: 'code_component', entity_name: 'set_input_error' },
      property: [{ property_name: 'column_name', property_value: 'label_filter_input.column_name' }],
      execution_label: execution_seq_obj.controller
    },
    [component_name_obj.invalid]: {
      entity: { entity_label: 'code_component', entity_name: 'else_condition' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'else_condition' }
      ],
      execution_label: execution_seq_obj.controller
    },
    [component_name_obj.validate_input]: {
      entity: { entity_label: 'code_component', entity_name: 'validate_input' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'validate_input' },
        { property_name: 'column_name', property_value: 'label_filter_input.column_name' },
        { property_on: property_on.parent, property_name: ce_property_name.variable_name, property_value: 'validate_input' }
      ],
      execution_label: execution_seq_obj.controller_start
    },
    [component_name_obj.load_form_data]: {
      entity: { entity_label: 'code_component', entity_name: 'form_data' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form_data' },
        // form data method
        {
          property_on: property_on.parent, property_name: ce_property_name.variable_name,
          property_value: 'update_data', execution_label: execution_seq_obj.model_end
        }
      ],
      execution_label: execution_seq_obj.controller
    },
    // Not required its in the model
    [component_name_obj.load_filter_data]: {
      execution_label: execution_seq_obj.controller,
      entity: {},
      property: [],
      property_list: [
        {
          ce_property_name: ce_property_name.template_name,
          ce_property_value: 'filter_data'
        },
        {
          // load filter fields from input
        },
        {
          // declare form data array
        }
      ]
    },
    [component_name_obj.load_table_data]: {
      execution_label: execution_seq_obj.controller,
      entity: { entity_label: 'code_component', entity_name: 'table_data' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'table_data' },
        // all data array
        // filter to get data method
      ]
    },
    [component_name_obj.load_add_view]: {
      execution_label: execution_seq_obj.controller_view,
      entity: { entity_label: 'code_component', entity_name: 'load_view' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'load_view' },
        // view object file name
      ],
    },
    [component_name_obj.default_add]: {
      execution_label: execution_seq_obj.controller_start,
      entity: { entity_label: 'code_component', entity_name: 'controller_method' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_method' },
        { property_name: 'method_name', property_value: 'default_add' }
        // add table name, add prefix property, add suffix property
      ]
    },
    [component_name_obj.update_record]: {
      execution_label: execution_seq_obj.controller_end,
      entity: { entity_label: 'code_component', entity_name: 'update_record' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'update_record' },
        { property_name: '' } // update array, primary key
      ]
    },
    [component_name_obj.validate_primary_key_input]: {
      execution_label: execution_seq_obj.controller_start,
      // change to add to parent
      entity: { entity_label: 'code_component', entity_name: component_name_obj.validate_primary_key_input },
      property: [
        { scope: '', filter: '', filter_property: '', property_name: 'column_name', property_value: 'primary_key_input_filter.column_name' },
        //..
      ]
    },
    [component_name_obj.load_update_view]: {
      execution_label: execution_seq_obj.controller_view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.load_update_view },
      property: [
        { scope: '', filter: '', filter_property: '', property_name: '' }
      ]
      // no need for this either
    },
    [component_name_obj.default_update]: {
      execution_label: execution_seq_obj.controller_start,
      entity: { entity_label: 'code_component', entity_name: 'controller_method' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_method' },
        { property_name: 'method', property_value: component_name_obj.default_update },
      ]
    },
    [component_name_obj.delete_record]: {
      execution_label: execution_seq_obj.controller_start,
      entity: { entity_label: 'code_component', entity_name: 'controller_method' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_method' },
        { property_name: 'method', property_value: component_name_obj.default_update },
      ]
    },
    [component_name_obj.load_delete_view]: {
      // not required
      execution_label: execution_seq_obj.controller_view,
      entity: { entity_label: 'code_component', entity_name: 'controller_method' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'load_view' },
        // view file name
      ]
    },
    [component_name_obj.default_delete]: {
      execution_label: execution_seq_obj.controller_start,
      entity: { entity_label: 'code_component', entity_name: 'controller_method' },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_method' },
        { property_name: 'method', property_value: component_name_obj.default_delete },
      ]
    },
    [component_name_obj.filter_table_data]: {
      execution_label: execution_seq_obj.controller,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.filter_table_data },
      property: [
        {
          property_name: ce_property_name.template_name,
          property_value: 'validate_input'
        }
      ]
    },
    [component_name_obj.validate_filter]: {
      execution_label: execution_seq_obj.controller_start,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.validate_filter },
      property: [
        {
          property_name: ce_property_name.template_name, property_value: 'validate_input'
        },
        {
          filter_name: 'label_filter_input'
        },
        {
          property_on: property_on.parent, property_name: ce_property_name.variable_name,
          property_value: 'label_filter'
        }
      ]
    },
    // not required use default
    [component_name_obj.load_query_view]: {
      execution_label: execution_seq_obj.controller_view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.load_query_view },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'query_view' },
        // file name
      ]
    },
    [component_name_obj.default_query]: {
      execution_label: execution_seq_obj.controller_end,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_query },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_method' },
        { property_name: ce_property_name.method_name, property_value: 'query_record' }
      ]
    },
    [component_name_obj.controller]: {
      execution_label: execution_seq_obj.controller_start,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.controller },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'controller_class' },
        { property_name: 'controller_name', property_value: alias_name.controller_name }
      ]
    },
    [component_name_obj.header]: {
      execution_label: execution_seq_obj.user_execute
    },
    [component_name_obj.leftnav]: {
      execution_label: execution_seq_obj.user_execute
    },
    [component_name_obj.alert_info]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.alert_info },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'alert_info' },
        { property_name: 'return_object' } // filter on label
      ]
    },
    [component_name_obj.form]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.form },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form' },
        { property_name: 'form_action' },
        { filter_name: 'input_fields' },
        { filter_name: 'primary_key_field' }
      ]
    },
    [component_name_obj.form_grid]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.form_grid },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form_grid' },
        { property_name: component_name_obj.form }
      ]
    },
    [component_name_obj.default_filter]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_filter },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form' },
        { filter_name: 'label_filter' }
      ]
    },
    [component_name_obj.default_pagination]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_pagination },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'pagination' },
        { filter_name: 'default_query_action' }
      ]
    },
    [component_name_obj.default_table]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_table },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'default_table' },
        { property_name: 'table_name', property_value: 'entity_name' }
      ]
    },
    [component_name_obj.tab]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.tab },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'tab' },
        ///
      ]
    },
    [component_name_obj.default_having]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_having },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form' },
        { filter_name: 'label_filter' }
      ]
    },
    [component_name_obj.default_grouping]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_grouping },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form' },
        { filter_name: 'label_filter' }
      ]
    },
    [component_name_obj.default_order_by]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_order_by },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'form' },
        { filter_name: 'label_filter' }
      ]
    },
    [component_name_obj.default_summary_table]: {
      // not required
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.default_summary_table },
      property: [
        //
      ]
    },
    [component_name_obj.tab_group]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.tab_group },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'tab_group' }
      ]
    },
    [component_name_obj.content_grid]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.content_grid },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'content_grid' }
      ]
    },
    [component_name_obj.page_grid]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.page_grid },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'page_grid' }
      ]
    },
    [component_name_obj.view]: {
      execution_label: execution_seq_obj.view,
      entity: { entity_label: 'code_component', entity_name: component_name_obj.view },
      property: [
        { property_name: ce_property_name.template_name, property_value: 'view' }
      ]
    }
  }
  let component_execution_sequence_label = ['scaffold_op', 'entity_op'];
  let componentList = [
    {
      group_execution_label: 'entity_op',
      page_entity_label: 'table',
      op_execution_sequence_label: [
        execution_seq_obj.model_start, execution_seq_obj.model, execution_seq_obj.model_end,
        execution_seq_obj.controller_start, execution_seq_obj.controller, execution_seq_obj.controller_end,
        execution_seq_obj.view_start, execution_seq_obj.view, execution_seq_obj.view_end,
        execution_seq_obj.controller_view, execution_seq_obj.final_code
      ],
      component_list: [
        [
          [
            [[component_name_obj.find_entity_table, [component_name_obj.input_field], component_name_obj.declare_array, component_name_obj.insert_query, component_name_obj.return_result], component_name_obj.default_add_m],
            [[component_name_obj.find_entity_table, [component_name_obj.input_field], component_name_obj.declare_array, [component_name_obj.primary_key_input_filter], component_name_obj.declare_array, component_name_obj.update_query, component_name_obj.return_result], component_name_obj.default_update_m],
            [[component_name_obj.find_entity_table, [component_name_obj.primary_key_input_filter], component_name_obj.declare_array, component_name_obj.update_query, component_name_obj.return_result], component_name_obj.default_delete_m],
            [[component_name_obj.find_entity_table, [component_name_obj.where_input_filter], component_name_obj.declare_array, [component_name_obj.having_input_filter], component_name_obj.declare_array, [component_name_obj.grouping_input_filter], component_name_obj.declare_array, [component_name_obj.order_by_filter], component_name_obj.declare_array, component_name_obj.write_select, component_name_obj.write_join, component_name_obj.write_where, component_name_obj.write_having, component_name_obj.write_grouping, component_name_obj.write_order_by, component_name_obj.return_result], component_name_obj.default_query_m]
          ],
          component_name_obj.model
        ],
        [
          [component_name_obj.authenticate_user, component_name_obj.authorize_user, component_name_obj.remap], component_name_obj.controller_remap,
          [[component_name_obj.load_model, [[component_name_obj.add_record], component_name_obj.valid, [component_name_obj.set_error_message], component_name_obj.invalid], component_name_obj.validate_input, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_table_data, component_name_obj.load_add_view], component_name_obj.default_add],
          [[component_name_obj.load_model, [[component_name_obj.update_record], component_name_obj.valid, [component_name_obj.set_error_message], component_name_obj.invalid], component_name_obj.validate_primary_key_input, [component_name_obj.valid, component_name_obj.invalid], component_name_obj.validate_input, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_table_data, component_name_obj.load_update_view], component_name_obj.default_update],
          [[component_name_obj.load_model, [[component_name_obj.delete_record], component_name_obj.valid, [component_name_obj.set_error_message], component_name_obj.invalid], component_name_obj.validate_primary_key_input, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_table_data, component_name_obj.load_delete_view], component_name_obj.default_delete],
          [[component_name_obj.load_model, [[component_name_obj.filter_table_data], component_name_obj.valid, [component_name_obj.set_error_message, component_name_obj.load_table_data], component_name_obj.invalid], component_name_obj.validate_filter, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_query_view], component_name_obj.default_query],
          component_name_obj.controller
        ],
        [[component_name_obj.header, component_name_obj.leftnav, [
          component_name_obj.alert_info,
          [[component_name_obj.form], component_name_obj.form_grid],
          [
            [
              [[[[component_name_obj.default_filter], component_name_obj.form_grid], [component_name_obj.default_pagination, component_name_obj.default_table]], component_name_obj.tab]
              [
              [[component_name_obj.default_having], component_name_obj.form_grid],
              [[component_name_obj.default_grouping], component_name_obj.form_grid],
              [[component_name_obj.default_order_by], component_name_obj.form_grid],
              [component_name_obj.default_pagination, component_name_obj.default_summary_table], component_name_obj.tab
              ]
            ],
            component_name_obj.tab_group
          ],
          component_name_obj.content_grid
        ],
        component_name_obj.page_grid], component_name_obj.view]
      ]
    },
    {
      group_execution_label: 'add_on_op',
      group_execution_sequence_label_list: [
        execution_seq_obj.model_start, execution_seq_obj.model, execution_seq_obj.model_end,
        execution_seq_obj.controller_start, execution_seq_obj.controller, execution_seq_obj.controller_end,
        execution_seq_obj.view_start, execution_seq_obj.view, execution_seq_obj.view_end,
        execution_seq_obj.controller_view, execution_seq_obj.final_code
      ],
      scope_entity_filter: {},
      component_list: [
        [[authenticate_user, authorize_user], login_model],
        [[login_authenticate_user, login_authorize_user], login_controller],
        [[[login_form], login_page_grid], login_view]
      ]
    }
  ];
  // get filter with page_entity, let entity be a property
  async.concat(componentList, (com) => {
    let entityList = '';      // call filter
    async.concat(entityList, (ent, opLClb) => {
      //dpOEN
    }, (err, compL) => {

    });
  }, (err, allOpL) => {

  });
}