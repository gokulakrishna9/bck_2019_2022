let { dbEntityLabel, codeEntityLabel, propertyLabel, propertyType, dbPropertyName, Entity, Property } = require('../../aw_main/entity_op');

exports.mvcPage = function (paramObject) {
  return {
    filter_default: {
      execution_label: '',
      filter_group_name: '',
      filter_type: '',
      property_filter: [
        { property_filter: {}, filter_name: '', filter_scope: '' }
      ],
      object: [{ parent: [''], child: ['filter_name.property_name'] }],
      property: ['filter_name.property_name as '],
      action: []
    },
    filter_list: [      /// NEVER GOTO PROPERTY VALUE, ONLY PROPERTY DATA
      // all filters here
      // column filter
      // table filter, have a nest attribute and set it to true
      // scope {db, entity, page, ..., filter_name}, scope can be any array, nest under filter name
      { head_label: '', scope: '', property_filter: {}, entity_name: 'db_column', entity_label: 'db_column', action_parameter: paramObject, action: 'getDBSchema', db: false },
      { head_label: '', scope: 'db_column', property_filter: {}, entity_name: 'a_column', entity_label: 'data_point', action: 'fieldObj', db: true }, // column
      { head_label: '', scope: 'all_column', property_filter: { property_name: 'primary_column', property_value: 'true' }, entity_name: 'column_name', entity_label: 'p_column', action: '', db: false },
      { head_label: '', filter_name: 'all_int_column', scope: 'all_column', property_filter: { property_name: 'column_type', property_value: 'int' }, entity_name: 'column_name', entity_label: 'i_column', action: '', db: false },
      { head_label: '', filter_name: 'entity', scope: 'all_column', property_filter: {}, entity_name: 'table', entity_label: 'entity', action: 'uniqueTable' }, // table
      { head_label: 'entity', property_filter: {}, scope: 'all_column', filter_name: 'entity_column', entity_name: 'column_name', entity_label: 'data_point', action: '' }, // only filter, it's a nest on column
      // integer
      { head_label: 'entity', filter_name: 'int_column', scope: 'entity_column', property_filter: { property_name: 'column_type', property_value: 'int' }, entity_name: '', entity_label: '', action: '' },
      // label
      { head_label: 'entity', filter_name: 'label_column', scope: 'entity_column', property_filter: { property_name: 'label_column', property_value: true }, entity_name: '', entity_label: '', action: '' },
      // date column
      { head_label: 'entity', filter_name: 'date_column', scope: 'entity_column', property_filter: { property_name: 'column_type', property_value: 'date' }, entity_name: '', entity_label: '', action: '' },
      // primary
      { head_label: 'entity', filter_name: 'primary_column', scope: 'entity_column', property_filter: { property_name: 'primary_column', property_value: true }, entity_name: '', entity_label: '', action: '' },

      { head_label: 'entity', filter_name: 'derived_same_name_column', scope: 'all_int_column', property_filter: { property_name: 'column_name', property_value: 'primary_column.property_name.column_name' }, entity_name: '', entity_label: '', action: '', db: false }, // only filter, it's a nest on column
      { head_label: 'entity', property_on: '', filter_name: 'derived_column', scope: 'derived_same_name_column', property_filter: { property_name: 'column_type', property_value: 'int' }, entity_name: '', entity_label: '', action: '' },
      // only filter, it's a nest on column
      { head_label: 'entity', filter_name: 'derived_label_column', scope: 'all_column', property_filter: { containing_entity_id: 'derived_column.containing_entity_id', entity_label: 'column', property_name: 'label_column', property_value: true }, entity_name: '', entity_label: '', action: '' },  // goto parent
      { head_label: 'entity', filter_name: 'derived_table', scope: 'entity', property_filter: { entity_id: 'derived_column.containing_entity_id', entity_label: 'table' }, entity_name: '', entity_label: '', action: '' }, // only filter, it's a nest on column

      { head_label: 'entity', filter_name: 'master_same_name_column', scope: 'all_primary_column', property_filter: { property_name: 'column_name', property_value: 'int_column.property_name.column_name' }, entity_name: '', entity_label: '', action: '', db: false }, // only filter, it's a nest on column
      { head_label: 'entity', filter_name: 'master_column', scope: 'master_same_name_column', property_filter: { property_name: 'primary_column', property_value: true}, entity_name: '', entity_label: '', action: '' }, // only filter, it's a nest on column      
      { head_label: 'entity', filter_name: 'master_label_column', scope: 'all_column', property_filter: { containing_entity_id: 'master_column.containing_entity_id', entity_label: 'column', property_name: 'label_column', property_value: true }, entity_name: '', entity_label: '', action: '' }, // only filter, it's a nest on column
      { head_label: 'entity', filter_name: 'master_table', scope: 'entity', property_filter: { entity_id: 'master_column.containing_entity_id', entity_label: 'table' }, entity_name: '', entity_label: '', action: '' }, // only filter, it's a nest on column

      { head_label: 'entity', property_filter: {}, filter_name: 'op_list', scope: '', entity_name: '', entity_label: '', action: 'writeEntityOp' }, // op_list
      
      { head_label: '', property_filter: {}, filter_name: 'sorted_op_list', scope: '', entity_name: '', entity_label: '', action: 'sortEntityOp', db: false }, // op_list
      // op filters by entity
      { head_label: 'op_list', property_filter: {}, filter_name: 'write_op_property', scope: '', entity_name: '', entity_label: '', action: 'writeOpProperty' }, // op_list
      // use scope, page, pipeline
    ] 
  }
}
