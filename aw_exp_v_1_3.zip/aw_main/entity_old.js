let _ = require('lodash');

class Entity {
  constructor(entity_label, entity_name, application_id = 0, containing_entity_id = 0, propertyL, entity_id = 0) {
    this.unique_entity_id = 0;
    this.entity_label = entity_label;
    this.entity_name = entity_name;
    this.application_id = application_id;
    this.containing_entity_id = containing_entity_id;
    this.entity_id = entity_id;
    this.propertyL = _.map(propertyL, (prp) => { prp.property_entity_id = this.unique_entity_id; return prp; });
  }

  setAttribute(attrObj) {
    let keyL = Object.keys(attrObj);
    _.forEach(keyL, (key) => {
      this[key] = attrObj[key];
    });
  }

  getEntity() {
    return {
      application_id: this.application_id, unique_entity_id: this.unique_entity_id,
      containing_entity_id: this.containing_entity_id, entity_label: this.entity_label, entity_name: this.entity_name
    };
  }

  getEntityProperty() {
    return _.map(this.propertyL, (prp) => {return prp.getProperty();});
  }

  getEntityString() {
    return '("' + this.application_id + '", "' + this.containing_entity_id + '", "' + this.entity_label + '", "' + this.entity_name + '")';
  }
}

class Property {
  constructor(property_entity_id, property_label, property_name, property_type, property_value, property_id = 0) {
    this.unique_property_id = 0;
    this.property_entity_id = property_entity_id;
    this.property_label = property_label;
    this.property_name = property_name;
    this.property_type = property_type;
    this.property_value = property_value;
    this.property_id = property_id;
  }

  setAttribute(attrObj) {
    let keyL = Object.keys(attrObj);
    _.forEach(keyL, (key) => {
      this[key] = attrObj[key];
    });
  }

  getEntityProperty() {
    return {
      property_entity_id: this.property_entity_id, property_label: this.property_label,
      property_name: this.property_name, property_type: this.property_type, property_value: this.property_value,
      unique_property_id: this.unique_property_id
    };
  }

  getEntityPropertyString() {
    return '("' + this.property_entity_id + '", "' + this.property_label + '", "' + this.property_name + '", "' + this.property_type + '", "' + this.property_value + '")';
  }
}

function entityTree(entityTO, etClb) {
  if(!Array.isArray(entityTO)) {
    etClb(null, entityTO);
    return;
  }
  async.concat(entityTO, (ent, apClb) => {
    if (ent.hasOwnProperty('child') && !_.isEmpty(ent.child)) {
      async.concat(ent.child, (ch, chClb) => {        
        if(ch.hasOwnProperty('child') && !_.isEmpty(ch.child)) {
          ch.entity.containing_entity_id = ent.unique_entity_id;
          entityTree(ch, (err, entL) => {chClb(null, entL)});
        } else {
          ch.containing_entity_id = ent.unique_entity_id;
          chClb(null, ch);
        }
      }, (err, childL) => {
        apClb(null, childL)
      });
    } else {
      apClb(null, ent);
    }
  }, (err, entL) => {
    etClb(err, _.flattenDeep(entL));
    return;
  });
}

function objectToPropertyL(pObj) {
  let objK = Object.keys(pObj);
  objK = _.filter(objK, (oky) => { return pObj.hasOwnProperty(oky) })
  return _.map(objK, (key) => {
    return new EntityProperty(0, 'property', key, 'string', pObj[key]);
  });
}

exports.objectToPropertyL = objectToPropertyL;
exports.entityTree = entityTree;
exports.Entity = Entity;
exports.Property = Property;