exports.action_list = {  
  fieldObj: {
    file_name: '../aw_main/application_object.js'
  },
  mvcPage: {
    file_name: '../design_pattern_page/mvc/mvc_page.js',
  },
  uniqueTable: {
    file_name: '../aw_main/application_object.js'
  }
} 