let _ = require('lodash');
let async = require('async');
const { action_list } = require('./action_route');
let { addEntTree, entityProperty } = require('./entity_op');
let { isObjectEmpty } = require('../helper_op/object');
class Query {
  static dataPoint = [];
  static applicationEntity = {};
  static localScope = [];
}

function setApplicationEntity(applicationName) {
  Query.applicationEntity = entityProperty({ entity: { entity_name: applicationName, entity_label: 'application' }, property: [] })[0];
}

function applyFilter(filter, fnlClb) {
  if (filter.hasOwnProperty('action')) {
    // step 0
    actionFilter(filter, fnlClb);
  } else {
    // step 1
    entityFilter(filter, fnlClb);
  }
}

function actionFilter(filter, fnlClb) {
  let scope = [];
  if (filter.hasOwnProperty('scope') && filter.scope !== '') {
    scope = _.filter(Query.dataPoint, { entity_name: filter.scope });
    scope = _.map(scope, (sc) => { return [sc, ..._.filter(Query.dataPoint, { property_entity_id: sc.entity_id })] });
  }

  require(action_list[filter.action].file_name)[filter.action](filter, scope, Query.applicationEntity, (err, actionRslt) => {
    // map action result to entity
    Query.dataPoint.push(...actionRslt);
    fnlClb(err, actionRslt);
  });
}

function entityFilter(filter, fnlClb) {
  if (_.isEmpty(filter.entity_filter))
    return;
  // async for each chunk, chunk determines properties picked, 
  // applied on entity, only if specified, assume uniqueness of query
  // EMPTY CHUNK FILTERS
  let fentityL = entityChunk(filter);
  if (!_.isEmpty(fentityL)) {
    async.concat(fentityL, (fe, feClb) => {
      if (filter.entity_filter.hasOwnProperty('entity_one')) {
        let filterEL = frmwJoinFilter(filter.entity_filter, fe.chunk_filter);
        feClb(null, { ...fe, filter_element_list: filterEL });
      } else {
        let filterEL = frmwEntityFilter({ ...filter.entity_filter, ...fe.chunk_filter });
        feClb(null, { ...fe, filter_element_list: filterEL });
      }
    }, (err, filterEntityL) => {
      // call propertyList
      // put this in another async, for properties
      propertyFilterList(filterEntityL, filter);
      fnlClb(null, null);
    });
  } else {
    // apply filter
    // filter_entity
    console.log('Empty Chunk');
    if (filter.entity_filter.hasOwnProperty('entity_one')) {
      let filterEL = frmwJoinFilter(filter.entity_filter, {});      
      async.concat(filterEL, (fe, feClb) => {
        let newE = entityProperty({ entity: filter.entity, property: [] }, Query.applicationEntity);
        console.log('Entity Property List');
        console.log(newE);
        feClb(null, { filter_entity: newE, filter_element_list: [fe] });
      }, (err, filterEntityL) => {
        fnlClb(null, null);
      });
    } else {
      let filterEL = frmwEntityFilter(filter.entity_filter);
      // asyn on each filter element
      async.concat(filterEL, (fe, feClb) => {
        console.log('Entity Property List');
        console.log(newE);
        let newE = entityProperty({ entity: filter.entity, property: [] }, Query.applicationEntity);
        feClb(null, { filter_entity: newE, filter_element_list: [fe] });
      }, (err, filterEntityL) => {
        // call propertyList
        // put this in another async, for properties
        //propertyFilterList(filterEntityL, filter);
        fnlClb(null, null);
      });
    }
  }
  // FILTER ELEMENT ELEMENT LIST
  // for each object property get matching objects, using match_property_name{to avoid confusion}
  // find all string properties
  // build filter list
}

// filter entity, filter entity property, find property
function propertyFilterList(filterObjectL, filter) {
  // check for entity type in filter
  // for each filterobjectl get property create property and add to scope
  //console.log('Filter Object List{chunk_filter, filter_entity:, filter_element_list}');
  _.forEach(filterObjectL, (fo) => {
    //console.log('Filter Element List');
    //console.log(fo.filter_element_list);
    _.forEach(filter.property, (prF) => {
      _.forEach(fo.filter_element_list, (fe) => {
        let propertyL = filterEntityProperty(fe, prF);
        _.forEach(fo.filter_entity, (ent) => {
          _.forEach(propertyL, (prp) => {
            Query.dataPoint.push(entityProperty({...prp, property_entity_id: ent.entity_id}, Query.applicationEntity));
          });          
        });
        console.log('Property List');
        console.log(propertyL);
      });
    });
  });
  // console.log('Filter Object List');
  // _.forEach(filterObjectL, (fo) => {
  //   console.log(fo.filter_element_list);
  // });
  // filterEntity, filterEntityProperty  
  /*
  if (filter.hasOwnProperty('property_list') && !_.isEmpty(filter.property_list)) {
    _.forEach(filter.property_list, (prp) => {
      let prpL = [];
      if (_.isString(prp)) {
        // if string propertyFilter default ref
        // if the object found is of type ref
        // 
        _.forEach(filterObjectL, (fo) => {
          let prp = filterEntityProperty(filterEntity({ entity_id: fo.entity_id }), { property_name: prp });
          prpL.push('');
        });
      } else if (!isObjectEmpty(prp)) {
        // if object propertyFilter
      }
      console.log('Property List');
      console.log(prpL);
    });    
  } else {
    // if empty propertyFilter
    _.forEach(filterObjectL, (fo) => {
      console.log(fo);
      console.log('Ref Object')
      console.log(filterEntity({entity_id: fo.entity_id}));
    });    
    // add object ref
  }
  */
}

function entityChunk(filter) {
  // NOT CREATING ENTITY HERE
  if (!filter.hasOwnProperty('chunk') || isObjectEmpty(filter.chunk)) {
    console.log('Empty Chunk Type');
    return [];
  }
  let chunkL = filterEntity({ entity_name: filter.chunk.entity_name });
  if (filter.chunk.chunk_type === 'parent') {
    let entityL = [];
    if (_.isString(filter.entity)) {
      entityL = _.map(chunkL, (ch) => {     // ENTITY NAME
        let chE = _.find(ch, { object_type: 'object' });
        let chunkFO = {};
        if (filter.chunk.hasOwnProperty('chunk_on') && filter.chunk_on !== '') {
          let chunkPV = _.find(ch, { property_name: filter.chunk.chunk_on }).property_value;
          if (filter.chunk.hasOwnProperty('chunk_property') && filter.chunk_property !== '') {
            chunkFO = { [filter.chunk.chunk_property]: chunkPV };
          } else {
            chunkFO = { [filter.chunk.chunk_on]: chunkPV };
          }
        } else {
          chunkFO = { containing_entity_id: chE.entity_id };
        }
        return { chunk_filter: chunkFO, filter_entity: filterEntity({ entity_name: filter.entity, containing_entity_id: chE.entity_id })[0] };
      });
      return entityL;
    } else {          // NEW ENTITY OBJECT
      entityL = _.map(chunkL, (ch) => {
        let chE = _.find(ch, { object_type: 'object' });
        let chunkFO = {};
        if (filter.chunk.hasOwnProperty('chunk_on') && filter.chunk_on !== '') {
          let chunkPV = _.find(ch, { property_name: filter.chunk.chunk_on }).property_value;         // BUG
          if (filter.chunk.hasOwnProperty('chunk_property') && filter.chunk_property !== '') {
            chunkFO = { [filter.chunk.chunk_property]: chunkPV };
          } else {
            chunkFO = { [filter.chunk.chunk_on]: chunkPV };
          }
        } else {
          chunkFO = { containing_entity_id: chE.entity_id };
        }
        let newE = entityProperty({ entity: filter.entity, parent: chE, property: [] }, Query.applicationEntity);
        Query.dataPoint.push(...newE);
        return { chunk_filter: chunkFO, filter_entity: newE };
      });
      return entityL;
    }
  } else if (filter.chunk.chunk_type === 'child') {
    let entityL = [];
    if (_.isString(filter.entity)) {
      entityL = _.map(chunkL, (ch) => {     // ENTITY NAME
        let chE = _.find(ch, { object_type: 'object' });
        let chunkFO = {};
        if (filter.chunk.hasOwnProperty('chunk_on') && filter.chunk_on !== '') {
          let chunkPV = _.find(ch, { property_name: filter.chunk.chunk_on }).property_value;
          if (filter.chunk.hasOwnProperty('chunk_property') && filter.chunk_property !== '') {
            chunkFO = { [filter.chunk.chunk_property]: chunkPV };
          } else {
            chunkFO = { [filter.chunk.chunk_on]: chunkPV };
          }
        } else {
          chunkFO = { containing_entity_id: chE.entity_id };
        }
        return { chunk_filter: chunkFO, filter_entity: filterEntity({ entity_name: filter.entity, entity_id: chE.containing_entity_id })[0] };
      });
      return entityL;
    } else {          // NEW ENTITY OBJECT
      entityL = _.map(chunkL, (ch) => {
        let chE = _.find(ch, { object_type: 'object' });
        let chunkFO = {};
        if (filter.chunk.hasOwnProperty('chunk_on') && filter.chunk_on !== '') {
          let chunkPV = _.find(ch, { property_name: filter.chunk.chunk_on }).property_value;
          if (filter.chunk.hasOwnProperty('chunk_property') && filter.chunk_property !== '') {
            chunkFO = { [filter.chunk.chunk_property]: chunkPV };
          } else {
            chunkFO = { [filter.chunk.chunk_on]: chunkPV };
          }
        } else {
          chunkFO = { containing_entity_id: chE.entity_id };
        }
        let newE = entityProperty({ entity: { ...filter.entity }, parent: chE, property: [] }, Query.applicationEntity);
        Query.dataPoint.push(...newE);
        return { chunk_filter: chunkFO, filter_entity: newE };
      });
      return entityL;
    }
  } else if (filter.chunk.chunk_type === 'entity' && _.isString(filter.entity) && filter.entity !== '') {
    // ONLY IF STRING, and Pass in property_entity_id
    let chunkL = filterEntity({ entity_name: filter.entity });
    entityL = _.map(chunkL, (ch) => {     // ENTITY NAME
      let chE = _.find(ch, { object_type: 'object' });
      let chunkFO = {};
      if (filter.chunk.hasOwnProperty('chunk_on') && filter.chunk_on !== '') {
        let chunkPV = _.find(ch, { property_name: filter.chunk.chunk_on }).property_value;
        if (filter.chunk.hasOwnProperty('chunk_property') && filter.chunk_property !== '') {
          chunkFO = { [filter.chunk.chunk_property]: chunkPV };
        } else {
          chunkFO = { [filter.chunk.chunk_on]: chunkPV };
        }
      } else {
        chunkFO = { property_entity_id: chE.entity_id };
      }
      return { chunk_filter: chunkFO, filter_entity: ch };
    });
    return entityL;
  }
  else if (filter.chunk.chunk_type === '' && !isObjectEmpty(filter.entity)) {    // INDEPENDENT ENTITY LIST
    let chunkL = [];
    // NEW ENTITY OBJECT
    entityL = _.map(chunkL, (ch) => {
      let chE = _.find(ch, { object_type: 'object' });
      let chunkFO = {};
      if (filter.chunk.hasOwnProperty('chunk_on') && filter.chunk_on !== '') {
        let chunkPV = _.find(ch, { property_name: filter.chunk.chunk_on }).property_value;
        if (filter.chunk.hasOwnProperty('chunk_property') && filter.chunk_property !== '') {
          chunkFO = { [filter.chunk.chunk_property]: chunkPV };
        } else {
          chunkFO = { [filter.chunk.chunk_on]: chunkPV };
        }
      } else {
        chunkFO = { containing_entity_id: chE.entity_id };
      }
      let newE = entityProperty({ entity: { ...filter.entity }, property: [], parent: {} }, Query.applicationEntity);
      Query.dataPoint.push(...newE);
      return { chunk_filter: chunkFO, filter_entity: newE };
    });
    return entityL;
  }
  // chunk_on, chunk_property, default{entity_property_id}
}

function frmwJoinFilter(entityFilter, chunkFilter) {
  // join filter, entity_one, property_one
  // entity_one filter
  let entityOne = frmwEntityFilter({ ...chunkFilter, entity_name: entityFilter.entity_one });
  let entityTwoF = _.map(entityOne, (ent) => {
    let prpOne = filterEntityProperty(ent, entityFilter.property_one);
    return { entity_one: ent, [entityFilter.property_two]: prpOne };
  });
  // for each property_one, entity_two, property_two: property_one      
  //console.log('Entity Two Filter');
  //console.log(entityTwoF);
  let entityTwo = _.map(entityTwoF, (ett) => {
    //console.log({ entity_name: entityFilter.entity_two, [entityFilter.property_two]: ett[entityFilter.property_two]});
    let ettw = frmwEntityFilter({ entity_name: entityFilter.entity_two, [entityFilter.property_two]: ett[entityFilter.property_two] });
    if (!_.isEmpty(ettw)) {
      return { [entityFilter.entity_one]: [ett.entity_one], [entityFilter.entity_two]: ettw };
    } else {
      return {};
    }
  });
  // entity_two filter
  entityTwo = _.filter(entityTwo, (ett) => {
    return !isObjectEmpty(ett);
  })
  return entityTwo;
}

function filterEntityProperty(entity, propertyF) {
  // if entity_type == 'ref_object' get ref property entity and get property
  let entityObj = _.find(entity, (ent) => {
    if (ent.hasOwnProperty('object_type')) {
      return true;
    } else {
      return false;
    }
  });
  
  if (!isObjectEmpty(entityObj) && entityObj.object_type === 'ref_object') {
    //console.log('Filter Entity Property- Entity Object');
    //console.log(entityObj);
    let prp = _.find(entity, { property_type: 'object_ref' });
    let ent = filterEntity({ entity_id: prp.property_value });
    return _.filter(ent, propertyF);
  } else {
    let ent = filterEntity({entity_id: entity.entity_id});
   // console.log('Filter Entity');
   // console.log(ent);
    return _.filter(ent, propertyF);
  }
}

function filterSiblingProperty(entity, propertyFilter) {

}

function filterParentProperty(entity, propertyFilter) {

}

function filterEntity(filter) {
  let entL = _.filter(Query.dataPoint, { ...filter, object_type: 'object' });  
  return _.map(entL, (ent) => {
    return [ent, ..._.filter(Query.dataPoint, { property_entity_id: ent.entity_id })];
  });
}

function frmwEntityFilter(filter) {
  let entLbl = filter.hasOwnProperty('entity_label') && filter.entity_label !== '' ? { entity_label: filter.entity_label } : {};
  let entName = filter.hasOwnProperty('entity_name') && filter.entity_name !== '' ? { entity_name: filter.entity_name } : {};
  let contEnt = filter.hasOwnProperty('containing_entity_id') && filter.containing_entity_id !== '' ? { containing_entity_id: filter.containing_entity_id } : {};
  let entL = _.filter(Query.dataPoint, { ...entLbl, ...entName, ...contEnt, object_type: 'object' });

  let tmpFlt = _.cloneDeep(filter);
  delete tmpFlt.entity_label;
  delete tmpFlt.entity_name;
  delete tmpFlt.containing_entity_id;
  let tmpFltK = Object.keys(tmpFlt);
  if (tmpFltK.length > 0) {
    tmpFlt = _.map(Object.keys(tmpFlt), (k) => {
      return { property_name: k, property_value: filter[k] };   // IN FILTER YOU ARE GIVING PROPERTY NAME AND PROPERTY VALUE
    });
    entL = _.filter(entL, (ent) => {
      let prpCond = _.map(tmpFlt, (fl) => {
        let prpL = _.filter(Query.dataPoint, { ...fl, property_entity_id: ent.entity_id, object_type: 'property' });
        return prpL.length > 0;
      });
      return _.reduce(prpCond, (pCon, cCon) => {
        return pCon && cCon;
      }, true);
    });
    return entL;
  } else {
    return entL;
  }
}

function longEntityFilter(filter) {
  let filterElementL = _.map(Object.keys(filter), (k) => {
    return { [k]: filter[k] };
  });
  console.log('Long entity filter');
  console.log(filterElementL);
}

exports.applyFilter = applyFilter;
exports.setApplicationEntity = setApplicationEntity;
exports.Query = Query;