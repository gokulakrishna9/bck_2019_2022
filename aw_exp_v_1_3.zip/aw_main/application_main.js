let async = require('async');
let _ = require('lodash');
let { action_list } = require('./action_route');
let { applyFilter, setApplicationEntity, Query } = require('./filter');
exports.applicationMain = function (transaction) {
  // assume an application name
  console.log('Application Main');
  let applicationName = 'Application One';
  // assume a database name
  let databaseName = 'funds_tracker';
  // assume a design pattern name
  let designPattern = 'mvc';
  async.waterfall([
    function (mnWflClb) {
      // get design pattern
      let dpO = require(action_list['mvcPage'].file_name)['mvcPage']({ db_name: databaseName, application_name: applicationName });
      mnWflClb(null, dpO);
    },
    function (dpPage, mnWflClb) {
      // apply filters
      setApplicationEntity(applicationName);
      console.log('Apply Filter');
      async.concatSeries(dpPage, (fl, flClb) => {
        applyFilter(fl, (err, rslt) => {
          flClb(null, null);
        });
      }, (err, rslt) => {
        // get page data and test
        let objectL = _.filter(Query.dataPoint, { object_type: 'object', entity_name: 'table' });
        console.log('Object List');
        console.log(objectL);
        let objectRL = _.filter(Query.dataPoint, { object_type: 'ref_object' });
        //console.log('Object Ref List');
        //console.log(objectRL);
        mnWflClb(null, null);
      });
    },
    function (dbDataDpData, mnWflClb) {
      // call filter list
      mnWflClb(null, null);
    },
    function (pageCLPip, mnWflClb) {
      // write template to entities
      mnWflClb(null, null);
    },
    function (pageDPip, mnWflClb) {
      // write template to file
      mnWflClb(null, null);
    },
    function (pageCLPip, mnWflClb) {
      // write code definition to file|db
      mnWflClb(null, null);
    }
  ], (err, applicationDefinitionList) => {
    //res.send()
  });
}