let _ = require('lodash');
let async = require('async');
let { splitCapitalize } = require('../helper_op/string_function');
let { getDBSchema } = require('../db_op/db_op.js');
let { addEntTree, entityProperty } = require('./entity_op');

function fieldObj(filter, scope, applicationEntity, filterList, fnlClb) {
  getDBSchema(filter.action_object.db_name, (err, columnL) => {
    async.concat(columnL, (column, asCClb) => {
      let columnType = _.split(column.COLUMN_TYPE.replace('(', ' ').replace(')', ''), ' ');
      let label = column.COLUMN_KEY != 'PRI' && (columnType[0] == 'varchar' || columnType[0] == 'char' || columnType[0] == 'date' || columnType[0] == 'time' || columnType[0] == 'datetime' || columnType[0] == 'timestamp') && columnType[1] > 5 && columnType[1] <= 75;
      let primaryColumn = column.COLUMN_KEY == 'PRI';
      asCClb(err, entityProperty({
        entity: { entity_name: filter.entity.entity_name, entity_label: filter.entity.entity_label },
        property: [
          { property_name: 'column_type', property_value: columnType[0] },
          { property_name: 'column_size', property_value: columnType[1] },
          { property_name: 'column_key', property_value: column.COLUMN_KEY },
          { property_name: 'column_name', property_value: column.COLUMN_NAME },
          { property_name: 'table_name', property_value: column.TABLE_NAME },
          { property_name: 'column_label', property_value: splitCapitalize(column.COLUMN_NAME, '_') },
          { property_name: 'label_column', property_value: label },
          { property_name: 'primary_column', property_value: primaryColumn },
          { property_name: 'db', property_value: column.TABLE_SCHEMA },
          { property_name: 'column_comment', property_value: column.COLUMN_COMMENT }
        ]
      }, applicationEntity));
    }, (err, colL) => {
      fnlClb(err, _.flattenDeep(colL));
    });
  });
}

function uniqueTable(filter, scope, applicationEntity, filterList, fnlClb) {
  console.log('Unique Table');
  let tableL = _.map(scope, (sc) => {
    return _.find(sc, { property_name: 'table_name' }).property_value;
  });
  tableL = _.uniq(tableL);
  tableL = _.map(tableL, (tbl) => {
    return entityProperty({
      entity: { entity_name: filter.entity.entity_name, entity_label: filter.entity.entity_label },
      property: [
        { property_name: 'table_name', property_value: tbl }
      ]
    }, applicationEntity);
  });
  fnlClb(null, _.flattenDeep(tableL));
}

exports.fieldObj = fieldObj;
exports.uniqueTable = uniqueTable;