const filterType = {
  find_entity: 'find_entity', filter_entity: 'filter_entity', copy_filter: 'copy_filter',
  copy_ref: 'copy_ref', action_filter: 'action_filter', step_filter: 'step_filter'
};
const getFilterScope = { entity: 'entity', all_scope: 'pipeline' };
const actionList = require('./action_route');
let _ = require('lodash');
let { isObjectEmpty, isString } = require('../helper_op/object');
let { action_list } = require('../aw_main/action_route');
let { createEntity, createProperty } = require('./entity_op');

// entity n =1 is entity_label, entity_id
class EntityScope {
  static scope = [];      // entity_list with entity_label, filter_id, head_filter_id, as properties
  // PROBLEM WITH PARALLEL EXECUTION FOR SINGLE ARRAY, UPDATE IN STAGES
  static applyFilter(filter, fnlClb) {
    // if not empty head_label get head filter
    let headLabel = [];      // search by label, headLabel's entity_id becomes containing_entity_id
    if (filter.hasOwnProperty('head_label') && filter.head_label !== '') {
      headLabel = _.filter(EntityScope.scope, { entity_label: filter.head_label });
    }   // HEAD ENTITY LIST
    // if not empty scope_filter, get scope_filter
    let filterScope = [];
    if (filter.hasOwnProperty('scope')) { // you are adding these properties to entity_name, entity_label
      if (!_.isEmpty(headLabel) && filter.scope == 'page') {
        filterScope = _.flattenDeep(_.map(headLabel, (hf) => {
          return _.filter(EntityScope.scope, { root_entity_id: hf.entity_id });
        }));
      } else if (!_.isEmpty(headLabel) && filter.scope !== '') {
        // filter name + head filter's entity_id as containing_entity_id
        filterScope = _.flattenDeep(_.map(headLabel, (hf) => {
          return _.filter(EntityScope.scope, { containing_entity_id: hf.entity_id, entity_label: filter.scope });
        }));
      } else if (!_.isEmpty(headLabel) && filter.scope === 'entity') {
        // return property containing_entity_id is headLabel's entity_id
        filterScope = _.flattenDeep(_.map(headLabel, (hf) => {
          return _.filter(EntityScope.scope, { property_entity_id: hf.entity_id });
        }));
      } else if (!_.isEmpty(headLabel) && filter.scope === '') {
        filterScope = _.flattenDeep(_.map(headLabel, (hf) => {
          return _.filter(EntityScope.scope, { property_entity_id: hf.entity_id });
        }));
      } else if (_.isEmpty(headLabel) && filter.scope !== '') {
        // filter name + head filter's entity_id as containing_entity_id
        filterScope = _.flattenDeep(_.filter(EntityScope.scope, { entity_label: filter.scope }), (ent) => {
          return _.filter(EntityScope.scope, { property_entity_id: ent.entity_id });
        });
      } else if (filter.scope === 'pipeline') {
        // return the entire scope
        filterScope = EntityScope.scope;
      }
    } else {
      filterScope = EntityScope.scope;
    }       // ALL PAGE AND PIPELINE AND HEAD COVERED
    console.log('Filter Obj');
    console.log(filter);
    console.log('Scope');
    console.log(filterScope);
    // You have filter scope HERE
    // FILTER IS THE SAME AS ENTITY LABEL is just more description
    let subFilter = EntityScope.getSubFilter(filter.property_filter); // is an OR condition
    // if not empty filter, get sub filter, only one, or error
    let subFilterL = [];
    if (!_.isEmpty(subFilter) && !_.isEmpty(headLabel)) {
      _.forEach(headLabel, (hf) => {
        _.forEach(subFilter, (filter, key) => {
          let filterL = _.filter(EntityScope.scope, { entity_label: filter[0], containing_entity_id: hf.entity_id });
          subFilterL = _.map(_.filter(filterL, [filter[1]]), (sfl) => {
            return { parent_entity: hf, filter: { ...filter, [key]: sfl } };
          });
        });
      });
    } else if (_.isEmpty(subFilter) && !_.isEmpty(headLabel)) {
      subFilterL = _.map(headLabel, (hf) => { return { parent_entity: hf, filter: filter.property_filter }; });
    } else {
      subFilterL = [{ parent_entity: {}, filter: filter.property_filter }];
    }
    // WHICH PROPERTY NAME HAS THE REF, db false not here
    console.log('Sub Filter');
    console.log(subFilterL);
    let filterObjL = _.map(subFilterL, (sf) => {
      // IF NO ENTITY LABEL SET ADD TO HEAD ENTITY
      let entity = {};
      if (isObjectEmpty(sf.filter) && !isObjectEmpty(sf.parent_entity)) {
        if (filter.hasOwnProperty('entity_name') && filter.entity_name !== '') {
          entity = createEntity({ entity_label: filter.entity_label, entity_name: filter.entity_name }, {}, sf.parent_entity);
          let propertyL = _.map(_.filter(filterScope, { containing_entity_id: sf.parent_entity.entity_id }), (prp) => {
            return createProperty(prp, entity, {});
          });
          return _.flattenDeep([entity, propertyL]);
        }
      } else if (isObjectEmpty(sf.filter) && isObjectEmpty(sf.parent_entity) && filter.hasOwnProperty('entity_name') && filter.entity_name !== '') {
        entity = createEntity({ entity_label: filter.entity_label, entity_name: filter.entity_name }, {}, sf.parent_entity);
        let propertyL = _.map(_.filter(filterScope, { containing_entity_id: sf.parent_entity.entity_id }), (prp) => {
          return createProperty(prp, entity, {});
        });
        return _.flattenDeep([entity, propertyL]);
      } // else with application object

      let filterL = _.filter(filterScope, sf.filter);

      // if filterL is entity get entity property list
      if (filter.hasOwnProperty('property_type') && filter.property_type !== 'ref_ref') {
        let propertyL = _.map(filterL, (fl) => { return { property_value: fl.property_id, property_type: 'ref_ref', property_entity_id: sf.entity_id } });
        propertyL = _.map(propertyL, (prp) => {
          if (isObjectEmpty(entity)) {
            return createProperty(prp, fl.parent_entity, {});
          } else {
            return createProperty(prp, entity, {});
          }
        });
        return _.flattenDeep([entity, propertyL]);
      } else {
        let propertyL = _.map(filterL, (fl) => {
          if (fl.property_type == 'ref') {
            return { property_id: fl.property_value, property_entity_id: sf.entity_id };
          } else {
            return { property_id: fl.property_value, property_entity_id: sf.entity_id };
          }
        });
        propertyL = _.map(propertyL, (prp) => {
          if (isObjectEmpty(entity)) {
            return createProperty(prp, fl.parent_entity, {});
          } else {
            return createProperty(prp, entity, {});
          }
        });
        return _.flattenDeep([entity, propertyL]);
      }
    });
    EntityScope.scope.push(_.flattenDeep(filterObjL));
    console.log('Filter Object List');
    console.log(filterObjL);
    // pass action parameter, filter_list|scope to action
    // ACTION WITH CALL BACK AND DONE, RUN THIS ONCE TO CONFIRM IT IS WORKING
    if (filter.hasOwnProperty('action') && filter.action !== '') {
      if (action_list.hasOwnProperty(filter.action)) {
        if (filter.hasOwnProperty('action_parameter') && !isObjectEmpty(filter.action_parameter)) {
          require(action_list[filter.action].file_name)[filter.action]({ ...filter.action_parameter, [filter.scope]: filterScope }, filter, (err, actionRslt) => {
            // map action result to entity
            let flEL = _.map(actionRslt, (ar) => {
              return createEntity({ ...ar, entity_name: filter.entity_name, entity_label: filter.entity_label });
            });
            EntityScope.scope.push(..._.flattenDeep(flEL));
            fnlClb(null, actionRslt);
          });
        } else {
          require(action_list[filter.action].file_name)[filter.action]({ [filter.scope]: filterScope }, filter, (err, actionRslt) => {
            let flEL = _.map(actionRslt, (ar) => {
              return createEntity({ ...ar, entity_name: filter.entity_name, entity_label: filter.entity_label });
            });
            EntityScope.scope.push(..._.flattenDeep(flEL));
            fnlClb(null, actionRslt);
          });
        }
      } else {
        EntityScope.scope.push(..._.flattenDeep(filterObjL));
        fnlClb(null, null);
        console.log('Action Not Defined: ', filter.action);
      }
    } else {
      EntityScope.scope.push(..._.flattenDeep(filterObjL));
      fnlClb(null, null);
    }
  }

  static getHeadElement(headLabel = '') {
    if (headLabel !== '')
      return _.filter(EntityScope.scope, { entity_label: filter.head_label });
    else
      return [];
  }

  // LIST{just property}, all entities needed are in headEL, query in stages only, entity->page->model->model_method->property
  static writeScope(headEL = [], scope = '') {
    let filterScope = [];
    if (!_.isEmpty(headEL) && scope == 'page') {
      filterScope = _.map(headEL, (hf) => {
        return _.map(hf.filter, (fl) => {
          return { head: hf.head_entity_id, property: _.filter(EntityScope.scope, { root_entity_id: hf.head_entity_id, ...fl }) };
        });
      });
    } else if (!_.isEmpty(headEL) && (scope === 'entity' || scope === '')) {
      filterScope = _.map(headEL, (hf) => {
        return _.map(hf.filter, (fl) => {
          return { head: hf.head_entity_id, property: _.filter(EntityScope.scope, { property_entity_id: hf.entity_id, ...fl }) };
        });
      });
    } else if (!_.isEmpty(headEL) && scope !== '') {
      let scpEl = _.map(headEL, (hf) => {
        return _.map(hf.filter, (fl) => {
          return { head: hf.head_entity_id, childEL: _.filter(EntityScope.scope, { containing_entity_id: hf.head_entity_id, ...fl, entity_label: scope }) };
        });
      });
      filterScope = _.map(scpEl, (sel) => {
        return _.map(sel, (se) => { return { head: sel.head, property: _.filter(EntityScope.scope, { property_entity_id: se.entity_id }) } });
      });
    } else if (_.isEmpty(headEL) && scope !== '') {
      filterScope = _.flattenDeep(_.filter(EntityScope.scope, { entity_label: filter.scope }), (ent) => {
        return { head: -1, property: _.filter(EntityScope.scope, { property_entity_id: ent.entity_id }) };
      });
    }

    return _.flattenDeep(filterScope);
  }

  static propertyFilter(entity_id, propertyFilter, propertyRefL) {
    let propertyL = _.filter(EntityScope.scope, { property_entity_id: entity_id });
    let prpFlKey = Object.keys(propertyFilter);
    // build one property object with property_name taken from property_filter
    let match = true;
    _.forEach(prpFlKey, (pk) => {
      if (_.some(propertyL, { [pk]: propertyFilter[pk] })) {
        return;
      } else {
        match = false;
        return false;
      }
    });
    if (match) {
      return _.map(propertyRefL, (pr) => { return _.find(propertyL, { property_name: pr }); });
    } else {
      return [];
    }
  }

  static addToScope(entityL) {
    EntityScope.push(...entityL);
  }

  static getFilterL(filter, headEL = []) {
    let flP = Object.keys(filter);
    let filterO = _.map(flP, (flp) => {
      return { [flp]: _.split(filter.property_filter[flp], '.') };
    });
    if (filterO.length > 1) {
      return false;
    } else if (filterO.length == 1) {
      return [filter];
    } else if (!_.isEmpty(headEL)) {
      let flPl = _.map(headEL, (hf) => {
        return _.filter(EntityScope.scope, { containing_entity_id: hf.entity_id, entity_label: filterO[0] });
      });
      flPl = _.flattenDeep(flPl);
      flPl = _.map(flPl, (fl) => {
        if (filterO.length > 2) {
          return { head_entity_id: fl.entity_id, filter: _.filter(EntityScope.scope, { property_entity_id: fl.entity_id, [filterO[1]]: filterO[2] }) };
        } else if (filterO.length == 2) {
          let rtPl = _.filter(EntityScope.scope, { property_entity_id: fl.entity_id });
          return { head_entity_id: fl.entity_id, filter: _.filter(rtPl, filterO[1]) };
        }
      });
      return _.flattenDeep(flPl);
    }
  }

  static applyAction(filterObject, scope) {

  }
}

exports.EntityScope = EntityScope;

/*
if (filter.hasOwnProperty('head_label') && filter.head_label !== '') {
      // get head filter list and build a filter list with head_label
      let headfilterL = entityProperty(EntityScope.scope, { entity_label: filter.head_label });
      // get scope filter{entity{default}, page, pipeline}
      // for each head filter get scope, and call filterObject
      _.forEach(headfilterL, (hd) => {
        if (filter.hasOwnProperty('scope') && filter.scope !== "") {
          if (filter.scope === 'page') {
            hd['scope'] = _.filter(EntityScope.scope, { containing_entity_id: hd.entity_id });
          } else if (filter.scope === 'pipeline') {
            hd['scope'] = EntityScope.scope;
          } else {
            let scp = _.filter(EntityScope.scope, { entity_label: scope });
            hd['scope'] = scp;
          }
        } else {
          hd['scope'] = hd;     // entity
        }
      });
    } else {        // Step One in the Unwinding
      if (filter.hasOwnProperty('filter') && !isObjectEmpty(filter.property_filter)) {
        // call filterObject
      } else if (filter.hasOwnProperty('action') && filter.action !== '') {
        // WRITE ACTION FILTER FIRST        
        let scp = [];
        if (filter.hasOwnProperty('scope') && filter.scope !== '') {
          scp = _.filter(EntityScope.scope, { entity_label: filter.scope });
        }
        if (!_.isEmpty(scp)) {
          console.log(filter.action);
          if (filter.hasOwnProperty('action_parameter') && (!isObjectEmpty(filter.action_parameter) || isString(filter.action_parameter))) {
            console.log('Scope Action Parameter');
            require(action_list[filter.action].file_name)[filter.action](filter.action_parameter, scp, (err, acOL) => {
              EntityScope.scope.push(...createEntityProperty(filter, acOL));
              fnlClb(null, null);
            });
          } else {
            console.log('Scope No Action Parameter');
            require(action_list[filter.action].file_name)[filter.action](scp, (err, acOL) => {
              EntityScope.scope.push(...createEntityProperty(filter, acOL));
              fnlClb(null, null);
            });
          }
        } else {
          console.log(filter.action);
          if (filter.hasOwnProperty('action_parameter') && (!isObjectEmpty(filter.action_parameter) || isString(filter.action_parameter))) {
            require(action_list[filter.action].file_name)[filter.action](filter.action_parameter, (err, acOL) => {
              EntityScope.scope.push(...createEntityProperty(filter, acOL));
              // console.log(EntityScope.scope);
              fnlClb(null, null);
            });
          } else {
            require(action_list[filter.action].file_name)[filter.action]((err, acOL) => {
              EntityScope.scope.push(...createEntityProperty(filter, acOL));
              fnlClb(null, null);
            });
          }
        }
      } else {
        // do nothing
      }
    }
*/