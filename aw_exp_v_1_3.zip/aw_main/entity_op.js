let _ = require('lodash');
const generateUniqueId = require('generate-unique-id');

function createEntity(entity, applicationEntity = { entity_id: '' }, parent = { entity_id: '' }) {
  let unqid = generateUniqueId({
    length: 11,
    useLetters: false
  });
  entity['object_type'] = entity.hasOwnProperty('object_type') ? entity.object_type: 'object';
  entity['entity_id'] = unqid;
  entity['containing_entity_id'] = parent.entity_id;
  entity['application_id'] = applicationEntity.entity_id;
  return entity;
}

function createProperty(property, entity = { entity_id: '' }, applicationEntity = { entity_id: '' }) {
  let unqid = generateUniqueId({
    length: 11,
    useLetters: false
  });
  property['object_type'] = 'property';
  property['property_id'] = unqid;
  property['property_entity_id'] = entity.entity_id;
  property['application_id'] = applicationEntity.entity_id;
  return property;
}

function entityProperty(entityProperty, applicationE) {
  let entity = createEntity(entityProperty.entity, applicationE, entityProperty.parent);
  let property = _.map(entityProperty.property, (prp) => { return createProperty(prp, entity, applicationE) });
  return [entity, ...property];
}

function addEntTree(entityList, applicationE, fnlClb) {
  async.concat(entityList, (ent, asClb) => {
    if (ent.hasOwnProperty('parent')) {
      let parent = createEntity(ent.parent.entity, applicationE);
      let property = _.map(ent.parent.property, (prp) => { return createProperty(prp, parent, applicationE); })       // application entity pending
      addEntTree(ent.child, (err, rentityObj) => {
        asClb(err, [parent, ...property, rentityObj]);
      });
    } else if (!isObjectEmpty(ent)) {
      let entity = createEntity(ent.entity);
      let property = _.map(ent.property, (prp) => { return createProperty(prp, entity, applicationE) });
      asClb(err, [entity, ...property]);
    }
  }, (err, rslt) => {
    fnlClb(err, _.flattenDeep(rslt));
  });
}

function dpOEN(dpONL, pgEId, dpOpPL, applicationE, fnlClb) {
  let childL = [];
  async.concatSeries(dpONL, (opn, asCSClb) => {
    // check if array, recurse add to child, add child to callback object
    if (opn === undefined) {
      asCSClb(null, []);
      return;
    }
    if (!_.isString(opn) && Array.isArray(opn)) {
      dpOEN(opn, pgEId, dpOpPL, applicationE, (err, opEL) => {
        childL = opEL;
        asCSClb(null, []);
      });
    } else {
      // get op property/filter{with execute attribute, after main filter is done go to execute attribute}, create entity,
      // add parent key to child entity list empty child entity return the entire array[entity, child]
    }
    // if name create entity, add property, callback, if child not empty, for each child  add this as parent
  }, (err, dpOpEL) => {
    // flatten deep the result and return
  });
}

function dpOEPL(opL, rtEntityId, opObjL, applicationId) {
  let opEL = [];
  let chOpL = [];
  _.forEach(opL, (op) => {
    if (op === undefined)
      return;
    if (!_.isString(op) && Array.isArray(op)) {
      chOpL.push(...dpOEPL(op, rtEntityId, opObjL, applicationId));
    } else {
      let opPrp;
      if (opObjL.hasOwnProperty(op)) {
        opPrp = opObjL[op];
        opPrp = _.map(_.filter(opPrp.property_list, (prp) => {
          return prp.hasOwnProperty('ce_property_value') && !prp.hasOwnProperty('property_on');
        }), (prp) => {
          return new EntityProperty(0, 'property', prp.ce_property_name, 'string', prp.ce_property_value);
        });
      }
      if (_.isEmpty(opPrp))
        opPrp = [];
      if (!_.isEmpty(chOpL)) {
        opEL.push({ parent: { entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op), new EntityProperty(0, 'root_entity', 'ce_ref', 'ref', rtEntityId), ...opPrp] }, child: chOpL });
        chOpL = [];
      } else {
        opEL.push({ entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op), new EntityProperty(0, 'root_entity', 'ce_ref', 'ref', rtEntityId), ...opPrp] });
      }
    }
  });

  if (_.isEmpty(opEL))
    opEL = chOpL;
  return opEL;
}

exports.entityProperty = entityProperty;
exports.addEntTree = addEntTree;
exports.createEntity = createEntity;
exports.createProperty = createProperty;


/*
exports.createEntityProperty = createEntityProperty;
function createEntityProperty(filter, filterObL, entity = {}, parentEntity = {}, applicationEntity = {}) {
  if (filter.hasOwnProperty('entity_label') || filter.hasOwnProperty('entity_name')) {
    // create entity list, look for containing entity id, make every thing else property with filter name
    let entityP = _.map(filterObL, (flo) => {
      let entity_name = filter.hasOwnProperty('entity_name') ? filter.entity_name : '';
      entity_name = flo.hasOwnProperty(entity_name) ? flo[entity_name] : '';
      let entity_label = filter.hasOwnProperty('entity_label') ? filter.entity_label : '';
      let ent = createEntity({ entity_name: entity_name, entity_label: entity_label }, applicationEntity, parentEntity);
      let propertyL = Object.keys(flo);
      propertyL = _.map(propertyL, (prp) => {
        return createProperty({ [prp]: flo[prp] }, ent, applicationEntity);
      });
      return [entity, propertyL];
    });
    return _.flattenDeep(entityP);
  } else if (filter.hasOwnProperty('property_label') || filter.hasOwnProperty('property_name')) {
    // create property list, look for property entity id, add filter name, root filter name
    let entityP = _.map(filterObL, (flo) => {
      let propertyL = Object.keys(flo);
      return _.map(propertyL, (prp) => {
        return createProperty({}, entity, applicationEntity);
      });
    });
    return _.flattenDeep(entityP);
  }
}*/