let _ = require('lodash');
let async = require('async');
const { action_list } = require('./action_route');
let { addEntTree, entityProperty } = require('./entity_op');
let { isObjectEmpty } = require('../helper_op/object');
class Query {
  static dataPoint = [];
  static applicationEntity = {};
  static localScope = [];
}

function setApplicationEntity(applicationName) {
  Query.applicationEntity = entityProperty({ entity: { entity_name: applicationName, entity_label: 'application' }, property: [] })[0];
}

function applyFilter(filter, fnlClb) {
  // chunk is on entity
  // get entity list{chunk_type, chunk_on}
  // empty chunk
  // get entity list if entity is string
  if (!filter.hasOwnProperty('chunk') || isObjectEmpty(filter.chunk)) {
    // apply filter{let filter create the entity, if entity is string error}
    // if entityFilter present apply entity filter
    // if action present apply action filter else fnlClb
    applyAction(filter, [], fnlClb);
  } else {
    // get chunk list then...
    // entityFilter
    let chunkFilter = {};
    if (filter.chunk.chunk_type === 'parent') {
      // set entity_filter, containing_entity_id
    } else if (filter.chunk.chunk_type === 'child') {
      // set entity_filter, entity_id
    } else if(filter.chunk.chunk_type === 'sibling') {
      // set entity_filter, containing_entity_id
    } else if(filter.chunk.chunk_type === 'entity') {
      // set entity_filter, entity_id
    }
    // for each chunk filter, combine with filter create filter, list
    // for each filter apply filter, entityFilter
    // call action with chunk list
    fnlClb(null, null);
  }
}

function applyAction(filter, filterList, fnlClb) {
  let scope = [];
  if (filter.hasOwnProperty('scope') && filter.scope !== '') {
    scope = _.filter(Query.dataPoint, { entity_name: filter.scope });
    scope = _.map(scope, (sc) => { return [sc, ..._.filter(Query.dataPoint, { property_entity_id: sc.entity_id })] });
  }

  require(action_list[filter.action].file_name)[filter.action](filter, scope, Query.applicationEntity, filterList, (err, actionRslt) => {
    // map action result to entity
    Query.dataPoint.push(...actionRslt);
    fnlClb(err, actionRslt);
  });
}

function joinFilter(filter, chunkFilter, fnlClb) {

}

function entityFilter(filter, fnlClb) {  
  let entityList = filterEntity(filter, (err, entL) => {
    async.filter(entL, (ent, ascon) => {

    }, (err, entPL) => {
      fnlClb(null, null);
    });
  });
}

function joinFilterEntity(filter, fnlClb) {

}

function filterEntity(entityFilter, fnlClb) {
  // fix to framework
  let entityName = '';
  let entityLabel = '';
  async.filter(Query.dataPoint, (dp) => {
    
  });
}

function containsProperty(entity, propertyFilter, fnlClb) {

}

function filterProperty(entity, propertyFilter, fnlClb) {
  // fix to framework
  // entity type ref_obj then get property
  // else get normal property with name, if value filter present ref property and get value
}

function nonStandardFilterEntity(entityFilter) {

}

function nonStandardFilterProperty(entity, propertyFilter, fnlClb) {

}

exports.applyFilter = applyFilter;
exports.setApplicationEntity = setApplicationEntity;
exports.Query = Query;