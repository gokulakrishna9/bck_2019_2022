let _ = require('lodash');
let async = require('async');
let { getDBSchema } = require('../db_op/db_op');
let { Entity, Property, objectToPropertyL } = require('../db_component/entity');
let { splitCapitalize } = require('../helper_op/string_function');
let { isObjectEmpty } = require('../helper_op/object');

exports.dbObj = function (db, fclb) {
  // get db data
  console.log('Scaffold Object DB Name');
  db = {db_name: 'funds_tracker', application_name: 'test_one'};
  console.log(db);
  let dbName = db.db_name;//findProp(db, { property_label: 'name' }).property_value;
  getDBSchema(dbName, (derr, dbSchema) => {
    // get unique table, map table_name, distinct table_name    
    let tableL = _.union(_.map(dbSchema.columns, (sch) => { return sch.TABLE_NAME }));  //unique values
    // for each table create column objects
    console.log('Uniq Table');
    console.log(tableL);
    tableL = _.map(tableL, (tbl) => {
      let colL = _.map(_.filter(dbSchema.columns, { TABLE_NAME: tbl }), (col) => { return fieldObj(col) });
      return {
        parent: new Entity('table', tbl, db.application_id, 0, [new Property(0, 'entity_name', 'table_name', 'string', tbl), new Property(0, 'entity_name', 'db_name', 'string', db.db_name)]),
        child: _.map(colL, (col) => {
          return Entity('column', col.column_name, db.entity.application_id, [new Property(0, 'entity_name', 'column_name', 'property_ref', 0), ...objectToPropertyL(col)]);
        })
      }
    });
    let rslt = { 
      entity: new Entity('application', db.application_name, 0, [new Property(0, 'entity_name', 'application_name', 'string', db.application_name)]), 
      child: [{ 
        parent: new Entity('database', db.application_name, 0, [new Property(0, 'entity_name', 'database_name', 'string', db.db_name)]), 
        child: tableL 
      }]
    };
    fclb(derr, rslt);
  });
}


exports.findRelation = function (dbObjL, fclb) {
  // {relation, containing_entity, ref table_one, ref table_two, ref col_one, ref col_two, ref_col_two_label}
  let tableL = _.map(entityFilter(dbObjL, { entity_label: 'table' }), (tl) => { return entityToObj(tl); });
  let colL = _.map(entityFilter(dbObjL, { entity_label: 'column' }), (cl) => { return entityToObj(cl); });
  async.concat(tableL, (tbl, acClb) => {
    // get column list
    let relationL = [];
    let tcL = _.filter(colL, { containing_entity_id: tbl.entity_id });
    let pCl = _.find(tcL, { column_key: 'PRI' });
    if (!isObjectEmpty(pCl)) {
      let cCol = _.filter(colL, { column_name: pCl.column_name });
      cCol = _.filter(_.reject(cCol, { column_key: 'PRI' }), { column_type: 'int' });
      _.forEach(cCol, (cl) => {
        let lbl = _.find(colL, { containing_entity_id: cl.containing_entity_id, label_column: true });
        if (isObjectEmpty(lbl)) {
          lbl = cl;
        }
        relationL.push({
          entity: new Entity('relation', 'derived', tbl.application_id, tbl.entity_id, [
            new EntityProperty(0, 'table', '1_table', 'ref', tbl.entity_id),
            new EntityProperty(0, 'column', '1_column', 'ref', pCl.entity_id),
            new EntityProperty(0, 'table', '2_table', 'ref', cl.containing_entity_id),
            new EntityProperty(0, 'column', '2_column', 'ref', cl.entity_id),
            new EntityProperty(0, 'column', 'select_col', 'ref', lbl.entity_id),
          ]),
        });
      });
    }
    let npC = _.filter(tcL, { column_type: 'int' });
    _.forEach(npC, (np) => {
      let mCol = _.find(colL, { column_name: np.column_name, column_key: 'PRI' });
      if (!isObjectEmpty(mCol)) {
        let lbl = _.find(colL, { containing_entity_id: mCol.containing_entity_id, label_column: true });
        if (isObjectEmpty(lbl)) {
          lbl = mCol;
        }
        relationL.push({
          entity: new Entity('relation', 'master', tbl.application_id, tbl.entity_id),
          property: [
            new EntityProperty(0, 'table', '1_table', 'ref', tbl.entity_id),
            new EntityProperty(0, 'column', '1_column', 'ref', np.entity_id),
            new EntityProperty(0, 'table', '2_table', 'ref', mCol.containing_entity_id),
            new EntityProperty(0, 'column', '2_column', 'ref', mCol.entity_id),
            new EntityProperty(0, 'column', 'select_col', 'ref', lbl.entity_id)
          ]
        });
      }
    });
    acClb(null, relationL);
  }, (err, relationL) => {
    fclb(null, relationL);
  });
}