let _ = require('lodash');
exports.getDistinct = function (objectList, objKey, filter) {
  let unique = [];
  if (!_.isEmpty(filter))
    objectList = _.filter(objectList, filter);
  unique = _.map(objectList, (ob) => {return {[objKey]: ob[objKey]}});
  unique = _.uniqBy(objectList, objKey);
  return unique;
}

exports.getUniqueProperty = function (objectList, groupLabel, filter) {
  let unique = [];
  if (_.isEmpty(groupLabel)) {
    console.log('Set group label!')
    return [];
  }
  objectList = _.filter(objectList, { group_label: groupLabel });
  if (!_.isEmpty(filter))
    objectList = _.filter(objectList, { ...filter });
  _.forEach(objectList, (ob) => {
    let key = Object.keys(ob);
    _.forEach(key, (k) => {
      if (_.findIndex(unique, k) >= 0)
        return;
      else
        unique.push(k);
    });
  });
  return unique;
}

function addDistinct (table_name, column_list, insert_value, clbck) {
  async.waterfall([
    function (clb) {
      // check filter
      async.concat(insert_value, (val, aclb) => {
        let filter = _.map(column_list, (col) => {
          return col + '=' + val[col];
        });
        filter = _.join(filter, ' AND ');
        let sql = "SELECT * FROM " + table_name + " WHERE " + filter;
        myc_pool.getConnection((err, connection) => {
          if (err) {
            console.log(err);
            clbck(err, null);
          }
          connection.query(sql, [value], function (error, result, fields) {
            if (error) {
              console.log(error);
              aclb(error, null);
            } else {
              if (_.isEmpty(result))
                aclb(null, { insert_record: val, insert: true });
              else
                aclb(null, { insert_record: ' ', insert: false });
            }
          });
          connection.release();
        });
      }, clb(err, rslt));
    },
    function (rslt, clb) {
      // if not in filter insert
      console.log(rslt);
      /*
      let sql = "INSERT INTO code_writer.property (object_id,	property_label,	property_name, property_type,	property_value, property_description, property_template) VALUES (?)";
      async.concat(clO,
        (cl, aclb) => {
          if (_.isEmpty(cl))
            return;
          myc_pool.getConnection((err, connection) => {
            connection.query(sql, [cl], function (error, result, fields) {
              if (error) {
                console.log(error);
                aclb(error, null);
              } else {
                aclb(null, { column_name: cl[1], insert_id: result.insertId });
              }
            });
            connection.release();
          });
        },
        function (err, rslts) {
          if (err) {
            console.log(err);
          } else {
            clbck(null, { ...rslt, property: rslts });
          }
        }
      );
      */
    }
  ]);
}

exports.addDistinct = addDistinct;

exports.addRecord = function (table_name, insert_record, clbck) {

}

exports.updateRecord = function (table_name, filter, update_record, clbck) {

}

exports.isObjectEmpty = function(ckObject) {
  if((typeof(ckObject) === "undefined" || ckObject === null) || (Object.keys(ckObject).length === 0 && ckObject.constructor === Object))
    return true;
  return false;
}

exports.isString = function(ckObject) {
  if (typeof ckObject === 'string' || ckObject instanceof String) {
    return true;
  }
}