var express = require('express');
var router = express.Router();
let async = require('async');
let { writeTransactionState, updateTransactionState, getTransactionStatus } = require('../db_op/transaction_op');
let { applicationMain } = require('../aw_main/application_main');
const generateUniqueId = require('generate-unique-id');
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/default', function (req, res, next) {
  const id = generateUniqueId({
    length: 11,
    useLetters: false
  });
  async.waterfall([
    function (cwfClb) {
      // write the transaction intialization to DB
      writeTransactionState(id, (err, rslt) => {
        applicationMain({ t_state: rslt.insertId, lt_req_key: rslt.lt_req_key });
        cwfClb(err, { t_state: rslt.insertId, lt_req_key: rslt.lt_req_key });
      });
    }
  ], (err, rslt) => {
    // send the transaction key to application_main
    console.log('Long Transaction record');
    console.log(rslt);
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(rslt));
  });
});

module.exports = router;