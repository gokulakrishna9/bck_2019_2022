let _ = require('lodash');
let myc_pool = require('./connection_pool_sql_to_application');
let async = require('async');
let { getDBSchema } = require('./db_object');
let { dbERModel } = require('./db_er_model');
let { getDistinct } = require('../helper_op/object');
let { writeMVCProperty } = require('../dp_middleware/mvc_property.js');
let { addEntityAndProperty } = require('./write_tree');
let { addEntityTree } = require('../model/write_tree');
exports.initialiseDbObjectList = function (applicationObj, callback) {
  console.log('Initialize DB Object List');
  console.log(applicationObj);
  // entity_id,	automatically update on change, , , operator specific properties,
  // value type, or template, , used in template, , template or value,
  // template or value, , , destructure programmer aid, automate, created_on, updated_on, active
  let tblList = [];
  async.waterfall([
    function (clbck) {
      // get data from application object
      let dbList = applicationObj.db_list;
      dbList = typeof dbList === 'string' ? [dbList] : dbList;
      let application = {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'object', 'application', ' ', ' ', ' ']],
          entity_property: [[0, 0, 0, 0, 'property', 'name', 'string', 'application_name', applicationObj.application_name]]
        }], child_entity: [
          ..._.map(dbList, (db) => {
            return {
              parent_entity: [
                {
                  entity: [[0, 0, 0, 0, 'object', 'database', ' ', ' ', ' ']],
                  entity_property: [[0, 0, 0, 0, 'property', 'name', 'string', 'database_name', db]]
                }
              ],
              child_entity: []
            }
          })
        ]
      };
      addEntityTree([application], (err, rslt) => {
        let db_list = _.filter(rslt, (ent) => { return ent.entity[0].entity_label == 'object' && ent.entity[0].entity_name == 'database'});
        let app = _.find(rslt, (ent) => { return ent.entity[0].entity_label == 'object' && ent.entity[0].entity_name == 'application'});
        clbck(err, {db_list: db_list, application: app});
      });
    },
    function (rslt, clbck) {
      if (rslt.hasOwnProperty('db_list')) {
        let dbList = _.map(rslt.db_list, (db) => {
          return _.find(db.entity_property, {entity_name: 'name', property_name: 'database_name'}).property_value;
        });
        async.concat(dbList, getDBSchema, (err, results) => {
          clbck(err, { ...rslt, db_schema: results });
        });
      }
    },
    function (rslt, clbck) {
      dbERModel({ db_schemas: rslt['db_schema'] }, (err, entities) => { clbck(err, { ...rslt, db_entity: _.flattenDeep(entities) }); });
    },//{db_list, db_schemas, }
    function (erModel, clbck) {
      // add records to db
      // add column
      // add relation
      // add column_property
      let label_counter = {};
      _.forEach(erModel.db_schemas, (mdl) => {
        if (!(mdl.group_label in label_counter))
          label_counter[mdl.group_label] = 1;
        else
          label_counter[mdl.group_label] += 1;
      });
      console.log('ErModel Details.');
      console.log(label_counter);
      clbck(null, erModel);
    },
    function (erModel, clbck) {
      /*
        property_entity_id, application_id, containing_entity_id, containing_entity_property_id, entity_label, entity_name, property_type, property_name, property_value
      */
      let entityList = [];
      _.forEach(erModel.db_list, (db) => {
        let dbName = _.find(db.entity_property, { property_name: 'database_name' });
        let tblList = getDistinct(erModel.db_entity, 'table_name', { group_label: 'table_column', db: dbName.property_value });
        console.log('Table Length');
        console.log(tblList.length);
        _.forEach(tblList, (table) => {
          entityList.push({
            entity: [[0, 0, db.entity[0].record_id, 0, 'rdbms_table', table.table_name, ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'name', 'string', 'table_name', table.table_name],
              [0, 0, dbName.property_entity_id, dbName.record_id, 'property', 'name', 'string', 'db_name', dbName.property_value]
            ]
          });
        });
      });
      // insert rdbms_table
      addEntityAndProperty(entityList, (err, rslt) => { clbck(err, { ...erModel, table_list: [...rslt] }); });
    },//erModel{db_scaffold, db_list, table_list}    
    function (erModel, clbck) {
      let tblList = _.map(erModel.table_list, (tbl) => {
        let db = _.find(tbl.entity_property, { property_name: 'db_name' });
        tbl = _.find(tbl.entity_property, { property_name: 'table_name' });
        return {
          table_entity_id: tbl.property_entity_id, table_name_property_id: tbl.record_id, table_name: tbl.property_value,
          db_entity_id: db.containing_entity_property_id, db_name_property_id: db.record_id, db_name: db.property_value
        };
      });
      let allColList = [];
      _.forEach(tblList, (tbl) => {
        let colList = _.filter(erModel.db_entity, { group_label: 'table_column', table_name: tbl.table_name, db: tbl.db_name });
        _.forEach(colList, (col) => {
          let colKeys = Object.keys(col);
          let colProps = []
          _.forEach(colKeys, (key) => {
            if (key == 'db') {
              colProps.push([0, 0, tbl.db_entity_id, tbl.db_name_property_id, 'property', 'name', 'string', 'db_name', tbl.db_name]);
            } else if (key == 'table_name') {
              colProps.push([0, 0, tbl.table_entity_id, tbl.table_name_property_id, 'property', 'name', 'string', 'table_name', col.table_name]);
            } else {
              colProps.push([0, 0, 0, 0, 'property', 'db_property', 'string', key, col[key]]);
            }
          });
          allColList.push({
            entity: [[0, 0, tbl.table_entity_id, 0, 'table_column', col.column_name, ' ', ' ', ' ']],
            entity_property: colProps
          });
        });
      });
      
      addEntityAndProperty(allColList, (err, rslt) => { clbck(err, { ...erModel, column_list: [...rslt] }); });
    },
    // add relation on table_entity
    function (erModel, clbck) {
      // column_list
      // db_schemas
      // table*1{table_list}, db*1{db_list}, column*1{column_list}
      // query table and corresponding children, filter on column_name, you get all, filter table, then filter db,
      // add to erModel, next method write relations to db
      // Simple, filter with a function
      let relation = _.filter(erModel.db_entity, { group_label: 'relation' });
      let rlm = _.filter(relation, { relation_type: 'master' });
      let rld = _.filter(relation, { relation_type: 'derived' });
      let rlbm = _.filter(relation, { relation_type: 'branching_master' });
      let rlbd = _.filter(relation, { relation_type: 'branching_derived' });

      async.concatSeries(erModel.table_list, (tbl, oAclb) => {
        let tblEnt = tbl.entity[0];
        let tblDB = _.find(tbl.entity_property, { property_name: 'db_name' });
        let tl = _.find(tbl.entity_property, { property_name: 'table_name' });
        let rm = _.filter(rlm, { table_name: tl.property_value, db: tblDB.property_value });
        let rd = _.filter(rld, { table_name: tl.property_value, db: tblDB.property_value });
        let rbm = _.filter(rlbm, { relation_root: tl.property_value, relation_root_db: tblDB.property_value });
        let rbd = _.filter(rlbd, { relation_root: tl.property_value, relation_root_db: tblDB.property_value });
        // search through column_list for tbl.containing_entity_id, find record_id, search for record_id in property_entity_id
        // finally search for column_name
        async.parallel([
          function (iAclb) {
            let rlO = [];
            _.forEach(rm, (rl) => {
              let rlObj = { entity: [], entity_property: [] };
              rlObj['entity'].push([0, 0, tblEnt.record_id, 0, 'relation', rl.table_name, ' ', ' ', ' ']);
              // columnList, columnName, tableName, dbName
              // 1
              let tP = findColumnAndLabelColumn(erModel.column_list, rl.column_name, rl.table_name, rl.db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'table_name', rl.table_name]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'table_column', rl.column_name]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'table_db_name', rl.db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'table_label', 'name', 'string', 'select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'table_label', 'name', 'string', 'select_column', tP.column.property_value]);
              // 2
              tP = findColumnAndLabelColumn(erModel.column_list, rl.master_column_name, rl.master_table_name, rl.db_master);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'join_on', rl.master_table_name]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_on_column', rl.master_column_name]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'join_on_db_name', rl.db_master]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.column.property_value]);
              rlObj['entity_property'].push([0, 0, 0, 0, 'label', 'name', 'string', 'relation_type', 'master']);
              rlO.push(rlObj);
            });
            if (_.isEmpty(rlO)) {
              iAclb(null, emptyInsert());
              return;
            }
            addEntityAndProperty(rlO, (err, rslt) => { iAclb(err, rslt); });
          },
          function (iAclb) {
            let rlO = [];
            _.forEach(rd, (rl) => {
              let rlObj = { entity: [], entity_property: [] };
              rlObj['entity'].push([0, 0, tblEnt.record_id, 0, 'relation', rl.table_name, ' ', ' ', ' ']);
              // 1
              let tP = findColumnAndLabelColumn(erModel.column_list, rl.column_name, rl.table_name, rl.db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'table_name', rl.table_name]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'table_column', rl.column_name]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'table_db_name', rl.db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'table_label', 'name', 'string', 'select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'table_label', 'name', 'string', 'select_column', tP.column.property_value]);
              // 2
              /*
                group_label: 'relation', relation_type: 'derived', column_type: 'int', column_size: '4', column_key: '', column_name: 'user_id',
                table_name: 'user_detail', column_label: 'User Id', label_column: false, db: 'e4s', column_comment: '', derived_table_name: 'service_record',
                derived_column_name: 'user_id', db_derived: 'e4s', branch: 'user_detail', active: true
               */
              tP = findColumnAndLabelColumn(erModel.column_list, rl.derived_column_name, rl.derived_table_name, rl.db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'join_on', rl.derived_table_name]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_on_column', rl.derived_column_name]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'join_on_db_name', rl.db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.column.property_value]);
              rlObj['entity_property'].push([0, 0, 0, 0, 'label', 'name', 'string', 'relation_type', 'derived']);
              rlO.push(rlObj);
            });
            if (_.isEmpty(rlO)) {
              iAclb(null, emptyInsert());
              return;
            }
            addEntityAndProperty(rlO, (err, rslt) => { iAclb(err, rslt); });
          },
          function (iAclb) {
            let rlO = [];
            _.forEach(rbm, (rl) => {
              // table_column, join_on, join_on_column
              // columnList, columnName, tableName, dbName
              let rlObj = { entity: [], entity_property: [] };
              rlObj['entity'].push([0, 0, tblEnt.record_id, 0, 'relation', rl.relation_root, ' ', ' ', ' ']);
              // 1
              let tP = findColumnAndLabelColumn(erModel.column_list, rl.relation_root_column, rl.relation_root, rl.relation_root_db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'table_name', rl.relation_root]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'table_column', rl.relation_root_column]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'table_db_name', rl.relation_root_db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'select_column', tP.column.property_value]);
              // 2
              tP = findColumnAndLabelColumn(erModel.column_list, rl.branch_on_column, rl.branch_on, rl.branch_on_db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'branch_on', rl.branch_on]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'branch_on_column', rl.branch_on_column]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'branch_on_db_name', rl.branch_on_db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'branch_join_select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'branch_join_select_column', tP.column.property_value]);
              // 3
              tP = findColumnAndLabelColumn(erModel.column_list, rl.master_table_name, rl.master_column_name, rl.db_master);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'join_on', rl.master_table_name]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_on_column', rl.master_column_name]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'join_on_db_name', rl.db_master]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.column.property_value]);
              rlObj['entity_property'].push([0, 0, 0, 0, 'label', 'name', 'string', 'relation_type', 'branch_master']);
              rlO.push(rlObj);
            });
            if (_.isEmpty(rlO)) {
              iAclb(null, emptyInsert());
              return;
            }
            addEntityAndProperty(rlO, (err, rslt) => { iAclb(err, rslt); });
          },
          function (iAclb) {
            let rlO = [];
            _.forEach(rbd, (rl) => {
              // table_column, join_on, join_on_column
              /**
                group_label: 'relation', relation_type: 'branching_derived', column_type: 'int', column_size: '4', column_key: '', column_label: 'Staff Id',
                label_column: false, column_comment: '', derived_table_name: 'hr_transaction', derived_column_name: 'staff_id', db_derived: 'health4all',
                branch: 'staff', active: true, relation_root: 'equipment', relation_root_column: 'equipment_id', relation_root_db: 'e4s', branch_on: 'staff',
                branch_on_column: 'staff_id', branch_on_db: 'health4all'
               */
              let rlObj = { entity: [], entity_property: [] };
              rlObj['entity'].push([0, 0, tblEnt.record_id, 0, 'relation', rl.relation_root, ' ', ' ', ' ']);
              // 1
              let tP = findColumnAndLabelColumn(erModel.column_list, rl.relation_root_column, rl.relation_root, rl.relation_root_db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'table_name', rl.relation_root]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'table_column', rl.relation_root_column]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'table_db_name', rl.relation_root_db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'table_label', 'name', 'string', 'select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'table_label', 'name', 'string', 'select_column', tP.column.property_value]);
              // 2
              tP = findColumnAndLabelColumn(erModel.column_list, rl.branch_on_column, rl.branch_on, rl.branch_on_db);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'branch_on', rl.branch_on]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'branch_on_column', rl.branch_on_column]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'branch_on_db_name', rl.branch_on_db]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'branch_on_select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'branch_on_select_column', tP.column.property_value]);
              // 3
              tP = findColumnAndLabelColumn(erModel.column_list, rl.derived_table_name, rl.derived_column_name, rl.db_derived);
              rlObj['entity_property'].push([0, 0, tP.table.containing_entity_id, tP.table.containing_entity_property_id, 'property', 'name', 'string', 'join_on', rl.derived_table_name]);
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_on_column', rl.derived_column_name]);
              rlObj['entity_property'].push([0, 0, tP.db.containing_entity_id, tP.db.containing_entity_property_id, 'property', 'name', 'string', 'join_on_db_name', rl.db_derived]);
              if (!_.isEmpty(tP.label_column)) {
                rlObj['entity_property'].push([0, 0, tP.label_column.containing_entity_id, tP.label_column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.label_column.property_value]);
              }
              rlObj['entity_property'].push([0, 0, tP.column.containing_entity_id, tP.column.containing_entity_property_id, 'property', 'name', 'string', 'join_select_column', tP.column.property_value]);
              rlObj['entity_property'].push([0, 0, 0, 0, 'label', 'name', 'string', 'relation_type', 'branch_derived']);
              rlO.push(rlObj);
            });
            if (_.isEmpty(rlO)) {
              iAclb(null, emptyInsert());
              return;
            }
            addEntityAndProperty(rlO, (err, rslt) => { iAclb(err, rslt); });
          }
        ], (err, rslt) => {     // iAclb
          oAclb(err, rslt);
        })
        ///*
        //*/
        //debugEntity('Relation Entity', rlO, { 4: 'label' });           
      }, (err, rslt) => {
        clbck(err, { ...erModel, relation_list: _.flattenDeep(rslt) });
      });
    },
    // here call mvc_property.js
    function (rslt, clbck) {
      writeMVCProperty(rslt, (err, rslt_prop) => { clbck(null, rslt_prop) });
    }
  ], (err, erModel) => {
    console.log('Done Writing Scaffold!');
    callback(err, erModel);
  });
}

function findColumnAndLabelColumn(columnList, columnName, tableName, dbName) {
  columnList = _.filter(columnList, (col) => { return col.entity[0].entity_name == columnName; });
  let colEnt = _.find(columnList, (col) => {
    /*
    console.log(columnName + ' ' + tableName + ' ' + dbName);
    console.log(col.entity_property);
    console.log(
      _.findIndex(col.entity_property, { property_name: 'column_name', property_value: columnName }) + ' ' +
      _.findIndex(col.entity_property, { property_name: 'table_name', property_value: tableName })  + ' ' +
      _.findIndex(col.entity_property, { property_name: 'db_name', property_value: dbName })
    ); */
    return (
      _.findIndex(col.entity_property, { property_name: 'column_name', property_value: columnName }) > -1 &&
      _.findIndex(col.entity_property, { property_name: 'table_name', property_value: tableName }) > -1 &&
      _.findIndex(col.entity_property, { property_name: 'db_name', property_value: dbName }) > -1
    );
  });
  if (_.isEmpty(colEnt)) {
    return {
      db: { containing_entity_id: ' ', containing_entity_property_id: ' ', property_value: ' ' },
      table: { containing_entity_id: ' ', containing_entity_property_id: ' ', property_value: ' ' },
      column: { containing_entity_id: ' ', containing_entity_property_id: ' ', property_value: ' ' },
      label_column: { containing_entity_id: ' ', containing_entity_property_id: ' ', property_value: ' ' }
    };
  }
  let db = _.find(colEnt.entity_property, { property_name: 'db_name' });
  let tbl = _.find(colEnt.entity_property, { property_name: 'table_name' });
  let col = _.find(colEnt.entity_property, { property_name: 'column_name' });
  let rslt = {
    db: { containing_entity_id: db.containing_entity_id, containing_entity_property_id: db.containing_entity_property_id, property_value: db.property_value },
    table: { containing_entity_id: tbl.containing_entity_id, containing_entity_property_id: tbl.containing_entity_property_id, property_value: tbl.property_value },
    column: { containing_entity_id: col.property_entity_id, containing_entity_property_id: col.record_id, property_value: col.property_value }
  }
  // label
  let colList = _.filter(columnList, (col) => {
    return col.entity[0].record_id == tbl.property_entity_id;
  });
  let lbl = {};
  _.forEach(colList, (col) => {
    lbl = _.find(col.entity_property, { property_name: 'label_column', property_value: true });
  });
  if (!_.isEmpty(lbl)) {
    rslt['label_column'] = { containing_entity_id: lbl.property_entity_id, containing_entity_property_id: lbl.record_id, property_value: lbl.property_value };
  }
  return rslt;
}

function emptyElement() {
  return {
    property_entity_id: 0, application_id: 0, containing_entity_id: 0, containing_entity_property_id: 0,
    entity_label: '', entity_name: '', property_type: '', property_name: '', property_value: ''
  };
}

function emptyInsert() {
  return [
    {
      entity: [{
        property_entity_id: '', application_id: '', containing_entity_id: '',
        containing_entity_property_id: '', entity_label: '',
        entity_name: '', property_type: '',
        property_name: '', property_value: '',
        record_id: ''
      }],
      entity_property: [{
        property_entity_id: '', application_id: '', containing_entity_id: '',
        containing_entity_property_id: '', entity_label: '',
        entity_name: '', property_type: '',
        property_name: '', property_value: '',
        record_id: ''
      }]
    }
  ];
}

function debugEntity(entityName, entityList, filterObj) {
  console.log(entityName);
  _.forEach(entityList, (el) => {
    console.log(el.entity);
    let entityProperty = _.filter(el.entity_property, filterObj);
    _.forEach(entityProperty, (ent) => {
      console.log(ent);
    });
  });
}