let async = require('async');
let _ = require('lodash');
let myc_pool = require('./connection_pool_sql_to_application');
let { connectionPoolManager } = require('./connection_pool_manager');
let mysql = require('mysql');

function addEntityTree(recordList, fnlClb) {
  if (!Array.isArray(recordList))
    recordList = [recordList];
  async.concat(recordList, (record, oasynClb) => {
    if (record.hasOwnProperty('parent_entity')) {
      addEntityAndProperty(record.parent_entity, (err, pRslt) => {
        if (record.hasOwnProperty('child_entity')) {
          _.forEach(record.child_entity, (ce) => {
            if (ce.hasOwnProperty('parent_entity')) {
              ce.parent_entity[0].entity[0][2] = pRslt[0].entity[0].record_id
            } else {
              ce.entity[0][2] = pRslt[0].entity[0].record_id
            }
          });
          addEntityTree(record.child_entity, (err, cRslt) => { oasynClb(err, [...pRslt, ...cRslt]); });
        }
      });
    } else if (record.hasOwnProperty('entity')) {
      addEntityAndProperty([record], (err, rslt) => {
        oasynClb(err, rslt);
      });
    } else {
      oasynClb(null, null);
    }
  }, (err, rslt) => {
    // output the count here
    fnlClb(err, rslt);
  });
}

let pConnection = myc_pool();
function dbConnection(sql, value, aclb) {
  pConnection.getConnection((err, connection) => {
    if (err) {
      console.log('Error! Unable to Get Connection.');
      //console.log(err);
      setTimeout(dbConnection, 5000, sql, value, aclb);
    } else {
      connection.query(sql, [value], function (error, result, fields) {
        connection.release();
        if (error) {
          console.log('Error! INSERT/UPATE PROPERTY.')
          console.log(error);
          setTimeout(dbConnection, 5000, pConnection, sql, value, aclb);
        } else {
          aclb(null, {
            property_entity_id: value[0], application_id: value[1], containing_entity_id: value[2],
            containing_entity_property_id: value[3], entity_label: value[4],
            entity_name: value[5], property_type: value[6],
            property_name: value[7], property_value: value[8],
            record_id: result.insertId
          });
        }
      });
    }
  });
}

function entityProperty(rList, clbck) {
  let sql = "INSERT INTO code_writer.entity_property (property_entity_id, application_id, containing_entity_id, containing_entity_property_id, entity_label, entity_name, property_type, property_name, property_value) VALUES (?)";
  // console.log('Record List');
  // console.log(recordList);  
  let rlst = _.chunk(rList, 500);
  let errorList = [];
  async.concatSeries(rlst, (recordList, oCSClb) => {
    async.concat(recordList, (rc, iclb) => {
      dbConnection(sql, rc, iclb);
    }, (err, rslt) => {
      oCSClb(err, rslt);
    });
  }, function (err, rslts) {
    if (err) {
      console.log('Error!')
      console.log(err);
    } else {
      // console.log('Results');
      _.forEach(rslts, (rslt) => {
        //console.log(rslt.record_id + ' ' + rslt.property_entity_id + ' ' + rslt.containing_entity_id + ' ' + rslt.entity_label + ' ' + rslt.entity_name + ' ' + rslt.property_name + ' ' + rslt.property_value);
      });
      clbck(null, rslts);
    }
  });
}

function addEntityAndProperty(recordList, clbck) {
  async.concat(recordList, (record, aclb) => async.waterfall([
    function (aclb) {
      entityProperty(record.entity, (err, rslt) => { aclb(err, rslt); });
    },
    function (rslt, aclb) {
      let propList = _.map(record.entity_property, (property) => {
        property[0] = rslt[0].record_id;
        return property;
      });
      entityProperty(propList, (err, rsltP) => {
        if (err) {
          aclb(err, null);
        }
        else {
          aclb(null, { entity: rslt, entity_property: rsltP });
        }
      });
    }
  ], (err, rslt) => {
    aclb(err, rslt);
  }), (err, rsltList) => {
    if (err) {
      clbck(err, null)
    } else {
      clbck(null, rsltList)
    }
  });
}

function transactionQuery(sql, value, aclb) {
  pConnection.getConnection((err, connection) => {
    if (err) {
      console.log('Error! Unable to Get Connection.');
      //console.log(err);
      setTimeout(dbConnection, 5000, sql, value, aclb);
    } else {
      connection.query(sql, [value], function (error, result, fields) {
        connection.release();
        if (error) {
          console.log('Error! INSERT/UPATE PROPERTY.')
          console.log(error);
          setTimeout(dbConnection, 5000, sql, value, aclb);
        } else {
          aclb(null, {
            lt_id: result.insertId
          });
        }
      });
    }
  });
}

function writeTransactionState(record, clbck) {
  let sql = "INSERT INTO code_writer.lt_state (lt_req_key) VALUES ('" + record + "')";
  transactionQuery(sql, '', (err, rslt) => { clbck(err, { lt_req_key: record, ...rslt }); });
}

function updateTransactionState(filter, record, clbck) {
  console.log(filter);
  let sql = "UPDATE code_writer.lt_state SET status = " + record + " WHERE lt_id = " + filter.lt_id + " AND lt_req_key = '" + filter.lt_req_key + "'";
  transactionQuery(sql, '', (err, rslt) => { clbck(err, { lt_req_key: record, ...rslt, lt_state: record }); });
}

exports.updateTransactionState = updateTransactionState;
exports.writeTransactionState = writeTransactionState;
exports.addEntityProperty = entityProperty;
exports.addEntityAndProperty = addEntityAndProperty;
exports.addEntityTree = addEntityTree;