let async = require('async');
let _ = require('lodash');
let myc_pool = require('./connection_pool_sql_to_application');

let connectionPool = myc_pool('code_writer');
exports.getDatabaseList = function (callback) {
  console.log('Get DB List.');
  connectionPool.getConnection((err, connection) => {
    connection.query('SHOW DATABASES', (error, result, fields) => {
      connection.release();
      if (error) {
        console.log('Error! In SHOW DATABASES');
        callback(error, null);
      } else {
        // raise result action
        // return !(rs == 'information_schema' || rs == 'mysql'
        // || rs == 'performance_schema' || rs == 'sys' || rs == 'code_writer');
        result = _.map(result, (rs) => { return rs.Database; })
        callback(null, result);
      }
    });
  });
};

function queryCW(query, clbk) {
  connectionPool.getConnection((err, connection) => {
    if (err) {
      console.log('Error! Unable to Get Connection.');
      console.log(err);
      clbk(err, null);
    } else {
      connection.query(query, function (error, result, fields) {
        connection.release();
        if (error) {
          console.log('Error! Unable to get data.');
          console.log(error);
          console.log(this.sql)
          queryCW(query, clbk(error, null));
        } else {
          clbk(null, result);
        }
      });
    }
  });
}

// filter{entity, entity_property}
function getEntityProperty(filter, fclb) {
  // it should not be a property
  let entWhere = [];
  _.forEach(Object.keys(filter), (key) => {
    entWhere.push(key + ' = "' + filter[key] + '"');
  });
  entWhere = _.join(entWhere, ' AND ');
  sql = 'SELECT * FROM entity_property WHERE ';
  if (_.isEmpty(entWhere)) {
    clbk(null, []);
    return;
  };
  async.waterfall([
    function (clbk) {
      queryCW(sql + entWhere, (err, rslt) => { clbk(err, rslt) });
    },
    function (rslt, clbk) {
      // asyncSeries on rslt;
      rslt = _.chunk(rslt, 30);
      async.concatSeries(rslt, (rsC, asnSrClb) => {
        async.concat(rsC, (rs, asnClb) => {
          async.waterfall([
            function (asnwfl) {
              let where = 'property_entity_id = "' + rs.entity_id + '"';
              queryCW(sql + where, (err, propertyL) => { asnwfl(err, { entity: rs, entity_property: propertyL }); });
            },
            function (rslt, asnwfl) {
              let where = 'entity_id = "' + rs.property_entity_id + '"';
              queryCW(sql + where, (err, container) => { asnwfl(err, { ...rslt, entity_object: container }); });
            },
            function (rslt, asnwfl) {
              if (rs.property_entity_id != 0) {
                let where = 'property_entity_id = "' + rs.property_entity_id + '"';
                queryCW(sql + where, (err, propertyList) => { rslt.entity_property.push(...propertyList); asnwfl(err, rslt); });
              } else {
                asnwfl(null, rslt);
              }
            },
            function (rslt, asnwfl) {
              if (rs.entity_id != 0) {
                let where = 'containing_entity_id = ' + rs.entity_id ;
                //console.log(sql + where);
                queryCW(sql + where, (err, childList) => { asnwfl(err, { ...rslt, child_entity: childList }); });
              } else {
                asnwfl(null, {...rslt, child_entity: []});
              }
            },///*
            function (rslt, asnwfl) {
              if (rs.containing_entity_id != 0) {
                let where = 'entity_id = ' + rs.containing_entity_id ;
                //console.log(sql + where);
                queryCW(sql + where, (err, parentList) => { asnwfl(err, { ...rslt, parent_entity: parentList }); });
              } else {
                asnwfl(null, {...rslt, parent_entity: []});
              }
            },//*/
          ], (err, rslt) => {
            asnClb(err, rslt);
          });
        }, (err, rslt) => {
          asnSrClb(err, rslt);
        });
      }, (err, rslt) => {
        clbk(err, _.flatten(rslt));
      });
    }
  ], (err, rslt) => {
    fclb(err, rslt);
  });
}

function getTransactionStatus(transactionRec, clb) {
  sql = 'SELECT * FROM lt_state WHERE lt_id = ' + transactionRec.lt_id + ' AND lt_req_key = "' + transactionRec.lt_req_key + '"';
  queryCW(sql, (err, rslt) => {
    clb(err, rslt);
  });
}

exports.getEntityProperty = getEntityProperty;
exports.getTransactionStatus = getTransactionStatus;