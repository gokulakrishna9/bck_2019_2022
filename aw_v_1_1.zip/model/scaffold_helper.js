let _ = require('lodash');
let {splitCapitalize} = require('../helper_op/string_function');

exports.fieldObj = function(column) {
  let columnType = _.split(column.COLUMN_TYPE.replace('(', ' ').replace(')', ''), ' ');
  let label = column.COLUMN_KEY != 'PRI' && (columnType[0] == 'varchar' || columnType[0] == 'char' || columnType[0] == 'date' || columnType[0] == 'time' || columnType[0] == 'datetime' || columnType[0] == 'timestamp') && columnType[1] > 5 && columnType[1] <= 75;
  return {
    column_type: columnType[0],
    column_size: columnType[1], 
    column_key: column.COLUMN_KEY,
    column_name: column.COLUMN_NAME,
    table_name: column.TABLE_NAME,
    column_label: splitCapitalize(column.COLUMN_NAME, '_'),
    label_column: label,
    db: column.TABLE_SCHEMA,
    column_comment: column.COLUMN_COMMENT
  };
}