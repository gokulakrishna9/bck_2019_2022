let myc_pool = require('./connection_pool_sql_to_application');
var _ = require('lodash');
let { fieldObj } = require('./scaffold_helper');

// Raise set all databases, only once, should be called in index.html and only once
exports.getDatabases = function (callback) {
  myc_pool().getConnection((err, connection) => {
    connection.query('SHOW DATABASES', (error, result, fields) => {
      if (error) {
        console.log('Error! In SHOW DATABASES');
        callback(error, null)
      }        
      // raise result action
      callback(null, result);
    });
  });
};

exports.getDBSchema = function (db_name, callback) {
  myc_pool().getConnection((err, connection) => {
    connection.query('SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = "' + db_name + '"', (error, result, fields) => {
      if (error) {
        rslt['error'] = error;
        callback(error, null);
        return;
      }
      let rslt = { db_name: db_name, columns: result };
      callback(null, rslt);
    });
    connection.release();
  });
}