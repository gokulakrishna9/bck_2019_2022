// these actions should trigger scaffold change, code change, long run redux
// for now combine code generation operation, into one, scaffolding into one
function addColumn(commandObj, calbck) {

}

function updateColumn(commandObj, calbck) {

}

function deleteColumn(commandObj, calback) {

}

function alterColumn(commandObj, calbck) {

}

function associateColumn(commandObj, calbck) {
  // read up foreign key constraint
}