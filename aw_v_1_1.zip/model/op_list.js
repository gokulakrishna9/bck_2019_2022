exports.getOps = function () {
  return [
    {
      op_name: 'list_db',
      op_file: './db_op/db_scaffold',
      op_method: 'listDB',
      help_text: ['Lists Databases that can be accessed.']
    },
    {
      op_name: 'app_init',
      op_file: './db_op/db_scaffold',
      op_method: 'appInit',
      help_text: ['Initialize an application.', 'Properties{app_name, db_list-comma separated values}.']
    }
  ]
}