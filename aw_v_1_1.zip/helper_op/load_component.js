let _ = require('lodash');
let { framework_map } = require('./framework_map');
// get the map
// get the component
// get the method
// after all the methods have been invoked invoke component method
// look for a json file as well
exports.loadComponent = function (componentName) {
  let componentLst = _.filter(framework_map(), {component_name: componentName});
  if(_.isEmpty(componentLst)) {
    console.log('Component Not Found');
    return [];
  }
  return _.flattenDeep(_.map(componentLst, (cmp) => {
    return require(cmp.component_folder + '/' + cmp.component_file);
  }));
}