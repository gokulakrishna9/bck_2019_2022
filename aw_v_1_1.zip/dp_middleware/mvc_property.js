let _ = require('lodash');
let async = require('async');
let { addEntityTree, addEntityProperty, addEntityAndProperty } = require('../model/write_tree');
let { coComponent } = require('../entity_helper/component_method');
let { findScopeObj, stepSearch, findEntProp } = require('../helper_op/search');
let { writeCode } = require('../ci_component/code_writer');
// e- insertTmpl
exports.writeMVCProperty = function (appProperty, calbck) {
  let dbList = appProperty.db_list;
  let tableList = appProperty.table_list;
  let columnList = appProperty.column_list;
  let relationList = appProperty.relation_list;
  let codeEntityList = [];
  _.forEach(dbList, (db) => {
    let dbTbl = _.filter(tableList, (tbl) => {
      return tbl.entity[0].containing_entity_id == db.entity[0].record_id;
    });
    let dbName = _.find(db.entity_property, { property_name: 'database_name' });
    let dbCol = _.filter(columnList, (col) => {
      let colDb = _.find(col.entity_property, { property_name: 'db_name' });
      return colDb.property_value == dbName.property_value;
    });
    let tblProp = { db_table: dbTbl, db_col: dbCol, relation_list: relationList };
    _.forEach(tblProp.db_table, (table) => {
      let tblCol = _.filter(tblProp.db_col, (col) => {
        return col.entity[0].containing_entity_id == table.entity[0].record_id;
      });
      let relation = _.filter(relationList, (rl) => {
        return !_.isEmpty(_.find(rl.entity_property, { containing_entity_id: table.entity[0].record_id }));
      });
      relation = _.filter(relation, (rl) => {
        return !_.isEmpty(_.find(rl.entity_property, { property_name: 'relation_type', property_value: 'master' }));
      });
      // code entity
      let codeEntity = writeEntity({ table_col: tblCol, relation_list: relation, db_column: dbCol }, table);
      codeEntityList.push(codeEntity);
    });
  });
  let i = 0;
  async.waterfall([
    function (wfClb) {
      async.concat(codeEntityList, (ce, conClb) => {
        addEntityTree(ce, (err, ceLst) => { conClb(err, ceLst); });
      }, (err, ceLst) => {
        wfClb(err, ceLst);
      });
    },
    function (codeEntLst, wfClb) {
      // column op
      // for each codeEntity column, get datasource
      console.log('In Col DS callback');
      // in codeEntLst, filter out code entity
      let codeObjLst = _.filter(codeEntLst, (entE) => {
        return entE.entity[0].entity_name == 'code_entity';
      });
      let colObjLst = _.filter(codeEntLst, (entE) => {
        return (entE.entity[0].entity_label == 'component' && entE.entity[0].entity_name == 'column');
      });
      console.log(codeObjLst.length);
      console.log(colObjLst.length)
      ///* // COLUMN DATA SOURCE
      async.concat(codeObjLst, (coe, asncnclb) => {
        addEntityAndProperty(writeColumnDS(coe, codeEntLst, colObjLst), (err, rslt) => { asncnclb(err, rslt); });
      }, (err, rslt) => {
        wfClb(err, [...codeEntLst, ...rslt]);
      });
    }
  ], (err, rslt) => {
    console.log('Done MVC Property!');
    writeCode({ db_list: dbList, table_list: tableList, column_list: columnList, relation_list: relationList, code_entity_list: rslt }, (err, rslt) => {
      calbck(err, rslt);
    });
  });
}

function writeEntity(entityProperty, table) {
  let tableName = _.find(table.entity_property, { property_name: 'table_name' });
  let codeEntity = {
    parent_entity: [{
      entity: [[0, 0, table.entity[0].record_id, 0, 'component', 'code_entity', ' ', ' ', ' ']],
      entity_property: [[0, 0, 0, 0, 'property', 'parent_component', 'ref', 'table', table.entity[0].record_id]]
    }],
    child_entity: [
      writeColumn(entityProperty),
      // change parent entity to view-method, have pattern file names in view-method, have controller name, model name on entity        
      {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'component', 'view', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, tableName.record_id, 'view', 'folder', 'string', 'folder_name', tableName.property_value],
          ]
        }],
        child_entity: [
          route(),
          layout(),
          defaultForm(tableName),
          tableGrid(tableName, entityProperty)
        ]
      }
    ]
  };
  return codeEntity;
}

function writeColumn(entityProperty) {
  // Add Entity to column head
  // { table_col: tblCol, relation_list: relation, db_column: dbCol }
  let colList = _.map(entityProperty.table_col, (col) => {
    let cl = { entity: [[0, 0, 0, 0, 'component', 'column', ' ', ' ', ' ']], entity_property: [] };
    let colNm = _.find(col.entity_property, { property_name: 'column_name' }).property_value;
    let masterColumn = _.find(entityProperty.relation_list, (rl) => {
      let tblCol = _.find(rl.entity_property, { property_name: 'table_column', property_value: colNm });
      return !_.isEmpty(tblCol);
    });
    cl.entity_property.push([0, 0, 0, 0, 'property', 'parent_component', 'ref', 'column', col.entity[0].record_id])
    if (!_.isEmpty(masterColumn)) {
      // join_on, join_on_column, join_table_label
      let mstTbl = _.find(masterColumn.entity_property, { property_name: 'join_on' });
      let mstCol = _.find(masterColumn.entity_property, { property_name: 'join_on_column' });
      // data source      
      cl.entity_property.push(
        [0, 0, 0, 0, 'property', 'master_table', 'ref', 'master_table', mstTbl.containing_entity_id],
        [0, 0, 0, 0, 'property', 'master_column', 'ref', 'master_column', mstCol.containing_entity_id],
        [0, 0, 0, 0, 'property', 'label', 'string', 'label_name', 'filter'],
      );
    }
    let lblCol = _.find(col.entity_property, { property_name: 'label_column', property_value: true });
    if (!_.isEmpty(lblCol)) {
      cl.entity_property.push(
        [0, 0, 0, 0, 'property', 'label', 'string', 'label_name', 'filter']
      );
    }
    return cl;
  });
  return { parent_entity: [{ entity: [[0, 0, 0, 0, 'component', 'column_list', ' ', ' ', ' ']], entity_property: [] }], child_entity: colList };
}

function writeColumnDS(ent, entList, alColList) {
  let colList = findScopeObj(entList, { entity: { containing_entity_id: ent.entity[0].record_id, entity_name: 'column_list' }, entity_property: {} });
  colList = findScopeObj(alColList, { entity: { containing_entity_id: colList[0].entity[0].record_id, entity_name: 'column' }, entity_property: { property_name: 'master_table' } });
  let allGet = [];
  _.forEach(colList, (col) => {
    let mstTblRef = findEntProp(col, { property_name: 'master_table' });      // Done!
    let getData = stepSearch(entList, [
      { containing_entity_id: mstTblRef.property_value, entity_name: 'code_entity' }, 
      { entity_name: 'view' }, { entity_name: 'table_grid' }, { entity_name: 'table' }, 
      { entity_name: 'default_table' }, { entity_name: 'controller' },
      { entity_name: 'get_data' }
    ]);
    allGet.push({ entity: [[0, 0, col.entity[0].record_id, 0, 'operator', 'column_datasource', 0, 0, 0]], entity_property: [[0, 0, 0, getData[0].entity[0].record_id, 'operator', 'column_datasource', 'ref', 'operator', getData[0].entity[0].record_id]] });
  });
  return allGet;
}

function writeColHTMLProp(dbColProp, masterDbCol) {
  // column_type, column_size
  /*
    column_type: columnType[0],
    column_size: columnType[1], 
    column_key: column.COLUMN_KEY,
    column_name: column.COLUMN_NAME,
    table_name: column.TABLE_NAME,
    column_label: splitCapitalize(column.COLUMN_NAME, '_'),
    label_column: label,
    db: column.TABLE_SCHEMA,
    column_comment: column.COLUMN_COMMENT
  */
  let ce = [];
  if (!_.isEmpty(masterDbCol)) {
    // {input, {checkbox, radio}}, {select}
    let select = { entity: [], entity_property: [] };
    let radio = { entity: [], entity_property: [] };
    let checkbox = { entity: [], entity_property: [] };
  } else if (dbColProp.column_type == 'int') {
    // {input, number}
  } else if (dbColProp.column_type == 'decimal') {
    // {input, number}
  } else if (dbColProp.column_type == 'double') {
    // {input, number}
  } else if (dbColProp.column_type == 'float') {
    // {input, number}
  } else if (dbColProp.column_type == 'smallint') {
    // {input, number}
  } else if (dbColProp.column_type == 'binary') {
    // radio
  } else if (dbColProp.column_type == 'bigint') {
    // {input, number}
  } else if (dbColProp.column_type == 'tinyint') {
    // {input, number}
  } else if (dbColProp.column_type == 'tinytext') {
    // {input, text}
  } else if (dbColProp.column_type == 'varchar') {
    // {input, text}
  } else if (dbColProp.column_type == 'text') {
    // {input, text}
  } else if (dbColProp.column_type == 'char') {
    // {input, text}
  } else if (dbColProp.column_type == 'mediumtext') {
    // {input, text}
  } else if (dbColProp.column_type == 'longtext') {
    // {textarea, text}
  } else if (dbColProp.column_type == 'date') {
    // {input, date}
  } else if (dbColProp.column_type == 'time') {
    // {input, time}
  } else if (dbColProp.column_type == 'datetime') {
    // {input, datetime-local}
  }
  else if (dbColProp.column_type == 'timestamp') {
    // {input, datetime-local}, actually disable timestamp
  }
}

function writeDataSource(entityProperty) {
  // relation_list: relation{entity_label: table_label|join_table_label, property_name: select_column}, table_col: tblCol, db_column: dbCol
  // map select column from column
  let relationList = _.map(entityProperty.relation_list, (rl) => {
    return {
      entity: [
        [0, 0, rl.entity[0].record_id, 0, 'component', 'relation', ' ', ' ', ' ']
      ],
      entity_property: []
    };
  });
  let datasource = {
    parent_entity: [{
      entity: [[0, 0, 0, 0, 'component', 'datasource', ' ', ' ', ' ']],
      entity_property: []
    }],
    child_entity: relationList
  }
  return datasource;
}

function route() {
  return {
    parent_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'code_entity_route', ' ', ' ', ' ']],
        entity_property: []
      }
    ],
    child_entity: [
      {
        entity: [[0, 0, 0, 0, 'operator', 'code_entity_route', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_page_url']
        ]
      }
    ]
  };
}

function layout() {
  return {
    parent_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'layout', ' ', ' ', ' ']],
        entity_property: []
      }
    ],
    child_entity: [{
      entity: [[0, 0, 0, 0, 'operator', 'default_layout', ' ', ' ', ' ']],
      entity_property: [[0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_layout']]
    }]
  };
}

function defaultForm(tableName) {
  return {
    parent_entity: [{
      entity: [[0, 0, 0, 0, 'component', 'form', ' ', ' ', ' ']],
      entity_property: []   // operator list
    }],
    child_entity: [
      {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'component', 'default_form', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_input'],
            [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_update']
          ]
        }],
        child_entity: [
          {
            parent_entity: [
              {
                entity: [[0, 0, 0, 0, 'component', 'controller', ' ', ' ', ' ']],
                entity_property: [
                  [0, 0, 0, tableName.record_id, 'property', 'name', 'ref', 'table_name', tableName.property_value]
                ]
              }
            ],
            child_entity: [
              {
                parent_entity: [{
                  entity: [[0, 0, 0, 0, 'operator', 'input', ' ', ' ', ' ']],
                  entity_property: [
                    [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_input'],
                    [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_update']
                  ]
                }],
                child_entity: [
                  {
                    parent_entity: [
                      {
                        entity: [[0, 0, 0, 0, 'component', 'model', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, tableName.record_id, 'property', 'name', 'string', 'table_name', tableName.property_value]
                        ]
                      }
                    ],
                    child_entity: [
                      {
                        entity: [[0, 0, 0, 0, 'operator', 'input', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, 0, 'property', 'operator', 'data_point', 'operator_name', 'default_input']
                        ]
                      },
                      {
                        entity: [[0, 0, 0, 0, 'operator', 'update', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, 0, 'property', 'operator', 'data_point', 'operator_name', 'default_update']
                        ]
                      },
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]        // write controller method name, model method name
  };
}

function defaultTable(tableName, entityProperty) {
  return {
    parent_entity: [{
      entity: [[0, 0, 0, 0, 'component', 'table', ' ', ' ', ' ']],
      entity_property: []   // operator list
    }],
    child_entity: [
      {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'component', 'default_table', ' ', ' ', ' ']],
          entity_property: [[0, 0, 0, 0, 'property', 'operator', 'scope', 'get_data', 'default_get_data']]
        }],
        child_entity: [
          {
            parent_entity: [
              {
                entity: [[0, 0, 0, 0, 'component', 'controller', ' ', ' ', ' ']],
                entity_property: [
                  [0, 0, 0, tableName.record_id, 'property', 'name', 'string', 'table_name', tableName.property_value]
                ]
              }
            ],
            child_entity: [
              {
                parent_entity: [{
                  entity: [[0, 0, 0, 0, 'operator', 'get_data', ' ', ' ', ' ']],
                  entity_property: [
                    [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_get_data']
                  ]
                }],
                child_entity: [
                  {
                    parent_entity: [
                      {
                        entity: [[0, 0, 0, 0, 'component', 'model', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, tableName.record_id, 'property', 'name', 'string', 'table_name', tableName.property_value]
                        ]
                      }
                    ],
                    child_entity: [
                      {
                        entity: [[0, 0, 0, 0, 'operator', 'get_data', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, 0, 'property', 'operator', 'data_point', 'operator_name', 'default_get_data']
                        ]
                      },
                      writeDataSource(entityProperty)
                    ]
                  },
                ]
              }
            ]
          },
          pagination(),
          filter(),
          ...recordOp(tableName)
        ]
      }
    ]  // write controller method name, model method name
  }
}

function tableGrid(tableName, entityProperty) {
  return {
    parent_entity: [{
      entity: [[0, 0, 0, 0, 'component', 'table_grid', ' ', ' ', ' ']]
    }],
    child_entity: [
      defaultTable(tableName, entityProperty)
    ]
  }
}

function pagination() {
  return {
    parent_entity: [{
      entity: [[0, 0, 0, 0, 'component', 'pagination', ' ', ' ', ' ']],
      entity_property: []   // operator
    }],
    child_entity: [{
      parent_entity: [{
        entity: [[0, 0, 0, 0, 'component', 'default_pagination', ' ', ' ', ' ']],
        entity_property: []
      }],
      child_entity: [
        {
          entity: [[0, 0, 0, 0, 'operator', 'get_data', ' ', ' ', ' ']],
          entity_property: [[0, 0, 0, 0, 'property', 'operator', 'scope', 'get_data', 'default_get_data']]
        }
      ]
    }]  // write controller method name, model method name
  };
}

function recordOp(tableName) {
  return [
    {
      parent_entity: [{
        entity: [[0, 0, 0, 0, 'component', 'button', ' ', ' ', ' ']],
        entity_property: []
      }],
      child_entity: [{
        entity: [[0, 0, 0, 0, 'operator', 'event', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_get_data'],
          [0, 0, 0, 0, 'property', 'label', 'string', 'button_label', 'Update'],
        ]
      }]
    },
    {
      parent_entity: [{
        entity: [[0, 0, 0, 0, 'component', 'button', ' ', ' ', ' ']],
        entity_property: []
      }],
      child_entity: [{
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'operator', 'event', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_delete_record'],
            [0, 0, 0, 0, 'property', 'label', 'string', 'button_label', 'Delete'],
          ]
        }],
        child_entity: [
          {
            parent_entity: [
              {
                entity: [[0, 0, 0, 0, 'component', 'controller', ' ', ' ', ' ']],
                entity_property: [
                  [0, 0, 0, tableName.record_id, 'property', 'name', 'string', 'table_name', tableName.property_value]
                ]
              }
            ],
            child_entity: [
              {
                parent_entity: [{
                  entity: [[0, 0, 0, 0, 'operator', 'delete_record', ' ', ' ', ' ']],
                  entity_property: [
                    [0, 0, 0, 0, 'property', 'operator', 'scope', 'operator_name', 'default_delete_record']
                  ]
                }], child_entity: [
                  {
                    parent_entity: [
                      {
                        entity: [[0, 0, 0, 0, 'component', 'model', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, tableName.record_id, 'property', 'name', 'string', 'table_name', tableName.property_value]
                        ]
                      }
                    ],
                    child_entity: [
                      {
                        entity: [[0, 0, 0, 0, 'operator', 'delete_data', ' ', ' ', ' ']],
                        entity_property: [
                          [0, 0, 0, 0, 'property', 'operator', 'data_point', 'operator_name', 'default_delete_record']
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }]
    }
  ]
}

function filter() {
  return {
    parent_entity: [{
      entity: [[0, 0, 0, 0, 'component', 'filter', ' ', ' ', ' ']],
      entity_property: []   // operator list
    }],
    child_entity: [{
      parent_entity: [{
        entity: [[0, 0, 0, 0, 'component', 'default_filter', ' ', ' ', ' ']],
        entity_property: [[0, 0, 0, 0, 'property', 'operator', 'scope', 'get_data', 'default_get_data']]
      }],
      child_entity: [{
        entity: [[0, 0, 0, 0, 'operator', 'get_data', ' ', ' ', ' ']],
        entity_property: [[0, 0, 0, 0, 'property', 'operator', 'scope', 'get_data', 'default_get_data']]
      }]
    }]  // write controller method name, model method name
  };
}

function viewTree(entityList) {
  if (!Array.isArray(entityList))
    entityList = [entityList];
  _.forEach(entityList, (ent) => {
    if (Array.isArray(ent)) {
      viewTree(ent);
    } else {
      if (ent.hasOwnProperty('parent_entity')) {
        viewTree(ent.parent_entity);
        viewTree(ent.child_entity);
      }
      else {
        console.log(ent.entity);
        console.log(ent.entity_property);
      }
    }
  });
}

function viewEntity(entityList) {
  if (!Array.isArray(entityList))
    entityList = [entityList];
  ///*
  _.forEach(entityList, (ent) => {
    console.log('Entity');
    console.log(ent.entity);
    console.log('Property');
    console.log(ent.entity_property)
  });
  // */
}