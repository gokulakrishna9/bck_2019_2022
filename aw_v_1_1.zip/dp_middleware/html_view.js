// default page for CRUD, basic report
// grid
// nav-bar
// form
// filter
// query builder in UI{?}
// report
let _ = require('lodash');
let { getOpsList } = require('../op_handler/op_list');
let async = require('async');
let { getEntityProperty } = require('../model/get_entity');
// grid column id, grid_list{col_size, element_list}
// form grid, ui grid
// 'default_layout', 'default_form', 'default_filter', 'default_pagination', 'default_table', with default UI

function writePage(fnlClb) {
  // get entity
  getEntityProperty({ entity: { entity_label: 'code_entity' }, entity_property: {} }, (err, codeEntityList) => {
    async.concat(codeEntityList, (ce, wpClb) => {
      ///*
      let page = writePageLayout(ce, (err, rslt) => {
        wpClb(err, rslt);
      });
      //*/
    });
  }, (err, rslt) => {
    // write route
    fnlClb(err, rslt);
  });
  // server side code
  // component property, data source, op_route, {add to session, get from session}
}
exports.writePage = writePage;

function writePageLayout(ce) {
  async.waterfall([
    function (clb) {
      // column_list-containing-entity-id, select{entity_properties}
      getEntityProperty({ entity: { containing_entity_id: ce.entity.entity_id, entity_label: 'column_list' }, entity_property: {} }, (err, rslt) => {
        clb(err, { column_list: rslt });
      });
    },
    function (colList, clb) {
      getEntityProperty({ entity: { containing_entity_id: ce.entity.entity_id, entity_name: 'controller' }, entity_property: {} }, (err, rslt) => {
        clb(err, { ...colList, controller: rslt });
      });
    },
    function (colLC, clb) {
      getEntityProperty({ entity: { containing_entity_id: ce.entity.entity_id, entity_name: 'model' }, entity_property: {} }, (err, rslt) => {
        clb(err, { ...colLc, model: rslt });
      });
    },
    function (colLCM, clb) {
      getEntityProperty({ entity: { containing_entity_id: ce.entity.entity_id, entity_name: 'view' }, entity_property: {} }, (err, rslt) => {
        clb(err, { ...colLCM, view: rslt });
      });
    },
    function (colLCMV, clb) {
      // form
      let form = writeForm(colLCMV);                    // controller elements, view elements      
    },
    function (colLCMVF, clb) {
      // filter
      // let filter = writeForm(ce);             // controller elements, view elements
    },
    function (colLCMVFF, clb) {
      // pagination
      // let pagination = writePagination(ce);   // controller elements, view elements
    },
    function (colLCMVFFP, clb) {
      // table
      // let table = writeForm(ce);              // controller elements, view elements
    },
    function (colLMCMVFFPT, clb) {
      // layout, add empty elements
    }
  ], (err, rslt) => {

  });
}

function writeForm(ce) {
  // write form op
  let addRecord = _.find(ce.controller.child, { entity_name: 'create' });
  let updateRecord = _.find(ce.controller.child, { entity_name: 'update' });
  let controller = [];
  let formElement = [];
  async.concat(ce.column_list, (col, asyFrmClb) => {
    col = getEntityProperty({ entity: { entity_id: col.entity.containing_entity_id }, entity_property: {} }, (err, dbCol) => {
      asyFrmClb(err, writeFormField(dbCol));
    });
  });
  // write field data source to controller ops
  // write form data source to controller ops
  // write component to controller ops
  // form grid
}

function writeFormField() {
  // html element, type
}

function writeFilter() {

}

function writeGrid() {
  // component, html element
}

function writeTable() {
  // component, html element
}

function writeAlert() {
  // component, html element
}

function writeNav() {
  // component, html element
}

function writePagination() {

}

function runCommand(commandObj) {
  let opMaps = getOpsList();
  let op_map = _.filter(opMaps, { op_name: ' ' })[0];
  if (_.isEmpty(op_map)) {
    console.log('Error: Invalid Operator!');
    prompt();
    return;
  }
  let c_file = op_map.op_file;
  try {
    let obj = require(c_file);
    let method = op_map.op_method;
    obj[method]((err, rslt) => { console.log(rslt); });
  } catch (e) {
    console.log(e);
    console.log('Error: Operator Not Found!');
    return;
  }
}
