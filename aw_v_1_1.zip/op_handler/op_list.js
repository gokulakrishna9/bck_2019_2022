let _ = require('lodash');

let opMapFolders = {
  db_ops: [
    './html_component/op_list',
    //'./mvc_op/op_list',
    //'./labeler_op/op_list'
    //'./scaff_op/op_map',
    //'./mvc_op/op_map'
  ]
};

exports.getOPMapFolders = function () {
  return opMapFolders;
}

exports.getOpsList = function () {
  let opMp = opMapFolders;
  let ops = [];
  _.forEach(opMp, (opfiles, op_type) => {
    // require call op_map method
    _.forEach(opfiles, (opfile) => {
      let opFile = require(opfile);               // dynamic load, require function
      ops.push(...opFile.getOps());
    });
  });
  return ops;
}