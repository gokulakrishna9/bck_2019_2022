function grid(stmt_list) {
  // container, row, col
  let stmtList = {};
  let rowStart = _.template(`<div class="w3-row <%= class %>">`);
  let rowEnd = _.template(`</div>`);
  let colStart = _.template(`<div class="w3-col <%= col_class %> \\<%= class \\%>"  \\<%= property \\%>>`);
  let colEnd = _.template(`</div>`);
  let cols = 0;
  // find col_sizes that aproximate to 12, if so add to row list
  let row = [];
  let r = [];
  let col = 0;
  let rem = 12;
  _.forEach(stmt_list, (colEl, i) => {
    col += colEl.col_size;
    if (col == 0 || col <= 12) {
      rem -= colEl.col_size;
      r.push(colEl);
    } else {
      col = 0;
      r.push({ property_name: 'remaining_col', property_value: rem });
      row.push(r);
      r = [];
      r.push(colEl);
    }
  });
  _.forEach(row, (cols, i) => {
    stmtList = { 1: { param_list: ['class'], template: rowStart, html_element_list: ['div'] } };
    let rem = _.find(cols, { property_name: 'remaining_col' });
    _.forEach(cols, (col) => {
      let size = col.col_size;
      if (size < 3 && rem.property_value > 0) {
        size += 1;
        rem -= 1;
      }
      let colCls = 'l' + size;
      if (size > 7 && !col.fixed)     // Note the fixed attribute
        colCls += ' ' + 'm12';
      else if (size > 7 && col.fixed)
        colCls += ' m' + size + ' s12';
      else if (size < 3)
        colCls += ' m' + size + ' s6';
      else
        colCls += ' m' + size + ' s12';
      stmtList.push({ param_list: ['class', 'property'], template: ('`' + colStart({ col_class: col.col_size })) + '`', html_element_list: ['div'] });
      _.forEach(col.element_list, (el) => {
        stmtList.push(el);
      });
      stmtList.push({ param_list: [], template: colEnd, html_element_list: [] });
    });
    stmtList.push({ param_list: [], template: rowEnd, html_element_list: [] });
  });
}