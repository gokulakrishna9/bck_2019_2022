function navbarHeaderLeft(stmt_list) {
  // add grid size here
  // op_list{group_label, op_name, op_label, framework_op_string, op_header_label, sort_order}
  let op_list = _.filter(stmt_list, { group_label: 'nav_operator' });
  let navList = _.groupBy(op_list, (op) => {
    return op.op_header_label;
  });
  let stmt = [];
  let navStart = _.template(`<div class="w3-bar \\<%= class \\%>"  \\<%= property \\%>>`);
  let navEnd = _.template(`</div>`);
  let link = _.template(`<a href="<%= framework_op_string %>" class="w3-bar-item w3-button \\<%= class \\%>"  \\<%= property \\%>><%= header_label %></a>`);
  
  // array{of objects} of arrays with header and nav_list
}