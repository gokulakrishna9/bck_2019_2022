
function form() {
  // for each column, figure out column element, column type
}

function filter() {
  // for each column, figure out column element, column type
}