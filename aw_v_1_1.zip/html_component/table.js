
function queryWriter() {
  // let form calculate grid size
}

function report() {

}