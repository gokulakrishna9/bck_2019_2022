let _ = require('lodash');
// read the templates and populate the DB with template properties
// have a file with all config methods
// Model start template
let modelOpeningTmpl = _.template(`<?php class <%= model_name %>_model extends CI_Model {`);
let modelClosingTmpl = _.template(`}`);
// Model end template
// Method start template
let methodOpening = _.template(`<%= outer_tab %>function <%=method_name%>(<%=param_list%>) {`);
let methodClosing = _.template(`<%= outer_tab %>}`);
// Method end template
// array declaration start
let arrayDeclaration = _.template(`<%= inner_tab %>$<%= array_name %> = [];`);
// array declaration end
// s- sessMstTmpl
let sessMstTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = $this->session->has_userdata('<%= property_name %>') ? $this->session->userdata('<%= property_name %>') : $<%= array_name %>['<%= column_name %>'];`);
// e- sessMstTmpl
// s- post sess temp
let postSessTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = is_null($this->input->post('<%= value_variable %>')) ? $<%= array_name %>['<%= column_name %>'] : $this->input->post('<%= value_variable %>');`);
// e- post sess temp
// s- setSessTmpl
let setSessTmpl = _.template(`<%= inner_tab %>$this->session->set_userdata('<%= column_name %>', $<%= array_name %>['<%= column_name %>']);`);
// e- setSessTmpl
// s- postTmpl
let postTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = is_null($this->input->post('<%= value_variable %>')) ? '' : $this->input->post('<%= value_variable %>');`);
// e- postTmpl
// s- datetimeModTmpl
let datetimeModTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = empty($<%= array_name %>['<%= column_name %>']) ? '23:59' : date("Y-m-d H:i", strtotime($<%= array_name %>['<%= column_name %>']));`);
// e- datetimeModTmpl
// s- dateModTmpl
let dateModTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = empty($<%= array_name %>['<%= column_name %>']) ? date("Y-m-d") : date("Y-m-d", strtotime($<%= array_name %>['<%= column_name %>']));`);
// e- dateModTmpl
// s- timeModTmpl
let timeModTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = empty($<%= array_name %>['<%= column_name %>']) ? '23:59' : date("H:i", strtotime($<%= array_name %>['<%= column_name %>']));`);
// e- timeModTmpl
// s- insertTmpl
let insertTmpl = _.template(`<%= inner_tab %>$this->db->insert('<%= table_name %>', $<%= data_array_name %>);`);
let returnInsertTmpl = _.template(`<%= inner_tab %>return array('insert_id' => $this->db->insert_id(), 'input_data' => $<%= array_name %>, success => true);`);

exports.pipelineObj = {
  add_record: [{method_name: writeCreate, description: '', search_term: [], default: true}],
  update_record: [{method_name: writeUpdate, description: '', search_term: [], default: true}],
  delete_record: [{method_name: writeDelete, description: '', search_term: [], default: true}],
  read_record: [{method_name: writeGet, description: '',  search_term: [], default: true}],
  grouping_record: [{method_name: groupingGet, description: '',  search_term: [], default: true}]
}

exports.writeController = function(codeEntityList, op, scope) {
  // find active op list
  // look for not found op list in other map file
}

function writeCreate() {
  // validation, model method
}

function writeUpdate() {
  // validation, model method
}

function writeDelete() {
  // validation, model method
}

function writeGet() {
  // validation, model method
}

function groupGet() {
  
}