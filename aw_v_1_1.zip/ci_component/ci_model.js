let _ = require('lodash');
let { findEnt, entityProperty, stepIntoSearch, findEntProp, findEntWithProp, findParentComponent, rvStepSearchScope, getScope } = require('../helper_op/search');
let { isObjectEmpty } = require('../helper_op/object');
let { entityProperty } = require('../helper_op/search');
//let { tabSpaces, ucFirst, splitCapitalize, toLower } = require('../helper_functions/string_function');
//let { writeFile } = require('../helper_functions/write_to_file');

// HAVE ABILITY TO ACT ON COLUMNS, APPLYING DATE, FORMATTING etc...
let modelTemplate = {
  method_opening: _.template(`function <%=method_name%>(<%=param_list%>) {`),
  method_closing: _.template(`}`),
  php_empty_variable: _.template(`$<%=variable_name%> = '';`),
  php_empty_array: _.template(`$<%= array_name %> = [];`),
  post: _.template(`$<%= array_name %>['<%= column_name %>'] = is_null($this->input->post('<%= value_variable %>')) ? '' : $this->input->post('<%= value_variable %>');`),
  get: _.template(`$<%= array_name %>['<%= column_name %>'] = is_null($this->input->get('<%= value_variable %>')) ? '' : $this->input->get('<%= value_variable %>');`),
  insert: _.template(`$this->db->insert('<%= table_name %>', $<%= data_array_name %>);`),
  return_insert: _.template(`return array('insert_id' => $this->db->insert_id(), 'input_data' => $<%= array_name %>);`),
  return_update: _.template(`return array('insert_id' => $this->db->affected_rows(), 'input_data' => $<%= array_name %>);`),
  field_op: _.template(`$<%= array_name %>[<%= field_name %>] = <%= op_name %>($<%= field_name %>);`),
  php_array_intialization: _.template(`$<%= array_name %> = array(<%= array_elements %>);`),
  array_exp: _.template(`array(<%= array_elements %>)`),
  array_element: _.template(`'<%= column_name %>' => $<%= value_variable %>`),
  array_assignment: _.template(`$<%= array_name %>['<%= column_name %>'] = $<%= value_variable %>;`),
  select: _.template(`$this->db->select('<%= columns_list %>')->from('<%= table_name %>');`),
  select_column: _.template(`<%= multi_line_string %><%=table_name%>.<%=column_name%> AS <%=column_label%>`),
  join: _.template(`$this->db->join('<%= join_table %>', '<%= join_on %>', '<%= join_type %>');`),
  get_query_result: _.template(`$qry = $this->db->get();`),
  return_query_result: _.template(`return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`),
  update: _.template(`$this->db->update('<%= table_name %>', $<%= data_array_name %>, array(<%= filter_element %>));`),
  where: _.template(`$this->db->where('<%= field_name %>', $<%= field_value_variable %>);`),
  where_array: _.template(`$this->db->where($<%= filter_array %>);`),
  delete: _.template(`$this->db->delete('<%= table_name %>', array(<%= filter_element %>));`),
  group_by: _.template(`$this->db->group_by($<%= table_name_column_name %>);`),
  order_by: _.template(`$this->db->order_by('<%= table_name_column_name %>', '<%= sorting %>');`),
  // The HAVING clause is often used with the GROUP BY clause to filter groups based on a specified condition. 
  // If the GROUP BY clause is omitted, the HAVING clause behaves like the WHERE clause.
  having: _.template(`$this->db->having('<%= table_name_column_name %>');`),
  return: _.template(`return $rslt;`),
  model_opening: _.template(`<?php class <%=table_name %>_model extends CI_Model {`),
  model_closing: _.template(`}`),
  if_open: _.template(`if(exp){`),
  if_close: _.template('}'),
  post_exp: _.template(`!is_null($this->input->post('<%= value_variable %>')`),
  data_array_session: _.template(`$<%= array_name %>['<%= column_name %>'] = $this->session->has_userdata('<%= key_name %>') ? $this->session->userdata('<%= key_name %>') : '';`),
  set_session_data: _.template(`$this->session->set_userdata('<%= column_name %>', $<%= array_name %>['<%= column_name %>']);`),
  field_op: _.template(`$<%= array_name %>[<%= field_name %>] = <%= op_name %>($<%= field_name %>);`),
  date_format: _.template(`$<%= array_name %>['<%= field_name %>'] = empty($<%= array_name %>['<%= field_name %>']) ? date("Y-m-d") : date("Y-m-d", strtotime($<%= array_name %>['<%= field_name %>']))`),
  time_format: _.template(`$<%= array_name %>['<%= field_name %>'] = empty($<%= array_name %>['<%= field_name %>']) ? '23:59' : date("H:i", strtotime($<%= array_name %>['<%= field_name %>']))`),
  date_time_format: _.template(`$<%= array_name %>['<%= field_name %>'] = empty($<%= array_name %>['<%= field_name %>']) ? date("Y-m-d H:i") : date("Y-m-d H:i", strtotime($<%= array_name %>['<%= field_name %>']))`)
}

let pipelineObj = function () {
  return [
    { method_name: componentDefault, description: '', search_term: ['component_default'], default: true },
    { method_name: wCreateMethod, description: '', search_term: ['default_input'], default: true },
    { method_name: wUpdateMethod, description: '', search_term: ['default_update'], default: true },
    { method_name: wDeleteMethod, description: '', search_term: ['default_delete_record'], default: true },
    { method_name: wSelectMethod, description: '', search_term: ['default_get_data'], default: true },
    { method_name: wGroupGet, description: '', search_term: ['default_grouping_record'], default: true }
  ];
};

// add all additional details to op only
exports.wComponentMethod = function (applicationDb, component, scopeData) {
  // component{component, operator_list}
  // load templates file, templates file takes precedence over hard coded templates
  // unless specified in {properties file}
  // invoke each of the methods
  // if method not found here, look for it in files and load
  // db_list: dbList, table_list: tableList, column_list: columnList, code_entity_list: rslt, relation_list 
  //console.log(methodFunction);
  let colL = columnList(applicationDb.column_list, scopeData.column_list);
  colL = getColumnComponent(colL);
  let methodStmts = [];
  _.forEach(component.operator_list, (op) => {
    let opF = _.find(op.entity_property, { property_name: 'operator_name' }).property_value;
    let methodFunction = _.find(pipelineObj(), (po) => {
      return _.includes(po.search_term, opF);
    });
    methodStmts.push(methodFunction.method_name(applicationDb, scopeData, colL, op));
  });
}

function columnList(allCols, refColumnList) {
  let colLst = _.map(refColumnList, (col) => {
    let refP = entityProperty(col).parent_component;
    return { col_component: findEnt(allCols, { record_id: refP })[0], ref: col.entity.record_id };
  });
  return colLst;
}

function getColumnComponent(colLst) {
  let colL = _.map(colLst, (col) => {
    console.log(col);
    // column_type, column_size, column_key, column_name, table_name
    let column_type = entityProperty(col.col_component).column_type;
    if (column_type == 'int' || column_type == 'decimal' || column_type == 'double' ||
      column_type == 'float' || column_type == 'smallint' || column_type == 'bigint' ||
      column_type == 'tinyint' || column_type == 'tinytext' || column_type == 'varchar' ||
      column_type == 'text' || column_type == 'char' || column_type == 'binary' || column_type == 'mediumtext' || column_type == 'longtext') {
      return {
        column_entity: col.col_component,
        parent_entity: {
          entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [[0, 0, 0, 0, 'property', 'parent_component', 'ref', 'table', col.ref]]
        },
        child_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'template', 'string', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'post']
            ]
          }
        ]
      };
      // {input, number}
    } else if (column_type == 'date') {
      // {input, date}
      return {
        column_entity: col.col_component,
        parent_entity: {
          entity: [[0, 0, col.ref, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'table', col.ref]
          ]
        },
        child_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'post']
            ]
          },
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'date_format']
            ]
          }
        ]
      };
    } else if (column_type == 'time') {
      // {input, time}
      return {
        column_entity: col.col_component,
        parent_entity: {
          entity: [[0, 0, col.ref, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'table', col.ref]
          ]
        },
        child_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'post']
            ]
          },
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'time_format']
            ]
          }
        ]
      };
    } else if (column_type == 'datetime') {
      // {input, datetime-local}
      return {
        column_entity: col.col_component,
        parent_entity: {
          entity: [[0, 0, col.ref, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'table', col.ref]
          ]
        },
        child_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'post']
            ]
          },
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'date_time_format']
            ]
          }
        ]
      };
    } else if (column_type == 'timestamp') {
      // {input, datetime-local}, actually disable timestamp
      return {
        column_entity: col.col_component,
        parent_entity: {
          entity: [[0, 0, col.ref, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [
            [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'column', col.ref]
          ]
        },
        child_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'post']
            ]
          },
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'date_time_format']
            ]
          }
        ]
      };
    }
  });
  return colL;
}

function componentDefault(methodTemplateList) {

}
// statement group{group_opening, group_closing, statement_list, sort_order}, 
// statement{template, template properties, sort_order}
function wCreateMethod(applicationDb, scopeData, colL, op) {
  console.log('Create Method');
  let statementGroup = {
    parent_entity: {
      entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
      entity_property: [
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_opening'],
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_closing'],
        [0, 0, 0, 0, 'property', '', 'int', 'sort_order', 0],
      ]
    },
    child_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array']
        ]
      }
    ]
  };
  _.forEach(colL, (col) => {
    // col{parent_entity, child_entity, column_entity}
    let eP = entityProperty(col.column_entity);
    if (eP.column_key == 'PRI')
      return;
    // has own property
    statementGroup.child_entity.push({ parent_entity: col.parent_entity, child_entity: col.child_entity });
  });
  // insert data
  // return data, and insert id
  statementGroup.child_entity.push({
    entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
    entity_property: [
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'insert'],
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'return_insert'],
    ]
  });
  return statementGroup;
}

function wUpdateMethod(applicationDb, scopeData, colL, op) {
  console.log('Update Method');
  let statementGroup = {
    parent_entity: {
      entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
      entity_property: [
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_opening'],
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_closing'],
        [0, 0, 0, 0, 'property', '', 'int', 'sort_order', 0],
      ]
    },
    child_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array']
        ]
      }
    ]
  };
  _.forEach(colL, (col) => {
    // col{parent_entity, child_entity, column_entity}
    let eP = entityProperty(col.column_entity);
    if (eP.column_key == 'PRI') {
      // change array name to filter
      statementGroup.child_entity.push({
        parent_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array'],
              [0, 0, 0, 0, 'property', 'template_property', 'string', 'array_name', 'update_filter']
            ]
          }
        ],
        child_entity: [
          {parent_entity: col.parent_entity, child_entity: col.child_entity}
        ]
      });
      return;
    }
    // has own property
    statementGroup.child_entity.push({ parent_entity: col.parent_entity, child_entity: col.child_entity });
  });
  // insert data
  // return data, and insert id
  statementGroup.child_entity.push({
    entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
    entity_property: [
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'insert'],
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'return_insert'],
    ]
  });
  return statementGroup;
}

function wDeleteMethod(applicationDb, scopeData, colL, op) {
  console.log('Delete Method');
  let statementGroup = {
    parent_entity: {
      entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
      entity_property: [
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_opening'],
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_closing'],
        [0, 0, 0, 0, 'property', '', 'int', 'sort_order', 0],
      ]
    },
    child_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array']
        ]
      }
    ]
  };
  _.forEach(colL, (col) => {
    // col{parent_entity, child_entity, column_entity}
    let eP = entityProperty(col.column_entity);
    if (eP.column_key == 'PRI') {
      // change array name to filter
      statementGroup.child_entity.push({
        entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array'],
          [0, 0, 0, 0, 'property', 'template_property', 'string', 'array_name', 'delete_filter']
        ]
      });
      return false;
    }
  });
  statementGroup.child_entity.push({
    entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
    entity_property: [
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'delete'],
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'return_delete'],
    ]
  });
  return statementGroup;
}

function wSelectMethod(applicationDb, scopeData, colL, op) {
  // table is the head of relation entity
  console.log('Select Method');
  let statementGroup = {
    parent_entity: {
      entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
      entity_property: [
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_opening'],
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_closing'],
        [0, 0, 0, 0, 'property', '', 'int', 'sort_order', 0],
      ]
    },
    child_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array']
        ]
      }
    ]
  };
  _.forEach(colL, (col) => {
    // col{parent_entity, child_entity, column_entity}
    let eP = entityProperty(col.column_entity);
    if (eP.column_label) {
      // change array name to filter
      statementGroup.child_entity.push({
        parent_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array'],
              [0, 0, 0, 0, 'property', 'template_property', 'string', 'array_name', 'select_filter']
            ]
          }
        ],
        child_entity: [
          {parent_entity: [col.parent_entity], child_entity: [col.child_entity]}
        ]
      });
    }
    // has own property
    statementGroup.child_entity.push(
      {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [[0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'select']]
        }], 
        child_entity: [
          { 
            parent_entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            child_entity: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'select_column'],
              [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'column', col.ref]
            ]
          }
        ]
      }
    );
  });
  // insert data
  // return data, and insert id
  statementGroup.child_entity.push({
    entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
    entity_property: [
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'get_query_result'],
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'return_query_result'],
    ]
  });
  return statementGroup;
}

function selectColumn(colL) {
  // master_table_name: mst.table_name, master_column_name: mst.column_name, master_label_column: mstCol.
  // column_name, label_column
  // entityProperty
  // select_column: _.template(`<%=table_name%>.<%=column_name%> AS <%=column_label%>`),
  let selectElem = [];
  let chunkSize = 3;
  _.forEach(colL, (col) => {
    // add master label column
    // master_table_name: mst.table_name, master_column_name: mst.column_name, 
    // master_label_column: mstCol.column_name
    if (col.hasOwnProperty('master_table_name')) {
      selectElem.push({
        template: modelTemplate.select_column,
        property_list: { ...col.property_list, table_name: col.master_table_name, column_name: col.master_table_name + '.' + col.master_label_column, column_label: 'label_column_' + col.master_label_column },
        sort_order: 0
      });
    }
    selectElem.push({ template: modelTemplate.select_column, property_list: col.property_list, sort_order: 0 });
  });
  // chunk, concat, flatten, multi_line_string: '\t\t'
  selectElem = _.map(selectElem, (se, index) => {
    if (index >= chunkSize && index % chunkSize == 0) {
      return { multi_line_string: '\t\t', ...se };
    }
    return { multi_line_string: ' ', ...se };
  });
  // select: _.template(`$this->db->select('<%= columns_list %>')->from('<%= table_name %>');`),
  return {
    template: modelTemplate.select,
    property_list: {
      column_list: [...selectElem],
      table_name: colL[0].table_name
    }
  }
}

function joinList(colL) {
  // get from column list
  let joinStmt = [];
  /*
  join: _.template(`$this->db->join('<%= join_table %>', '<%= join_on %>', '<%= join_type %>');`),
  get_query_result: _.template(`$qry = $this->db->get();`),
  return_query_result: _.template(`return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`),
  */
  _.forEach(colL, (col) => {
    // add master label column
    // master_table_name: mst.table_name, master_column_name: mst.column_name, 
    // master_label_column: mstCol.column_name
    if (col.hasOwnProperty('master_table_name')) {
      joinStmt.push({
        template: modelTemplate.join,
        property_list: { ...col.property_list, join_table: col.master_table_name, join_on: col.master_table_name + '.' + col.master_column_name + '=' + col.table_name + '.' + col.column_name },
        sort_order: 0
      });
    }
  });
  joinStmt.push({ template: modelTemplate.get_query_result, property_list: {} });
  return joinStmt;
}

function wGroupGet(colL) {
  // get from column list
  console.log('Grouping Get Method');
  // table is the head of relation entity
  let statementGroup = {
    parent_entity: {
      entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
      entity_property: [
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_opening', 'method_opening'],
        [0, 0, 0, 0, 'property', 'template', 'string', 'block_closing', 'method_closing'],
        [0, 0, 0, 0, 'property', '', 'int', 'sort_order', 0],
      ]
    },
    child_entity: [
      {
        entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
        entity_property: [
          [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array']
        ]
      }
    ]
  };
  _.forEach(colL, (col) => {
    // col{parent_entity, child_entity, column_entity}
    let eP = entityProperty(col.column_entity);
    if (eP.hasOwnProperty('master_table_name')) {
      // group filter
      statementGroup.child_entity.push({
        parent_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array'],
              [0, 0, 0, 0, 'property', 'template_property', 'string', 'array_name', 'group_filter']
            ]
          }
        ],
        child_entity: [
          {parent_entity: [col.parent_entity], child_entity: [col.child_entity]}
        ]
      });
      // having filter
      statementGroup.child_entity.push({
        parent_entity: [
          {
            entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            entity_property: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'php_empty_array'],
              [0, 0, 0, 0, 'property', 'template_property', 'string', 'array_name', 'having_filter']
            ]
          }
        ],
        child_entity: [
          {parent_entity: [col.parent_entity], child_entity: [col.child_entity]}
        ]
      });
    }
    // select list
    statementGroup.child_entity.push(
      {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: [[0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'select']]
        }], 
        child_entity: [
          { 
            parent_entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            child_entity: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'select_column'],
              [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'column', col.ref]
            ]
          }
        ]
      }
    );
    // join list
    statementGroup.child_entity.push(
      {
        parent_entity: [{
          entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
          entity_property: []
        }], 
        child_entity: [
          { 
            parent_entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
            child_entity: [
              [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'join_on_column'],
              [0, 0, 0, 0, 'property', 'parent_component', 'ref', 'column', col.ref]
            ]
          }
        ]
      }
    );
  });
  statementGroup.child_entity.push({
    entity: [[0, 0, 0, 0, 'component', 'code_block', ' ', ' ', ' ']],
    entity_property: [
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'get_query_result'],
      [0, 0, 0, 0, 'property', 'template', 'string', 'template_name', 'return_query_result'],
    ]
  });
  return statementGroup;
}

function wColumnList(selArr) {
  // for select
}

function wRelations(entities, entity) {
  // for join
}

function wWhere() {

}

function wHaving() {

}

function wBuildGroup() {

}

function wWorkflowStatement() {

}

function fieldDefault(columnComp) {

}

function applyColumnSelectOp(column) {
  // global, method
}

function applyReturnOp(applicationDb, scopeData, colL, op) {
  // invoke op
}

exports.pipelineObj = pipelineObj;