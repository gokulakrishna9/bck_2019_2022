let _ = require('lodash');
let { findEnt, stepIntoSearch, findEntProp, findEntWithProp, findParentComponent, rvStepSearchScope, getScope } = require('../helper_op/search');
let { isObjectEmpty } = require('../helper_op/object');
let { entityProperty } = require('../helper_op/search');
//let { tabSpaces, ucFirst, splitCapitalize, toLower } = require('../helper_functions/string_function');
//let { writeFile } = require('../helper_functions/write_to_file');

// HAVE ABILITY TO ACT ON COLUMNS, APPLYING DATE, FORMATTING etc...
let modelTemplate = {
  method_opening: _.template(`function <%=method_name%>(<%=param_list%>) {`),
  method_closing: _.template(`}`),
  php_empty_variable: _.template(`$<%=variable_name%> = '';`),
  php_empty_array: _.template(`$<%= array_name %> = [];`),
  post: _.template(`$<%= array_name %>['<%= column_name %>'] = is_null($this->input->post('<%= value_variable %>')) ? '' : $this->input->post('<%= value_variable %>');`),
  get: _.template(`$<%= array_name %>['<%= column_name %>'] = is_null($this->input->get('<%= value_variable %>')) ? '' : $this->input->get('<%= value_variable %>');`),
  insert: _.template(`$this->db->insert('<%= table_name %>', $<%= data_array_name %>);`),
  return_insert: _.template(`return array('insert_id' => $this->db->insert_id(), 'input_data' => $<%= array_name %>);`),
  return_update: _.template(`return array('insert_id' => $this->db->affected_rows(), 'input_data' => $<%= array_name %>);`),
  field_op: _.template(`$<%= array_name %>[<%= field_name %>] = <%= op_name %>($<%= field_name %>);`),
  php_array_intialization: _.template(`$<%= array_name %> = array(<%= array_elements %>);`),
  array_exp: _.template(`array(<%= array_elements %>)`),
  array_element: _.template(`'<%= column_name %>' => $<%= value_variable %>`),
  array_assignment: _.template(`$<%= array_name %>['<%= column_name %>'] = $<%= value_variable %>;`),
  select: _.template(`$this->db->select('<%= columns_list %>')->from('<%= table_name %>');`),
  select_column: _.template(`<%= multi_line_string %><%=table_name%>.<%=column_name%> AS <%=column_label%>`),
  join: _.template(`$this->db->join('<%= join_table %>', '<%= join_on %>', '<%= join_type %>');`),
  get_query_result: _.template(`$qry = $this->db->get();`),
  return_query_result: _.template(`return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`),
  update: _.template(`$this->db->update('<%= table_name %>', $<%= data_array_name %>, array(<%= filter_element %>));`),
  where: _.template(`$this->db->where('<%= field_name %>', $<%= field_value_variable %>);`),
  where_array: _.template(`$this->db->where($<%= filter_array %>);`),
  delete: _.template(`$this->db->delete('<%= table_name %>', array(<%= filter_element %>));`),
  group_by: _.template(`$this->db->group_by($<%= table_name_column_name %>);`),
  order_by: _.template(`$this->db->order_by('<%= table_name_column_name %>', '<%= sorting %>');`),
  // The HAVING clause is often used with the GROUP BY clause to filter groups based on a specified condition. 
  // If the GROUP BY clause is omitted, the HAVING clause behaves like the WHERE clause.
  having: _.template(`$this->db->having('<%= table_name_column_name %>');`),
  return: _.template(`return $rslt;`),
  model_opening: _.template(`<?php class <%=table_name %>_model extends CI_Model {`),
  model_closing: _.template(`}`),
  if_open: _.template(`if(exp){`),
  if_close: _.template('}'),
  post_exp: _.template(`!is_null($this->input->post('<%= value_variable %>')`)
}
let workFlowTemplate = {
  data_array_session: _.template(`$<%= array_name %>['<%= column_name %>'] = $this->session->has_userdata('<%= key_name %>') ? $this->session->userdata('<%= key_name %>') : '';`),
  set_session_data: _.template(`$this->session->set_userdata('<%= column_name %>', $<%= array_name %>['<%= column_name %>']);`)
}
let fieldOpTemplate = {
  field_op: _.template(`$<%= array_name %>[<%= field_name %>] = <%= op_name %>($<%= field_name %>);`),
  date_format: _.template(`$<%= array_name %>['<%= field_name %>'] = empty($<%= array_name %>['<%= field_name %>']) ? date("Y-m-d") : date("Y-m-d", strtotime($<%= array_name %>['<%= field_name %>']))`),
  time_format: _.template(`$<%= array_name %>['<%= field_name %>'] = empty($<%= array_name %>['<%= field_name %>']) ? '23:59' : date("H:i", strtotime($<%= array_name %>['<%= field_name %>']))`),
  date_time_format: _.template(`$<%= array_name %>['<%= field_name %>'] = empty($<%= array_name %>['<%= field_name %>']) ? date("Y-m-d H:i") : date("Y-m-d H:i", strtotime($<%= array_name %>['<%= field_name %>']))`)
}

let pipelineObj = function () {
  return [
    { method_name: componentDefault, description: '', search_term: ['component_default'], default: true },
    { method_name: wCreateMethod, description: '', search_term: ['default_input'], default: true },
    { method_name: wUpdateMethod, description: '', search_term: ['default_update'], default: true },
    { method_name: wDeleteMethod, description: '', search_term: ['default_delete_record'], default: true },
    { method_name: wSelectMethod, description: '', search_term: ['default_get_data'], default: true },
    { method_name: wGroupGet, description: '', search_term: ['default_grouping_record'], default: true }
  ];
};

// add all additional details to op only
exports.wComponentMethod = function (applicationDb, component, scopeData) {
  // component{component, operator_list}
  // load templates file, templates file takes precedence over hard coded templates
  // unless specified in {properties file}
  // invoke each of the methods
  // if method not found here, look for it in files and load
  // db_list: dbList, table_list: tableList, column_list: columnList, code_entity_list: rslt, relation_list 
  //console.log(methodFunction);
  let colL = getColumnComponent(applicationDb.column_list, scopeData.column_list);
  let methodStmts = [];
  _.forEach(component.operator_list, (op) => {
    let opF = _.find(op.entity_property, { property_name: 'operator_name' }).property_value;
    let methodFunction = _.find(pipelineObj(), (po) => {
      return _.includes(po.search_term, opF);
    });
    methodStmts.push(methodFunction.method_name(applicationDb, scopeData, colL, op));
  });
}

function getColumnComponent(allCols, columnList) {
  // get columns
  let colLst = _.map(columnList, (col) => {
    let refP = _.find(col.entity_property, { entity_name: 'parent_component', property_type: 'ref', property_name: 'column' });
    return { component: findEnt(allCols, { record_id: refP.property_value })[0], ref: col };
  });

  // {...col, template:  modelTemplate.method_opening, property_list: {array_name: table_name+'_data', column_name: column_name, value_variable: column_name}, sort_order: 0, component_property: {column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label} },
  colLst = _.map(colLst, (col) => {
    console.log(col);
    // column_type, column_size, column_key, column_name, table_name
    let column_type = _.find(col.component.entity_property, { property_name: 'column_type' }).property_value;
    let column_name = _.find(col.component.entity_property, { property_name: 'column_name' }).property_value;
    let table_name = _.find(col.component.entity_property, { property_name: 'table_name' }).property_value;
    let column_key = _.find(col.component.entity_property, { property_name: 'column_key' }).property_value;
    let column_size = _.find(col.component.entity_property, { property_name: 'column_size' }).property_value;
    let column_label = _.find(col.component.entity_property, { property_name: 'column_label' }).property_value;
    if (column_type == 'int') {
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
      // {input, number}
    } else if (column_type == 'decimal') {
      // {input, number}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'double') {
      // {input, number}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'float') {
      // {input, number}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'smallint') {
      // {input, number}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'binary') {
      // radio
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'bigint') {
      // {input, number}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'tinyint') {
      // {input, number}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'tinytext') {
      // {input, text}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'varchar') {
      // {input, text}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'text') {
      // {input, text}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'char') {
      // {input, text}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'mediumtext') {
      // {input, text}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'longtext') {
      // {textarea, text}
      return { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } };
    } else if (column_type == 'date') {
      // {input, date}
      return {
        group_opening: {}, group_closing: {}, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label },
        statement_list: [
          { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 1 },
          { ...col, template: fieldOpTemplate.date_format, property_list: { array_name: table_name + '_data', column_name: column_name, field_name: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } },
        ]
      };
    } else if (column_type == 'time') {
      // {input, time}
      return {
        group_opening: {}, group_closing: {}, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label },
        statement_list: [
          { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 1 },
          { ...col, template: fieldOpTemplate.time_format, property_list: { array_name: table_name + '_data', column_name: column_name, field_name: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } },
        ]
      };
    } else if (column_type == 'datetime') {
      // {input, datetime-local}
      return {
        group_opening: {}, group_closing: {}, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label },
        statement_list: [
          { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 1 },
          { ...col, template: fieldOpTemplate.date_time_format, property_list: { array_name: table_name + '_data', column_name: column_name, field_name: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } },
        ]
      };
    } else if (column_type == 'timestamp') {
      // {input, datetime-local}, actually disable timestamp
      return {
        group_opening: {}, group_closing: {}, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label },
        statement_list: [
          { ...col, template: modelTemplate.post, property_list: { array_name: table_name + '_data', column_name: column_name, value_variable: column_name }, sort_order: 1 },
          { ...col, template: fieldOpTemplate.date_time_format, property_list: { array_name: table_name + '_data', column_name: column_name, field_name: column_name }, sort_order: 0, component_property: { column_key: column_key, column_name: column_name, table_name: table_name, column_size: column_size, column_label: column_label } },
        ]
      };
    }
  });
  return colLst;
}

function componentDefault(methodTemplateList) {

}
// statement group{group_opening, group_closing, statement_list, sort_order}, 
// statement{template, template properties, sort_order}
function wCreateMethod(applicationDb, scopeData, colL, op) {
  console.log('Create Method');
  let statementGroup = {
    group_opening: { template: modelTemplate.method_opening, property_list: { method_name: colL[0].table_name + '_create_record', param_list: ' ' }, sort_order: 0 },
    statement_list: [],
    group_closing: { template: modelTemplate.method_closing, property_list: {}, sort_order: 0 },
    sort_order: 0
  };
  // array initialization
  statementGroup.statement_list.push({ template: modelTemplate.php_empty_array, property_list: { array_name: colL[0].table_name + '_data' }, sort_order: 0 });
  // input array
  _.forEach(colL, (col) => {
    if (col.component_property.column_key == 'PRI')
      return;
    // has own property
    if (col.hasOwnProperty('statement_list')) {
      _.forEach(col.statement_list, (stmt) => {
        statementGroup.statement_list.push({ template: stmt.template, property_list: stmt.property_list, sort_order: stmt.sort_order });
      });
    } else {
      statementGroup.statement_list.push({ template: col.template, property_list: col.property_list, sort_order: col.sort_order });
    }
  });
  console.log(statementGroup.statement_list);
  // insert data
  // return data, and insert id
  statementGroup.statement_list.push({
    group_opening: {},
    group_closing: {},
    statement_list: [
      { template: modelTemplate.insert, property_list: { table_name: colL[0].table_name, data_array_name: colL[0].table_name + '_data' }, sort_order: 0 },
      { template: modelTemplate.return_insert, property_list: { input_data: colL[0].table_name + '_data' }, sort_order: 1 },
    ],
    sort_order: 0
  });
  console.log(statementGroup);
  return statementGroup;
}

function wUpdateMethod(applicationDb, scopeData, colL, op) {
  console.log('Update Method');
  let statementGroup = {
    group_opening: { template: modelTemplate.method_opening, property_list: { method_name: colL[0].table_name + '_create_record', param_list: ' ' }, sort_order: 0 },
    statement_list: [],
    group_closing: { template: modelTemplate.method_closing, property_list: {}, sort_order: 0 },
    sort_order: 0
  };
  // array initialization
  statementGroup.statement_list.push({ template: modelTemplate.php_empty_array, property_list: { array_name: colL[0].table_name + '_data' }, sort_order: 0 });
  // input array
  _.forEach(colL, (col) => {
    if (col.component_property.column_key == 'PRI') {
      // change array name to filter
      statementGroup.statement_list.push({ template: modelTemplate.php_empty_array, property_list: { array_name: colL[0].table_name + '_filter' }, sort_order: 0 });
      statementGroup.statement_list.push({ template: col.template, property_list: { ...col.property_list, array_name: colL[0].table_name + '_filter' }, sort_order: col.sort_order });
      return;
    }
    // has own property
    if (col.hasOwnProperty('statement_list')) {
      _.forEach(col.statement_list, (stmt) => {
        statementGroup.statement_list.push({ template: stmt.template, property_list: stmt.property_list, sort_order: stmt.sort_order });
      });
    } else {
      statementGroup.statement_list.push({ template: col.template, property_list: col.property_list, sort_order: col.sort_order });
    }
  });
  // insert data
  // return data, and insert id
  statementGroup.statement_list.push({
    group_opening: {},
    group_closing: {},
    statement_list: [
      { template: modelTemplate.update, property_list: { table_name: colL[0].table_name, data_array_name: colL[0].table_name + '_data', filter_element: colL[0].table_name + '_filter' }, sort_order: 0 },
      { template: modelTemplate.return_insert, property_list: { input_data: colL[0].table_name + '_data' }, sort_order: 1 },
    ],
    sort_order: 0
  });
  console.log(statementGroup);
  return statementGroup;
}

function wDeleteMethod(applicationDb, scopeData, colL, op) {
  console.log('Delete Method');
  let statementGroup = {
    group_opening: { template: modelTemplate.method_opening, property_list: { method_name: colL[0].table_name + '_delete_record', param_list: ' ' }, sort_order: 0 },
    statement_list: [],
    group_closing: { template: modelTemplate.method_closing, property_list: {}, sort_order: 0 },
    sort_order: 0
  };
  // input array
  _.forEach(colL, (col) => {
    if (col.component_property.column_key == 'PRI') {
      // change array name to filter
      statementGroup.statement_list.push({ template: modelTemplate.php_empty_array, property_list: { array_name: colL[0].table_name + '_filter' }, sort_order: 0 });
      statementGroup.statement_list.push({ template: col.template, property_list: { ...col.property_list, array_name: colL[0].table_name + '_filter' }, sort_order: col.sort_order });
      return false;
    }
  });
  // return data, and insert id
  statementGroup.statement_list.push({
    group_opening: {},
    group_closing: {},
    statement_list: [
      { template: modelTemplate.delete, property_list: { table_name: colL[0].table_name, data_array_name: colL[0].table_name + '_data', filter_element: colL[0].table_name + '_filter' }, sort_order: 0 },
      { template: modelTemplate.return_insert, property_list: { input_data: colL[0].table_name + '_data' }, sort_order: 1 },
    ],
    sort_order: 0
  });
  console.log(statementGroup);
  return statementGroup;
}

function wSelectMethod(applicationDb, scopeData, colL, op) {
  // table is the head of relation entity
  console.log('Select Method');
  // find filters from colL{add datetime, date, time fields to filter}
  let statementGroup = {
    group_opening: { template: modelTemplate.method_opening, property_list: { method_name: colL[0].table_name + '_select_record', param_list: ' ' }, sort_order: 0 },
    statement_list: [],
    group_closing: { template: modelTemplate.method_closing, property_list: {}, sort_order: 0 },
    sort_order: 0
  };
  // input array
  _.forEach(colL, (col) => {
    if (col.component_property.column_label) {
      // change array name to filter
      statementGroup.statement_list.push({ template: modelTemplate.php_empty_array, property_list: { array_name: colL[0].table_name + '_filter' }, sort_order: 0 });
      statementGroup.statement_list.push({ template: col.template, property_list: { ...col.property_list, array_name: colL[0].table_name + '_filter' }, sort_order: col.sort_order });
      return;
    }
  });
  // return data, and insert id
  statementGroup.statement_list.push({
    group_opening: {},
    group_closing: {},
    statement_list: [
      { template: modelTemplate.delete, property_list: { table_name: colL[0].table_name, data_array_name: colL[0].table_name + '_data', filter_element: colL[0].table_name + '_filter' }, sort_order: 0 },
      { template: modelTemplate.return_insert, property_list: { input_data: colL[0].table_name + '_data' }, sort_order: 1 },
    ],
    sort_order: 0
  });
  // select statement
  statementGroup.statement_list.push(selectColumn(colL));
  // join
  statementGroup.statement_list.push(joinList(colL));
  // where
  //where_array: _.template(`$this->db->where($<%= filter_array %>);`)
  statementGroup.statement_list.push({ template: modelTemplate.where_array, property_list: { filter_array: colL[0].table_name + '_filter' }, sort_order: 0 });
  console.log(statementGroup);
  // return select
  //get_query_result: _.template(`$qry = $this->db->get();`)
  //return_query_result: _.template(`return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`)
  statementGroup.statement_list.push({ template: modelTemplate.get_query_result, property_list: {}, sort_order: 0 });
  statementGroup.statement_list.push({ template: modelTemplate.return_query_result, property_list: { filter_array: colL[0].table_name + '_filter' }, sort_order: 0 });
  return statementGroup;
  // find relation_list from scopeData
  // write select statements
}

function selectColumn(colL) {
  // master_table_name: mst.table_name, master_column_name: mst.column_name, master_label_column: mstCol.
  // column_name, label_column
  // entityProperty
  // select_column: _.template(`<%=table_name%>.<%=column_name%> AS <%=column_label%>`),
  let selectElem = [];
  let chunkSize = 3;
  _.forEach(colL, (col) => {
    // add master label column
    // master_table_name: mst.table_name, master_column_name: mst.column_name, 
    // master_label_column: mstCol.column_name
    if (col.hasOwnProperty('master_table_name')) {
      selectElem.push({
        template: modelTemplate.select_column,
        property_list: { ...col.property_list, table_name: col.master_table_name, column_name: col.master_table_name + '.' + col.master_label_column, column_label: 'label_column_' + col.master_label_column },
        sort_order: 0
      });
    }
    selectElem.push({ template: modelTemplate.select_column, property_list: col.property_list, sort_order: 0 });
  });
  // chunk, concat, flatten, multi_line_string: '\t\t'
  selectElem = _.map(selectElem, (se, index) => {
    if (index >= chunkSize && index % chunkSize == 0) {
      return { multi_line_string: '\t\t', ...se };
    }
    return { multi_line_string: ' ', ...se };
  });
  // select: _.template(`$this->db->select('<%= columns_list %>')->from('<%= table_name %>');`),
  return {
    template: modelTemplate.select,
    property_list: {
      column_list: [...selectElem],
      table_name: colL[0].table_name
    }
  }
}

function joinList(colL) {
  // get from column list
  let joinStmt = [];
  /*
  join: _.template(`$this->db->join('<%= join_table %>', '<%= join_on %>', '<%= join_type %>');`),
  get_query_result: _.template(`$qry = $this->db->get();`),
  return_query_result: _.template(`return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`),
  */
  _.forEach(colL, (col) => {
    // add master label column
    // master_table_name: mst.table_name, master_column_name: mst.column_name, 
    // master_label_column: mstCol.column_name
    if (col.hasOwnProperty('master_table_name')) {
      joinStmt.push({
        template: modelTemplate.join,
        property_list: { ...col.property_list, join_table: col.master_table_name, join_on: col.master_table_name + '.' + col.master_column_name + '=' + col.table_name + '.' + col.column_name },
        sort_order: 0
      });
    }
  });
  joinStmt.push({ template: modelTemplate.get_query_result, property_list: {} });
  return joinStmt;
}

function wGroupGet(colL) {
  // get from column list
  console.log('Grouping Get Method');
  // method start
  let statementGroup = {
    group_opening: { template: modelTemplate.method_opening, property_list: { method_name: colL[0].table_name + '_group_get', param_list: ' ' }, sort_order: 0 },
    statement_list: [],
    group_closing: { template: modelTemplate.method_closing, property_list: {}, sort_order: 0 },
    sort_order: 0
  };
  // write the select statment
  // apply groups to groups
  let group = [];
  let select = [];
  let having = [];
  let join = [];
  let ifStmt = [];
  _.forEach(colL, (col) => {
    // add master label column
    // master_table_name: mst.table_name, master_column_name: mst.column_name, 
    // master_label_column: mstCol.column_name
    /*
      if_open: _.template(`if(<%= exp %>){`),
      if_close: _.template('}'),
      post_exp: _.template(`!is_null($this->input->post('<%= value_variable %>')`)
    */
    if (col.hasOwnProperty('master_table_name')) {
      ifStmt.push({
        group_opening: {
          template: modelTemplate.if_open,
          property_list: {
            exp: [{
              template: modelTemplate.not_null_exp, property_list: [
                {
                  template: modelTemplate.post_exp, property_list: {}, sort_order: 0
                }
              ], sort_order: 0
            }]
          },
          sort_order: 0
        },
        statement_list: [
          // get
          {
            template: '',
            property_list: {},
            sort_order: 0
          },
          // join,
          {
            template: '',
            property_list: {},
            sort_order: 0
          },
          // grouping,
          {
            template: '',
            property_list: {},
            sort_order: 0
          },
          // having
          {
            template: '',
            property_list: {},
            sort_order: 0
          }
        ],
        group_closing: { template: modelTemplate.if_close, property_list: {}, sort_order: 0 },
        sort_order: 0
      });
    }
  });
  // apply having filters
  // return data, and filters
  // method end
}

function wColumnList(selArr) {
  // for select
}

function wRelations(entities, entity) {
  // for join
}

function wWhere() {

}

function wHaving() {

}

function wBuildGroup() {

}

function wWorkflowStatement() {

}

function fieldDefault(columnComp) {

}

function applyColumnSelectOp(column) {
  // global, method
}

function applyReturnOp(applicationDb, scopeData, colL, op) {
  // invoke op
}

exports.pipelineObj = pipelineObj;