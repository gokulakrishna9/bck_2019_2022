let _ = require('lodash');
let async = require('async');
let { getEntityProperty } = require('../model/get_entity');
let { groupEntityByProperty, getScope, findEnt, findEntProp, stepIntoSearch, stepSearch, findEntWithProp, findParentComponent } = require('../helper_op/search');
let { isObjectEmpty } = require('../helper_op/object');
let { loadComponent } = require('../helper_op/load_component');
// require load_component
function writeCode(applicationDb) {
  // console.log(codeEntityList.code_entity_list.length);
  // console.log(codeEnt.length);
  // db_list: dbList, table_list: tableList, column_list: columnList, code_entity_list: rslt 
  let refOpLst = []
  entityOp(applicationDb.code_entity_list, (err, codeEntity) => {
    ///*
    _.forEach(codeEntity, (ce) => {
      //console.log('Op List');
      //console.log(ce);
      let dataPointOp = _.filter(ce.op_list, (oe) => {
        return _.filter(oe.entity_property, { property_type: 'data_point' }).length > 0;
      });
      let scopeOp = _.filter(ce.op_list, (oe) => {
        return _.filter(oe.entity_property, { property_type: 'scope' }).length > 0;
      });
      let refOp = _.filter(ce.op_list, (oe) => {
        return _.filter(oe.entity_property, { property_type: 'ref' }).length > 0;
      });
      refOpLst.push(...refOp);
      // group data point op by component
      // find entity with table name
      let cEScope = getScope(applicationDb.code_entity_list, ce.code_entity);
      // find columnList
      let opClL = findEnt(cEScope.child, {entity_name: 'column_list'})[0];
      let colLScp = getScope(applicationDb.code_entity_list, opClL);
      // GET the table object from ce
      let table = findEntProp(ce.code_entity, {entity_name: 'parent_component', property_name: 'table'});
      table = findEnt(applicationDb.table_list, {record_id: table.property_value});
      // Group all ops into components{going into recursion, assume syntax}
      // let opGroup = groupEntityByProperty(dataPointOp, 'containing_entity_id');
      /*
      console.log('Component Entity Scope');
      console.log(cEScope);
      console.log('Column List Entity');
      console.log(opClL);
      console.log('Column List Scope');
      console.log(colLScp);
      console.log('Table Entity');
      console.log(table);      
      */
      let scopeData = {table_component: table, column_list: colLScp.child};
      // Call components
      let component = findEnt(applicationDb.code_entity_list, {record_id: dataPointOp[0].entity[0].containing_entity_id})[0];
      let compObj = loadComponent(component.entity[0].entity_name);
      compObj[0]['wComponentMethod'](applicationDb, {component: component, operator_list: dataPointOp}, scopeData);
      /*
      console.log('Scope Op');
      _.forEach(scopeOp, (scOp) => {
        console.log(scOp);
      });
      console.log('Reference Op');
      _.forEach(refOp, (rOp) => {
        console.log(rOp);
      });
      //*/
    });
  });
  // get component list
  // get not ref methods in component list
  // call non ref methods 
  // call ref parent method
  // call ref parent method
  // ...
}

function entityOp(ceL, entOpClb) {
  let ceLst = findEnt(ceL, { entity_label: 'component', entity_name: 'code_entity' });
  async.concat(ceLst, (ce, asynClb) => {
    stepIntoSearch(
      0,
      ceL,
      [{ entity_label: 'component' }, { entity_label: 'operator' }],
      { record_id: ce.entity[0].record_id },
      (err, opL) => {
        let codeEntity = { code_entity: ce, op_list: opL };
        asynClb(null, codeEntity);
      }
    );
  }, (err, rslt) => {
    entOpClb(null, rslt);
  });
}

exports.writeCode = writeCode;