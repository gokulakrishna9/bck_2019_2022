let _ = require('lodash');

function coComponent(componentList) {
  let helpText = 'Console Ouput Component';
  _.forEach(componentList, (comp) => {
    console.log('Entity');
    console.log(comp.entity[0]);
    _.forEach(comp.entity_property, (prop) => {
      console.log('Entity Property');
      console.log(prop);
    });
  });
}

// filter component is taken as parent
function getComponentTree(filter) {

}


exports.coComponent = coComponent;

