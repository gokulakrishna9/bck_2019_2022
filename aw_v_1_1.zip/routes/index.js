var express = require('express');
var router = express.Router();
let { initialiseDbObjectList } = require('../model/db_scaffold');
let { getDatabaseList, getEntityProperty, getTransactionStatus } = require('../model/get_entity');
let { writeTransactionState, updateTransactionState } = require('../model/write_tree');
let async = require('async');
let _ = require('lodash');
let { makeid } = require('../helper_op/number');
const path = require('path');

router.get('/landing_page', (req, res, next) => {
  console.log('Landing Page');
  // long action
  async.waterfall([
    function (clbck) {
      // get db list
      getDatabaseList((err, rslt) => { clbck(err, { db_list: rslt }); });
    },
    function (rslt, clbck) {
      // get application list
      getEntityProperty({ entity_name: 'application' }, (err, rs) => { clbck(err, { ...rslt, application_list: rs }); });
    }
  ], (err, rslt) => {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(rslt));
  });
});

router.post('/get_entity', (req, res, next) => {
  console.log(req.body);
  getEntityProperty(req.body, (err, rs) => { 
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({result: rs, error: err}));
  });
});

router.get('/', (req, res, next) => { res.sendFile(path.join(__dirname, '../views/index.html')); });
router.post('/', (req, res, next) => { res.sendFile(path.join(__dirname, '../views/index.html')); });

router.post('/write_scaffold', (req, res, next) => {
  console.log('Request Body');
  console.log(req.body);
  if (Object.keys(req.body).length === 0 && req.body.constructor === Object) {
    clbck(null, null);
  } else {
    async.waterfall([
      function (clbck) {
        // write the transaction intialization to DB
        writeTransactionState(makeid(7), (err, rslt) => {
          console.log('Long Transaction record');
          console.log(rslt);
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(rslt));
          clbck(err, { t_state: rslt });
        });
      },
      function (rslt, clbck) {
        // write the scaffold        
        initialiseDbObjectList(req.body, (err, erModel) => { clbck(err, { ...rslt, erModel }); });
      },
      function (rslt, clbck) {
        // update the transaction initialization to DB
        let state = true;
        updateTransactionState(rslt.t_state, state, (err, rslt) => {
          clbck(err, rslt);
        });
      }
    ], (err, rslt) => {
      if (err) {
        console.log(err);
        let state = false;
        updateTransactionState(...rslt.t_state, state, (err, rslt) => {
          return;
        });
      } else {
        console.log('End of Long Transaction!');
      }
      return;
    });
  };
});

router.post('/status_long_action', (req, res, next) => {
  console.log('Long Action');
  console.log(req.body);
  getTransactionStatus(req.body, (err, rslt) => {
    console.log('Long Transaction');
    console.log(rslt);
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(rslt));
  });
});

router.post('/entity', function (req, res, next) {
  // update
  // add
});

router.post('/object_list', function (req, res, next) {
  res.send('Objects Currently in DB');
});

router.post('/write_scaffold', function (req, res, next) {
  // output req object

});

router.post('/add_object', function (req, res, next) {
  res.sent('Add Object');
});

router.post('/update_object', function (req, res, next) {
  res.send('Update Object');
});

router.post('/add_property', function (req, res, next) {
  res.send('Add Property');
});

router.post('/update_property', function (req, res, next) {
  res.send('Update Property');
});

router.post('/add_property_value', function (req, res, next) {
  res.send('Add Property Value');
});

router.post('/update_property_value', function (req, res, next) {
  res.send('Update Property Value');
});

router.post('/get_label_op_list', function (req, res, next) {
  res.sent('Get Label Operator List');
});

module.exports = router;