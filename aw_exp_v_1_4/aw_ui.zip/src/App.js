import logo from './logo.svg';
import './w3.css';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';

function App() {
  return (
    <div className='w3-container'>
      <div className='w3-row w3-indigo w3-padding-large w3-monospace'>
        <div className='w3-col m4'>
          <h3>Application Writer</h3>
        </div>
        <div className='w3-col m4'>
          <h4>Code Component</h4>
        </div>
        <div className='w3-col m4'>
          <h4>Application</h4>
        </div>
      </div>
      <div className='w3-row w3-monospace'>
        <div className='w3-col m2 w3-lime w3-padding-large w3-monospace'>
          <h5>Abstract Code Entity | Abstract Page</h5>
          <h5>Code Entity | Page</h5>
          <h5>Create Database</h5>
          <h5>Import Database</h5>
          <h5>Application Code Entity | Property | Connected Code Entity</h5>
        </div>
        <div className='w3-col m10'>
          <div className='w3-row'>
            Form
          </div>
          <div className='w3-row'>
            Table
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
