// framework folder name
exports.framework_map = function() {
  return [
    {
      component_name: 'controller',
      component_folder: '../ci_component',
      component_file: 'ci_controller',
      component_method: 'write_controller'
    },
    {
      component_name: 'model',
      component_folder: '../ci_component',
      component_file: 'ci_model',
      component_method: 'write_model'
    },
    {
      component_name: 'view',
      component_folder: '../ci_component',
      component_file: 'react_view',
      component_method: 'write_react_view'
    },
  ]
}