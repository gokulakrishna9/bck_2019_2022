let _ = require('lodash');
let async = require('async');
let { isObjectEmpty } = require('../helper_op/object');
// entity_list, {ent filter, child filter}
function findScopeObj(entityList, filter) {
  // find property, find property entity
  let entMatch = [];
  if (!(Object.keys(filter.entity_property).length === 0 && filter.entity_property.constructor === Object)) {
    entMatch = _.filter(entityList, (ent) => {
      return _.filter(ent.entity_property, filter.entity_property).length > 0;
    });
  }

  if (!(Object.keys(filter.entity).length === 0 && filter.entity.constructor === Object)) {
    if (entMatch.length == 0)
      entMatch = entityList;
    entMatch = _.filter(entMatch, (ent) => {
      return _.filter(ent.entity, filter.entity).length > 0;
    });
  }

  return entMatch;
}

function getScope(entityList, ele) {
  // filter, entitiy, entity parent
  if(isObjectEmpty(ele))
    return [];
  return {
    element: ele,
    parent: recursiveParent(entityList, ele), 
    child: childList(entityList, ele),
    sibling: findSibling(entityList, ele)
  };
}

function recursiveParent(entityList, ent) {
  let parent = [];
  let prn = findEnt(entityList, {record_id: ent.entity[0].containing_entity_id})[0];
  if(!isObjectEmpty(prn)) {
    parent.push(prn);
    parent.push(...recursiveParent(entityList, prn));
    return parent;
  } else {
    return [];
  }
}

function childList(entityList, ent) {
  let chl = findEnt(entityList, {containing_entity_id: ent.entity[0].record_id});  
  return chl;
}

function findSibling(entityList, ele) {
  return findEnt(entityList, {containing_entity_id: ele.entity[0].containing_entity_id});
}

function findEntProp(entity, filter = {}) {
  return _.find(entity.entity_property, filter);
}

function findEnt(entityLst, filter = {}) {
  let entFlt = _.filter(entityLst, (entity) => {
    return _.filter(entity.entity, filter).length > 0;
  });
  return entFlt;
}

function findEntWithProp(entityLst, filter = {}) {
  let entFlt = _.filter(entityLst, (entity) => {
    return _.filter(entity.entity_property, filter).length > 0;
  });
  return entFlt;
}

function entityChildList(entityList, filter) {
  let parentLst = _.filter(entityList, (ent) => {
    return _.filter(ent.entity, filter).length > 0;
  });
  let entChld = _.map(parentLst, (pl) => {
    return _.filter(entityList, (ent) => {
      return _.filter(ent.entity, { containing_entity_id: pl.entity[0].record_id }).length > 0;
    });
  });
  return _.flatten(entChld);
}

function stepSearch(entityList, filterSequence) {
  if (filterSequence.length < 0)
    return entityList;
  let match = _.filter(entityList, (ent) => {
    return _.filter(ent.entity, filterSequence[0]).length > 0;
  });
  filterSequence.splice(0, 1);
  if (!_.isEmpty(match) && filterSequence.length > 0) {
    let stepRslt = [];
    _.forEach(match, (mtch) => {
      filterSequence[0] = { ...filterSequence[0], containing_entity_id: mtch.entity[0].record_id };
      let fs = _.map(filterSequence, (fs) => { return fs; });
      let rslt = stepSearch(entityList, fs);
      if (rslt != undefined)
        stepRslt.push(...rslt);
    });
    return stepRslt;
  } else if (!_.isEmpty(match) && filterSequence.length == 0) {
    return match;
  } else {
    return [];
  }
}

// no break in pattern, create a scope object, {parent, child}pattern
function stepIntoSearch(depth, entityList, stepFilter, scope, stpIntoClbck) {
  // search first by the head
  let hstepFilter = [{ ...scope, ...stepFilter[0] }];
  for (let i = 1; i < stepFilter.length; i++) {
    hstepFilter.push(stepFilter[i]);
  }
  // 0'rth condition
  let entMtch = stepSearch(entityList, hstepFilter);
  if (!_.isEmpty(entMtch)) {
    entMtch = _.map(entMtch, (em) => { return { depth: depth, ...em } });
  }
  let chLst = entityChildList(entityList, scope);  
  // apply filter on each of the child entities, if datasource operator found return
  async.concat(chLst, (che, asynClb) => {
    stepIntoSearch(++depth, entityList, stepFilter, { record_id: che.entity[0].record_id }, (err, stpInto) => {
      let resultLst = [];
      resultLst.push(...entMtch);  
      if (!_.isEmpty(stpInto)) {
        resultLst.push(...stpInto);
      }
      asynClb(null, resultLst);
    });
  }, (err, rslt) => {
    stpIntoClbck(null, rslt);
  });
}

// reverse step search
function rvStepSearchScope(entityList, filterSequence, scope) {
  if (filterSequence.length < 0)
    return entityList;
  let match = _.filter(entityList, (ent) => {
    return _.filter(ent.entity, filterSequence[0]).length > 0;
  });
  /*
  console.log('Filter Sequence');
  console.log(filterSequence);
  console.log('Match');
  console.log(match);
  */
  let stepRslt = [];
  filterSequence.splice(0, 1);
  if (!_.isEmpty(match) && filterSequence.length > 0) {
    _.forEach(match, (mtch) => {
      filterSequence[0] = { ...filterSequence[0], record_id: mtch.entity[0].containing_entity_id };
      let fs = _.map(filterSequence, (fs) => { return fs; });
      let rslt = rvStepSearchScope(entityList, fs, mtch);
      if (rslt != undefined) {
        stepRslt.push(...rslt);
      }
    });
    return stepRslt;
  } else if(_.isEmpty(match) && !isObjectEmpty(scope)) {
    let prn = findEnt(entityList, {record_id: scope.entity[0].containing_entity_id});
    console.log('Parent Record');
    console.log(prn);
    if(!_.isEmpty(prn)) {
      filterSequence[0] = { ...filterSequence[0], record_id: prn[0].entity[0].containing_entity_id };
      let fs = _.map(filterSequence, (fs) => { return fs; });
      let rslt = rvStepSearchScope(entityList, fs, prn[0]);
      if (rslt != undefined) {
        stepRslt.push(...rslt);
      }
    }
    return stepRslt;
  } else if (!_.isEmpty(match) && filterSequence.length == 0) {
    return match;
  } else {
    return [];
  }
}

function findParentComponent(componentList, component) {
  return _.filter(componentList, (ce) => {
    return _.filter(ce.entity, {record_id: component.entity[0].containing_entity_id}).length > 0;
  });
}

function distinctProperty(entityList, property) {
  let propertyValL = _.map(entityList, (ent) => { 
    return _.map(ent.entity, (prp) => { return prp[property]; }); 
  });
  propertyValL = _.uniq(_.flatten(propertyValL));
  return propertyValL;
}

function groupEntityByProperty(entityList, property) {
  let dstPropVal = distinctProperty(entityList, property);
  return _.map(dstPropVal, (prpVal) => {
    return {[prpVal]: findEnt(entityList, {[property]: prpVal})};
  });
}

function entityProperty(entity) {
  return _.map(entity.entity_property, (ep) => {
    return {[ep.property_name]: ep.property_value};
  });
}

exports.findScopeObj = findScopeObj;
exports.findEntProp = findEntProp;
exports.stepSearch = stepSearch;
exports.findEnt = findEnt;
exports.findEntWithProp = findEntWithProp;
exports.stepIntoSearch = stepIntoSearch;
exports.entityChildList = entityChildList;
exports.findParentComponent = findParentComponent;
exports.rvStepSearchScope = rvStepSearchScope;
exports.getScope = getScope;
exports.distinctProperty = distinctProperty;
exports.groupEntityByProperty = groupEntityByProperty;
exports.entityProperty = entityProperty;