let _ = require('lodash');
let async = require('async');
let { entPropFilter, getEntityChildL } = require('./entity_op');
let { isString, isObjectEmpty } = require('../helper_op/object');
function recInvOpRtTolf(opEntLst, allOpEntLst, opRefL, scope = [], pO, pOLst, executionLevel, fnlClb) {   // prLst{page, allEntLst}
  //console.log(opEntLst);    // getting called as parent and as child as well
  async.concat(opEntLst, (op, oAclb) => {
    // Some modification on OP
    // get op name
    let opr = _.find(op.property, {property_name: 'operator_name'});//.property_value;//opRefL[op];
    if(isObjectEmpty(opr)){
      oAclb(null, []);
      return;
    }
    let oprt = opRefL[opr.property_value];
    console.log(opr.property_value);
    if (typeof oprt !== 'function') {
      console.log('Operator Not found!');
      oAclb(null, []);
      return;
    }
    // execution stack?  
    ///*
    oprt(op, pO, pOLst, scope, executionLevel, (err, rslt) => {
      // get all the children
      let childL = getEntityChildL(op, allOpEntLst);
      //console.log(childL);
      if(!_.isEmpty(childL)) {
        recInvOpRtTolf(childL, allOpEntLst, opRefL, rslt, pO, pOLst, [], (err, rsltL) => {
          childL = [];
          oAclb(err, [...rslt, ...scope, ...rsltL]);     // Bug?
        });
      } else {
        // add to db here {label, entity, db data, execution level}
        oAclb(err, [...scope, ...rslt]);
      }
    });
    //*/
  }, (err, rsltL) => {
    // add result to scope
    if(_.isEmpty(rsltL))
      fnlClb(err, []);
    else
      fnlClb(err, _.flattenDeep(rsltL));
  });
}

exports.recInvOpRtTolf = recInvOpRtTolf;