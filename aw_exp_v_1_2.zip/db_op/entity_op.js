let _ = require('lodash');
let async = require('async');

let { queryR, queryW } = require('./db_op');
let { isObjectEmpty } = require('../helper_op/object');

class Entity {
  constructor(entity_label, entity_name, application_id = 0, containing_entity_id = 0, entity_id = 0) {
    this.entity_label = entity_label;
    this.entity_name = entity_name;
    this.application_id = application_id;
    this.containing_entity_id = containing_entity_id;
    this.entity_id = entity_id;
  }

  setAttribute(attrObj) {
    let keyL = Object.keys(attrObj);
    _.forEach(keyL, (key) => {
      this[key] = attrObj[key];
    });
  }

  // entity_id,	application_id,	containing_entity_id,	entity_label,	entity_name, created_on, updated_on, active 
  getEntity() {
    return [this.application_id, this.containing_entity_id, this.entity_label, this.entity_name];
  }

  getEntityString() {
    return '("' + this.application_id + '", "' + this.containing_entity_id + '", "' + this.entity_label + '", "' + this.entity_name + '")';
  }
}

class EntityProperty {
  constructor(property_entity_id, property_label, property_name, property_type, property_value, property_id = 0) {
    this.property_entity_id = property_entity_id;
    this.property_label = property_label;
    this.property_name = property_name;
    this.property_type = property_type;
    this.property_value = property_value;
    this.property_id = property_id;
  }

  setAttribute(attrObj) {
    let keyL = Object.keys(attrObj);
    _.forEach(keyL, (key) => {
      this[key] = attrObj[key];
    });
  }

  getEntityProperty() {
    return [this.property_entity_id, this.property_label, this.property_name, this.property_type, this.property_value];
  }

  getEntityPropertyString() {
    return '("' + this.property_entity_id + '", "' + this.property_label + '", "' + this.property_name + '", "' + this.property_type + '", "' + this.property_value + '")';
  }
}

function getEntityChildL(entity, entityList) {
  return entityFilter(entityList, { containing_entity_id: entity.entity.entity_id });
}

function getEntity(filter, fclb) {
  let entWhere = '';
  if (!isObjectEmpty(filter)) {
    let wh = []
    _.forEach(Object.keys(filter), (key) => {
      wh.push(key + ' = "' + filter[key] + '"');
    });
    entWhere = _.join(wh, ' AND ');
    entWhere = ' WHERE ' + entWhere;
  }
  sql = 'SELECT * FROM code_writer_v2.entity' + entWhere;
  queryR(sql, (err, rslt) => { fclb(err, rslt); });
}

function entityReject(entLst, filter) {
  if(isObjectEmpty(filter))
    return entLst;
  return _.reject(entLst, (ent) => {
    return _.filter([ent.entity], filter).length > 0
  });
}

function entityFilter(entLst, filter) {
  if(isObjectEmpty(filter))
    return entLst;
  return _.reject(entLst, (ent) => {
    return _.filter([ent.entity], filter).length > 0
  });
}

function entityPropertyReject(entLst, filter) {
  if(isObjectEmpty(filter))
    return entLst;
  return _.reject(entLst, (ent) => {
    return !isObjectEmpty(findProp(ent, filter));
  });
}

function entPropFilter(entLst, filter) {
  // return entities with properties
  if(isObjectEmpty(filter)) {
    return entLst;
  }    
  return _.filter(entLst, (ent) => {
    return !isObjectEmpty(findProp(ent, filter));
  });
}

function findProp(entity, filter) {
  if(isObjectEmpty(filter))
    return entity;
  return _.find(entity.property, filter);
}

function filterProp(entity, filter) {
  if(isObjectEmpty(filter))
    return entity;
  return _.filter(entity.property, filter);
}

function getProperty(filter, fclb) {
  let entWhere = '';
  if (!isObjectEmpty(filter) && filter.hasOwnProperty('entity_id')) {
    let wh = [];
    _.forEach(Object.keys(filter), (key) => {
      wh.push(key + ' = "' + filter[key] + '"');
    });
    entWhere = _.join(wh, ' AND ');
    entWhere = ' WHERE ' + entWhere;
    sql = 'SELECT * FROM code_writer_v2.entity';
    queryR(sql, (err, rslt) => { fclb(err, rslt); });
  } else {
    fclb(null, []);
  }
}

function addEntity(entity, fclb) {
  // entity_id,	application_id,	containing_entity_id,	entity_label,	entity_name, created_on, updated_on, active 
  let entSql = 'INSERT INTO code_writer_v2.entity (application_id,	containing_entity_id,	entity_label,	entity_name) VALUES ' + entity.getEntityString();
  queryR(entSql, (err, erslt) => {
    entity.setAttribute({ entity_id: erslt.insertId })
    fclb(err, entity);
  });
}
// BULK write properties
function addProperty(property, fclb) {
  // property_id,	property_entity_id, property_label,	property_name, property_type, property_value, 
  // created_on, updated_on, editable, active 
  let entPSql = 'INSERT INTO code_writer_v2.entity_property (property_entity_id, property_label,	property_name, property_type, property_value) VALUES ' + property.getEntityPropertyString();
  queryR(entPSql, (err, prslt) => {
    property.setAttribute({ property_id: prslt.insertId });
    fclb(err, property);
  });
}

function addEntityProperty(epList, fclb) {
  async.waterfall([
    function (clb) {
      async.concat(epList, (ep, asClb) => {
        addEntity(ep.entity, (err, rslt) => {
          _.forEach(ep.property, (pr) => {
            pr.setAttribute({ property_entity_id: rslt.entity_id });
          });
          asClb(err, { entity: rslt, property: ep.property });
        });
      }, (err, rslt) => {
        clb(err, rslt);
      });
    },
    function (epList, clb) {
      async.concat(epList, (ep, asClb) => {
        // BUG Property list
        async.concat(ep.property, (pr, iasClb) => {
          addProperty(pr, (err, rslt) => {
            iasClb(err, rslt);
          });
        }, (err, rslt) => {
          asClb(err, { ...ep, property: rslt });
        });
      }, (err, rslt) => {
        clb(err, rslt);
      });
    }
  ], (err, rslt) => {
    fclb(err, rslt);
  });
}

// [{entity: eo, property: po}, ...]
function addEntTree(entityList, fclb) {
  // parent, child
  async.concat(entityList, (ent, asClb) => {
    if (ent.hasOwnProperty('parent')) {
      addEntityProperty([ent.parent], (err, entityObj) => {
        entityObj = entityObj[0];
        if (ent.hasOwnProperty('child')) {
          _.forEach(ent.child, (ch) => {
            if (ch.hasOwnProperty('parent')) {
              ch.parent.entity.setAttribute({ containing_entity_id: entityObj.entity.entity_id });
            } else if (!isObjectEmpty(ch)) {
              ch.entity.setAttribute({ containing_entity_id: entityObj.entity.entity_id });
            }
          });
          addEntTree(ent.child, (err, rentityObj) => {
            asClb(err, [entityObj, rentityObj]);
          });
        } else {
          asClb(err, entityObj);
        }
      });
    } else if (!isObjectEmpty(ent)) {
      addEntityProperty([ent], (err, rslt) => {
        asClb(err, rslt);
      });
    }
  }, (err, rslt) => {
    fclb(err, _.flattenDeep(rslt));
  });
}

function objectToPropertyL(pObj) {
  let objK = Object.keys(pObj);
  objK = _.filter(objK, (oky) => { return pObj.hasOwnProperty(oky) })
  return _.map(objK, (key) => {
    return new EntityProperty(0, 'property', key, 'string', pObj[key]);
  });
}

function entityToObj(ent) {
  let pObj = {};
  _.forEach(ent.property, (prp) => {
    pObj[prp.property_name] = prp.property_value;
  })
  return { ...ent.entity, ...pObj };
}

function entityChDec(entLst, prntEnt, filter) {
  let cEntL = entityFilter(entLst, { containing_entity_id: prntEnt.entity.entity_id, ...filter });
  let cEL = [];
  if (!_.isEmpty(cEntL)) {
    _.forEach(cEntL, (ce) => {
      cEL.push(...entityChDec(entLst, ce));
      cEL.push(ce);
    });
  } else {
    return [];
  }
  return cEL;
}

function opOnEntChRec(entLst, page, allEntityLst, filterOp, entOprt, scope = [], fnlClb) {
  async.concat(entLst, (ent, oAclb) => {
    entOprt(ent, page, scope, allEntityLst, (err, rslt) => {
      oAclb(err, rslt);
    });
  }, (err, rsltL) => {
    // add result to scope
    scope.push(...rsltL);
    // find childList of each item in entity list, recurse on each childList
    async.concat(entLst, (ent, oAclb) => {
      let childL = filterOp(ent, allEntityLst);
      if (_.isEmpty(childL)) {
        oAclb(err, scope);
      } else {
        opOnEntChRec(childL, page, allEntityLst, filterOp, entOprt, scope, (err, rslt) => { oAclb(err, rslt); });
      }
    }, (err, rslt) => {
      fnlClb(err, rslt);
    });
  });
}

function entityObjFilter(entLst, filterOb) {
  let entityPrp = [
    'entity_id', 'application_id',
    'containing_entity_id', 'entity_label',
    'entity_name'
  ];
  let entityPropertyPrp = [
    'property_id', 'property_entity_id',
    'property_label', 'property_name',
    'property_type', 'property_value'
  ];

  let entityFOL = _.map(filterOb.filter, (fl) => {
    let entityFO = {};
    _.forEach(entityPrp, (prp) => {
      if (fl.hasOwnProperty(prp) && fl[prp] !== '') {
        entityFO[prp] = fl[prp];
      }
    });
    let propertyFO = {};
    _.forEach(entityPropertyPrp, (prp) => {
      if (fl.hasOwnProperty(prp) && fl[prp] !== '') {
        propertyFO[prp] = fl[prp];
      }
    });
    let entityObjL = entityFilter(entLst, entityFO);    
    console.log(entityFilter(entityObjL, {entity_label: 'table'}));
    entityObjL = entPropFilter(entityObjL, propertyFO);
    console.log('Table Again');
    console.log(entPropFilter(entityObjL, propertyFO));
    return entityObjL;
  });
  
  entityFOL = _.flattenDeep(entityFOL);
  console.log('Label Filter');
  if (filterOb.hasOwnProperty('reject')) {
    let entityFO = {};
    _.forEach(filterOb.reject, (rj) => {
      _.forEach(entityPrp, (prp) => {
        if (rj.hasOwnProperty(prp) && rj[prp] !== '') {
          entityFO[prp] = rj[prp];
        }
      });
      entityFOL = entityReject(entityFOL, entityFO);
      let propertyFO = {};
      _.forEach(entityPropertyPrp, (prp) => {
        if (rj.hasOwnProperty(prp) && rj[prp] !== '') {
          propertyFO[prp] = rj[prp];
        }
      });
      entityFOL = entityPropertyReject(entityFOL, propertyFO);
    });
  }
  
  if (filterOb.hasOwnProperty('get_property') && !_.isEmpty(filterOb.get_property)) {
    let entityRefProperty = _.map(entityFOL, (ent) => {
      let pRef = _.map(filterOb.get_property, (prp) => { return filterProp(ent, { property_name: prp }); });
      return { entity: ent, property_ref:  pRef}
    });
    return entityRefProperty;
  } else {
    return entityFOL;
  }
}

function opRootEntity(dbOpL, opE) {
  let rt;
  let condition = false;
  do {
    rt = entityFilter(dbOpL, { entity_id: opE.entity.containing_entity_id })[0];
    if (rt.entity.containing_entity_id == 0)
      condition = true;
    else
      opE = rt;
  } while (!condition);
  return rt;
}

function addRefProperty(propObj, fnlClb) {
  if (isObjectEmpty(propObj)) {
    fnlClb(null, []);
    return;
  }
  addProperty(propObj.property, (err, rtPrp) => {
    async.concat(propObj.ref_list, (refP, asyRefClb) => {
      refP.property_value = rtPrp.property_id;
      addProperty(refP, (err, refPD) => {
        asyRefClb(err, refPD);
      });
    }, (err, refPrpL) => {
      fnlClb(err, [...refPrpL, rtPrp]);
    });
  });
}

function getEntityList(filterOb, fnlClb) {
  let entityPrp = [
    'entity_id', 'application_id',
    'containing_entity_id', 'entity_label',
    'entity_name'
  ];
  let entityPropertyPrp = [
    'property_id', 'property_entity_id',
    'property_label', 'property_name',
    'property_type', 'property_value'
  ];
  let filter = {};
  _.forEach(entityPrp, (prp) => {
    if (filterOb.hasOwnProperty(prp) && filterOb[prp] !== '') {
      filter[prp] = filterOb[prp];
    }
  });
  _.forEach(entityPropertyPrp, (prp) => {
    if (filterOb.hasOwnProperty(prp) && filterOb[prp] !== '') {
      filter[prp] = filterOb[prp];
    }
  });
  let entWhere = '';
  if (!isObjectEmpty(filter)) {
    let wh = []
    _.forEach(Object.keys(filter), (key) => {
      wh.push(key + ' = "' + filter[key] + '"');
    });
    entWhere = _.join(wh, ' AND ');
    entWhere = ' WHERE ' + entWhere;
  }
  /*
  sql = 'SELECT entity.*, GROUP_CONCAT(CONCAT_WS(",", entity_property.property_id, entity_property.property_entity_id, entity_property.property_label, entity_property.property_name, entity_property.property_type, entity_property.property_value) SEPARATOR ";") AS property_list FROM code_writer_v2.entity LEFT JOIN code_writer_v2.entity_property ON entity_property.property_entity_id = entity.entity_id ' + entWhere + ' GROUP BY entity_id';
  */
  sql = 'SELECT entity.* FROM code_writer_v2.entity ' + entWhere + ' GROUP BY entity_id';
  queryR(sql, (err, rsltL) => {
    let entityL = _.map(rsltL, (ent) => {return { entity: new Entity(ent.entity_label, ent.entity_name, ent.application_id, ent.containing_entity_id, ent.entity_id), property: prpL }});
    fnlClb(err, entityL);
  });
}


exports.getEntityList = getEntityList;
exports.addRefProperty = addRefProperty;
exports.opRootEntity = opRootEntity;
exports.opOnEntChRec = opOnEntChRec;
exports.entityChDec = entityChDec;
exports.Entity = Entity;
exports.EntityProperty = EntityProperty;
exports.getEntity = getEntity;
exports.getProperty = getProperty;
exports.addEntity = addEntity;
exports.addProperty = addProperty;
exports.addEntityProperty = addEntityProperty;
exports.addEntTree = addEntTree;
exports.findProp = findProp;
exports.objectToPropertyL = objectToPropertyL;
exports.entPropFilter = entPropFilter;
exports.entityToObj = entityToObj;
exports.entityFilter = entityFilter;
exports.getEntityChildL = getEntityChildL;
exports.entityObjFilter = entityObjFilter;