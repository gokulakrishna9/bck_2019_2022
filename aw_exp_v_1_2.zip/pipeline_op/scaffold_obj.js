let _ = require('lodash');
let async = require('async');
let { getDBSchema } = require('../db_op/db_op');
let { Entity, entityFilter, findProp, entPropFilter, EntityProperty, addEntityProperty, addEntTree, objectToPropertyL, propertyToObj, entityToObj } = require('../db_op/entity_op');
let { splitCapitalize } = require('../helper_op/string_function');
let { isObjectEmpty } = require('../helper_op/object');

exports.dbObj = function (db, fclb) {
  // get db data
  console.log('Scaffold Object DB Name');
  console.log(db);
  let dbName = findProp(db, { property_label: 'name' }).property_value;
  getDBSchema(dbName, (derr, dbSchema) => {
    // get unique table, map table_name, distinct table_name    
    let tableL = _.union(_.map(dbSchema.columns, (sch) => { return sch.TABLE_NAME }));
    // for each table create column objects
    console.log('Uniq Table');
    console.log(tableL);
    tableL = _.map(tableL, (tbl) => {
      let colL = _.map(_.filter(dbSchema.columns, { TABLE_NAME: tbl }), (col) => { return fieldObj(col) });
      return {
        parent: {
          entity: new Entity('table', tbl, db.entity.application_id, db.entity.entity_id),
          property: [new EntityProperty(0, 'name', 'table_name', 'string', tbl)]
        },
        child: _.map(colL, (col) => {
          return {
            entity: new Entity('column', col.column_name, db.entity.application_id),
            property: objectToPropertyL(col)
          };
        })
      };
    });
    fclb(derr, tableL);
  });
}

function fieldObj(column) {
  let columnType = _.split(column.COLUMN_TYPE.replace('(', ' ').replace(')', ''), ' ');
  let label = column.COLUMN_KEY != 'PRI' && (columnType[0] == 'varchar' || columnType[0] == 'char' || columnType[0] == 'date' || columnType[0] == 'time' || columnType[0] == 'datetime' || columnType[0] == 'timestamp') && columnType[1] > 5 && columnType[1] <= 75;
  return {
    column_type: columnType[0],
    column_size: columnType[1],
    column_key: column.COLUMN_KEY,
    column_name: column.COLUMN_NAME,
    //table_name: column.TABLE_NAME,
    column_label: splitCapitalize(column.COLUMN_NAME, '_'),
    label_column: label,
    //db: column.TABLE_SCHEMA,
    column_comment: column.COLUMN_COMMENT
  };
}

exports.findRelation = function (dbObjL, fclb) {
  // {relation, containing_entity, ref table_one, ref table_two, ref col_one, ref col_two, ref_col_two_label}
  let tableL = _.map(entityFilter(dbObjL, { entity_label: 'table' }), (tl) => { return entityToObj(tl); });
  let colL = _.map(entityFilter(dbObjL, { entity_label: 'column' }), (cl) => { return entityToObj(cl) });
  async.concat(tableL, (tbl, acClb) => {
    // get column list
    let relationL = [];
    let tcL = _.filter(colL, { containing_entity_id: tbl.entity_id });
    let pCl = _.find(tcL, { column_key: 'PRI' });
    if (!isObjectEmpty(pCl)) {
      let cCol = _.filter(colL, { column_name: pCl.column_name });
      cCol = _.filter(_.reject(cCol, { column_key: 'PRI' }), { column_type: 'int' });      
      _.forEach(cCol, (cl) => {
        let lbl = _.find(colL, { containing_entity_id: cl.containing_entity_id, label_column: true });
        if (isObjectEmpty(lbl)) {
          lbl = cl;
        }
        relationL.push({
          entity: new Entity('relation', 'derived', tbl.application_id, tbl.entity_id),
          property: [
            new EntityProperty(0, 'table', '1_table', 'ref', tbl.entity_id),
            new EntityProperty(0, 'column', '1_column', 'ref', pCl.entity_id),
            new EntityProperty(0, 'table', '2_table', 'ref', cl.containing_entity_id),
            new EntityProperty(0, 'column', '2_column', 'ref', cl.entity_id),
            new EntityProperty(0, 'column', 'select_col', 'ref', lbl.entity_id),
          ]
        });
      });
    }
    let npC = _.filter(tcL, { column_type: 'int' });
    _.forEach(npC, (np) => {
      let mCol = _.find(colL, { column_name: np.column_name, column_key: 'PRI' });
      if (!isObjectEmpty(mCol)) {
        let lbl = _.find(colL, { containing_entity_id: mCol.containing_entity_id, label_column: true });
        if (isObjectEmpty(lbl)) {
          lbl = mCol;
        }
        relationL.push({
          entity: new Entity('relation', 'master', tbl.application_id, tbl.entity_id),
          property: [
            new EntityProperty(0, 'table', '1_table', 'ref', tbl.entity_id),
            new EntityProperty(0, 'column', '1_column', 'ref', np.entity_id),
            new EntityProperty(0, 'table', '2_table', 'ref', mCol.containing_entity_id),
            new EntityProperty(0, 'column', '2_column', 'ref', mCol.entity_id),
            new EntityProperty(0, 'column', 'select_col', 'ref', lbl.entity_id)
          ]
        })
      }
    });
    acClb(null, relationL);
  }, (err, relationL) => {
    fclb(null, relationL);
  });
}