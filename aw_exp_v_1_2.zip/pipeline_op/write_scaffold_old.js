let _ = require('lodash');
let async = require('async');
let { opOnEntChRec, Entity, EntityProperty, entPropFilter, addEntityProperty, addEntTree, entityFilter, entityChDec, entityToObj } = require('../db_op/entity_op');
let { dbObj, findRelation } = require('./scaffold_obj');
let { isString, isObjectEmpty } = require('../helper_op/object');
let { application_component_list } = require('../dp_op/application_component')
let { recInvOpRtTolf } = require('../db_op/dynamic_op');
exports.writeScaffold = function (userInputAD, callback) {
  console.log(userInputAD);
  let applicationId;
  let frameworkL = ['codeigniter'];
  async.waterfall([
    // 4 Sep 2021
    function (clbck) {
      // add application entity to db
      // application object
      addEntityProperty([{
        entity: new Entity('application', userInputAD.application_name),
        property: [new EntityProperty(0, 'name', 'application_name', 'string', userInputAD.application_name)]
      }],
        (err, appOb) => {
          clbck(err, appOb[0]);
        });
    },
    function (appOb, clbck) {
      // for each db_list create an entity, with application entity as head
      //console.log('App Object');
      //console.log(appOb);
      applicationId = appOb.entity.entity_id;
      let dbL = userInputAD.db_list;
      if (isString(dbL)) {
        dbL = [dbL]
      }
      dbL = _.map(dbL, (db) => {
        return { entity: new Entity('database', db, applicationId, applicationId), property: [new EntityProperty(0, 'name', 'database_name', 'string', db)] };
      });
      // write scaffold for each db element
      async.concat(dbL, (db, acClb) => {
        // tree entity {table, column}
        dbObj(db, (err, dbDObj) => {
          acClb(err, { parent: db, child: dbDObj });
        })
      }, (err, dbDObjL) => {
        addEntTree(dbDObjL, (err, dbDObjRL) => {
          clbck(err, dbDObjRL);
        });
      });
    },
    function (dbDObjRL, clbck) {
      // for each db_list create table entity {table}
      // has column list, table list
      findRelation(dbDObjRL, (err, relationL) => {
        addEntTree(relationL, (err, relationDbR) => {
          clbck(err, [...dbDObjRL, ...relationDbR]);
        });
      });
    },
    function (dbDObjL, clbck) {
      // for each table entity, create column entity{contains relation}
      // design pattern name user input
      let dp_folder = '../dp_op/mvc_op';
      let ptO = require(dp_folder).mvcDP();
      let dpPeL = applicationPageScopeList(ptO.application_page_scope_entity_list, dbDObjL);
      ///*
      // add design pattern op list, dp_ent_op, dp_op
      async.concat(dpPeL, (page, asCnClb) => {
        let dpEOpL = dpOpList(ptO.dp_ent_op, page, applicationId);
        addEntTree(dpEOpL, (err, dpEOpLR) => {
          asCnClb(err, { page: page, op_list: dpEOpLR });
        });
      }, (err, rsltL) => {
        // design pattern op list, dp_op
        let dpOpL = dpOpList(ptO.dp_op, {}, applicationId);
        addEntTree(dpOpL, (err, dpOpLR) => {
          clbck(err, { page_list: dpPeL, dp_op: dpOpLR, app_op_list: rsltL, dp_ob: ptO });
        });
      });
      //*/
    },
    function (pageOp, clbck) {
      let appScope = [];                               // label, op_record_id, op_name, op_object
      console.log('DP OP Size');
      console.log(pageOp.dp_op.length);
      async.waterfall([
        function (wflClb) {
          _.forEach(pageOp.dp_ob.call_sequence, (csop) => {
            let csopL = entityFilter(pageOp.dp_op, { entity_name: csop });
            recInvOpRtTolf(csopL, pageOp.dp_op, pageOp.dp_ob.op_stmtg, [], {}, [], [], (err, rslt) => {

            });
          });
        },
        function (dpOpL, wflClb) {
          _.forEach(pageOp.dp_ob.call_sequence, (csop) => {
            let csopL = entityFilter(pageOp.app_op_list, { entity_name: csop });
            recInvOpRtTolf(csopL, pageOp.dp_op, pageOp.dp_ob.op_stmtg, [], {}, [], [], (err, rslt) => {

            });
          });
        }
      ], (err, rslt) => { })
      /*
      _.forEach(pageOp.dp_ob.call_sequence, (cope) => {
        _.forEach(pageOp.app_op_list, (opL) => {
          let copeL = entityFilter(opL.op_list, { entity_name: cope });
          if(_.isEmpty(copeL))
            return;
          opOnEntChRec(copeL, opL.page, opL.op_list, (ent, allEnt) => {
            return entityFilter(allEnt, { containing_entity_id: ent.entity.entity_id });
          }, (op, page, op_scope_list, all_entity_list, clb) => {
            if(op.entity.entity_name === undefined)
              return;
            console.log(op.entity.entity_name);
            pageOp.dp_ob.op_stmtg[op.entity.entity_name](op, page, op_scope_list, all_entity_list, (err, rslt) => {
              clb(null, null);
            });
            
          }, [], (err, rslt) => {

          });
        });
      });
      */
    },
    function (dtOp, clbck) {
      // template scaffold, mvc template folder, from input
    },
    function (dtOp, clbck) {
      // write code, from template folder
    }
  ]);
}

function applicationPageScopeList(scopeEntityList, applicationMetaData) {
  let scopeObj = [];
  _.forEach(scopeEntityList, (se) => {
    let entityL = entityFilter(applicationMetaData, { entity_label: se.entity });
    _.forEach(entityL, (ent) => {
      let childL = []
      _.forEach(se.child, (ch) => {
        childL.push(entityFilter(applicationMetaData, { containing_entity_id: ent.entity.entity_id, entity_label: ch }));
      });
      let prn = entityFilter(applicationMetaData, { entity_id: ent.entity.containing_entity_id, entity_label: se.parent })[0];
      scopeObj.push({ entity: se.entity, entity_scope: { entity: ent, child_list: childL, parent: prn } });
    });
  });
  return scopeObj;
}

// for each entity create dpOpList, or page
function dpOpList(dpOpL, page, applicationId) {
  let cmpEL = [];
  _.forEach(dpOpL, (dpo) => {
    // create a component make it a child of previous component
    if (isObjectEmpty(page))
      page = { entity_scope: { entity: { entity_id: 0 } } };  // application entity list, let the framework op add this
    let compEnt = { parent: { entity: new Entity('component', ' ', applicationId, 0), property: [new EntityProperty(0, 'scope', 'table', 'ref', page.entity_scope.entity.entity_id)] }, child: [] };
    // make all ops children of current component
    let opEl = opEntL(dpo.op_list, applicationId);
    compEnt.child = opEl;
    cmpEL.push(compEnt);
  });
  return cmpEL;
}

function opEntL(opL, applicationId) {
  let opEL = [];
  let chOpL = [];
  _.forEach(opL, (op) => {
    if (Array.isArray(op)) {
      chOpL.push(...opEntL(op, applicationId));
    } else {
      if (!_.isEmpty(chOpL)) {
        opEL.push({ parent: { entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op)] }, child: chOpL });
        chOpL = [];
      } else {
        opEL.push({ entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op)] });
      }
    }
  });
  return opEL;
}

function applyDPToDBScf(dlOl, fnlclb) {
  // component, method, statement group, statement, expression, method group{statement, statement group, expression}
  let appD = dlOl.dp_ob.application_definition;
  // pass application definition to build application
  appD = application_component_list(appD, dlOl.meta_data_list);
  // console.log('Application Definition');
  // console.log(appD);
  // component graph
  // component
  // op_list, assume next component is dependent on previous
  let scope = [];
  // async concat
  async.concat(dlOl.dp_ob.component_graph, (layer, oAClb) => {
    async.concat(layer.parent_group, (pg, pAClb) => {
      // call pg op
      if (!isObjectEmpty(_.find(scope, (val, key) => { return key == pg; })))
        return;
      let component = entPropFilter(entityFilter(dlOl.op_list, { entity_label: 'component' }), { property_label: 'op_group', property_value: pg });
      if (_.isEmpty(component))
        return;
      let pgCeL = [...entityChDec(dlOl.op_list, component[0], { entity_label: 'operator' }), component[0]];
      // add to scope
      scope.push({ [pg]: opCal(pgCeL, scope, appD) });
      // add pg op to db, clbck
    }, (err, rslt) => {
      async.concat(layer.child_group, (cg) => {
        // link child group to parent group
        if (!isObjectEmpty(_.find(scope, (val, key) => { return key == cg; })))
          return;
        let component = entPropFilter(entityFilter(dlOl.op_list, { entity_label: 'component' }), { property_label: 'op_group', property_value: cg });
        if (_.isEmpty(component))
          return;
        let cgCeL = [...entityChDec(dlOl.op_list, component[0], { entity_label: 'operator' }), component[0]];
        // add to scope
        scope.push({ [cg]: opCal(cgCeL, scope, appD) });
        // add child op to dg, clbck
      }, (err, rslt) => {
        // final clbck
      });
    })
  }, (err, rslt) => {
    fnlclb(err, rslt);
  });
  /*
  _.forEach(dlOl.dp_ob.component_graph, (layer) => {
    // async concat
    _.forEach(layer.parent_group, (pg) => {
      if (!isObjectEmpty(_.find(scope, (val, key) => { return key == pg; })))
        return;
      let component = entPropFilter(entityFilter(dlOl.op_list, { entity_label: 'component' }), { property_label: 'op_group', property_value: pg });
      if (_.isEmpty(component))
        return;
      let pgCeL = [...entityChDec(dlOl.op_list, component[0], { entity_label: 'operator' }), component[0]];
      // add to scope
      scope.push({ [pg]: opCal(pgCeL, scope, appD) });
    });
    // call db and add the elements to db
    // async concat
    // similarty child layer
    _.forEach(layer.child_group, (cg) => {
      if (!isObjectEmpty(_.find(scope, (val, key) => { return key == cg; })))
        return;
      let component = entPropFilter(entityFilter(dlOl.op_list, { entity_label: 'component' }), { property_label: 'op_group', property_value: cg });
      if (_.isEmpty(component))
        return;
      let cgCeL = [...entityChDec(dlOl.op_list, component[0], { entity_label: 'operator' }), component[0]];
      // add to scope
      scope.push({ [cg]: opCal(cgCeL, scope, appD) });
    });
  });
  */
}

function opCal(opEL, scope, appDef) {
  // for each operator call, pass in the data list, in each operator create entity, entity property ref
  // create a global scope object list
  // from op call return {scope, add_to_db}
  // all op group, component list
  let opELC = opEL[opEL.length - 1];
  // op_group, // op_list
  opELC = entityToObj(opELC);
  let dp_folder = '../dp_op/mvc' + '/' + opELC.group_name;
  let opO = require(dp_folder);//[opELC['group_name']];
  //console.log('OpL Obj');
  //console.log(opO);
  let opElL = [];
  _.forEach(opEL, (oe) => {
    oe = entityToObj(oe);
    let op = opO[oe['operator_name']];
    // {scope, add_to_db}
    // dp_ob: ptO, op_folder: dp_folder + '/' + ptO.dp_folder, meta_data_list: dbObjL, op_list: dpOpLR 
    console.log(oe['operator_name']);
    _.forEach(appDef, (appTE) => {
      //console.log(op);
      opElL.push(op(oe, scope, appTE, appDef));
    });
  });
  return { parent: opElL[opElL.length - 1], child: [opElL.splice(opElL.length - 1, 1)] };
}