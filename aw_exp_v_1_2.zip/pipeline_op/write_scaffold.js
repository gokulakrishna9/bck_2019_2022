let _ = require('lodash');
let async = require('async');
let { opOnEntChRec, Entity, EntityProperty, entPropFilter, addEntityProperty, addEntTree, entityFilter, entityChDec, entityToObj } = require('../db_op/entity_op');
let { dbObj, findRelation } = require('./scaffold_obj');
let { isString, isObjectEmpty } = require('../helper_op/object');
let { application_component_list } = require('../dp_op/application_component')
let { recInvOpRtTolf } = require('../db_op/dynamic_op');
let { writeFrameworkToDB } = require('../dp_op/write_framework');
exports.writeScaffold = function (userInputAD, callback) {
  console.log(userInputAD);
  let applicationId;
  let frameworkL = ['codeigniter'];
  async.waterfall([
    // 4 Sep 2021
    function (clbck) {
      // add application entity to db
      // application object
      addEntityProperty([{
        entity: new Entity('application', userInputAD.application_name),
        property: [new EntityProperty(0, 'name', 'application_name', 'string', userInputAD.application_name)]
      }],
        (err, appOb) => {
          clbck(err, appOb[0]);
        });
    },
    function (appOb, clbck) {
      // for each db_list create an entity, with application entity as head
      //console.log('App Object');
      //console.log(appOb);
      applicationId = appOb.entity.entity_id;
      let dbL = userInputAD.db_list;
      if (isString(dbL)) {
        dbL = [dbL]
      }
      dbL = _.map(dbL, (db) => {
        return { entity: new Entity('database', db, applicationId, applicationId), property: [new EntityProperty(0, 'name', 'database_name', 'string', db)] };
      });
      // write scaffold for each db element
      async.concat(dbL, (db, acClb) => {
        // tree entity {table, column}
        dbObj(db, (err, dbDObj) => {
          acClb(err, { parent: db, child: dbDObj });
        })
      }, (err, dbDObjL) => {
        addEntTree(dbDObjL, (err, dbDObjRL) => {
          clbck(err, dbDObjRL);
        });
      });
    },
    function (dbDObjRL, clbck) {
      // for each db_list create table entity {table}
      // has column list, table list
      findRelation(dbDObjRL, (err, relationL) => {
        addEntTree(relationL, (err, relationDbR) => {
          clbck(err, [...dbDObjRL, ...relationDbR]);
        });
      });
    },
    function (dbDObjL, clbck) {
      // for each table entity, create column entity{contains relation}
      // design pattern name user input
      let dp_folder = '../dp_op/label_scaffold';
      // CHANGE CODE FROM HERE
      let ptO = require(dp_folder).mvcScaffold();
      writeFrameworkToDB(ptO, dbDObjL, {}, (err, rslt) => {
        clbck(err, rslt);
      });
      ///*
      // add design pattern op list, dp_ent_op, dp_op
      
      //*/
    },
    function (pageOp, clbck) {
      /*
      let appScope = [];                               // label, op_record_id, op_name, op_object
      console.log('DP OP Size');
      console.log(pageOp.dp_op.length);
      async.waterfall([
        function (wflClb) {
          _.forEach(pageOp.dp_ob.call_sequence, (csop) => {
            let csopL = entityFilter(pageOp.dp_op, { entity_name: csop });
            recInvOpRtTolf(csopL, pageOp.dp_op, pageOp.dp_ob.op_stmtg, [], {}, [], [], (err, rslt) => {

            });
          });
        },
        function (dpOpL, wflClb) {
          _.forEach(pageOp.dp_ob.call_sequence, (csop) => {
            let csopL = entityFilter(pageOp.app_op_list, { entity_name: csop });
            recInvOpRtTolf(csopL, pageOp.dp_op, pageOp.dp_ob.op_stmtg, [], {}, [], [], (err, rslt) => {

            });
          });
        }
      ], (err, rslt) => { })
      
      _.forEach(pageOp.dp_ob.call_sequence, (cope) => {
        _.forEach(pageOp.app_op_list, (opL) => {
          let copeL = entityFilter(opL.op_list, { entity_name: cope });
          if(_.isEmpty(copeL))
            return;
          opOnEntChRec(copeL, opL.page, opL.op_list, (ent, allEnt) => {
            return entityFilter(allEnt, { containing_entity_id: ent.entity.entity_id });
          }, (op, page, op_scope_list, all_entity_list, clb) => {
            if(op.entity.entity_name === undefined)
              return;
            console.log(op.entity.entity_name);
            pageOp.dp_ob.op_stmtg[op.entity.entity_name](op, page, op_scope_list, all_entity_list, (err, rslt) => {
              clb(null, null);
            });
            
          }, [], (err, rslt) => {

          });
        });
      });
      */
    },
    function (dtOp, clbck) {
      // template scaffold, mvc template folder, from input
    },
    function (dtOp, clbck) {
      // write code, from template folder
    }
  ]);
}