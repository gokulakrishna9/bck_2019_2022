let express = require('express');
let router = express.Router();
let async = require('async');
let _ = require('lodash');

let { getDatabaseList } = require('../db_op/db_op');
let { writeTransactionState, updateTransactionState, getTransactionStatus } = require('../db_op/transaction_op');
let { getEntity } = require('../db_op/entity_op');
let { writeScaffold } = require('../pipeline_op/write_scaffold');
let { makeid } = require('../helper_op/number');

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/landing_page', (req, res, next) => {
  console.log('Landing Page');
  // long action
  async.waterfall([
    function (clbck) {
      // get db list
      getDatabaseList((err, rslt) => { clbck(err, { db_list: rslt }); });
    },
    function (rslt, clbck) {
      // get application list
      // NEED TO TEST THIS PART
      getEntity({ entity_name: 'application' }, (err, rs) => { clbck(err, { ...rslt, application_list: rs }); });
    }
  ], (err, rslt) => {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(rslt));
  });
});

router.post('/write_scaffold', (req, res, next) => {
  console.log('Request Body');
  console.log(req.body);
  // VALIDATION METHOD
  if (Object.keys(req.body).length === 0 && req.body.constructor === Object) {
    clbck(null, null);
  } else {
    async.waterfall([
      function (clbck) {
        // write the transaction intialization to DB
        writeTransactionState(makeid(7), (err, rslt) => {
          console.log('Long Transaction record');
          console.log(rslt);
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(rslt));
          clbck(err, { t_state: rslt.insertId, lt_req_key: rslt.lt_req_key });
        });
      },
      function (rslt, clbck) {
        // write the scaffold    
        writeScaffold(req.body, (err, appScaff) => { clbck(err, { transaction_filter: rslt, application_scaffold: appScaff }); });
      },
      function (rslt, clbck) {
        // update the transaction initialization to DB
        console.log(rslt);
        let state = true;
        updateTransactionState(rslt.transaction_filter, state, (err, rslt) => {
          clbck(err, rslt);
        });
      }
    ], (err, rslt) => {
      if (err) {
        console.log(err);
        let state = false;
        updateTransactionState(...rslt.t_state, state, (err, rslt) => {
          return;
        });
      } else {
        console.log('End of Long Transaction!');
      }
      return;
    });
  };
});

module.exports = router;