function htmlComment() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function docType() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function anchor() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function abbreviation() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function address() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function area() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function article() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function aside() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function audio() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function bold() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function base() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function bdi() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function bdo() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function blockquote() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function body() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function htmlbreak() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function button() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function canvas() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function caption() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function cite() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function code() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function column() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function colgroup() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function data() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function datalist() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function description() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function htmldelete() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function details() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function dfn() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function dialog() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function div() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function dl() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function dt() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function emphasized() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function embed() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function fieldset() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function figcaption() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function footer() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function form() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function heading() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function head() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function header() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function hr() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function html() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function italic() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function iframe() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function img() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function input() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function ins() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function kbd() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function label() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function legend() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function li() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function link() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function main() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function map() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function mark() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function meta() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function meter() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function navigation() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function noscript() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function object() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function orderedList() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function optgroup() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function option() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function output() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function paragraph() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function param() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function picture() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function pre() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function progress() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function short_quotation() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function pronunciation() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function ruby_annotations() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function no_longer_correct() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function samp() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function script() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function section() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function select() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function small() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function source() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function span() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function strong() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function style() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function sub() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function summary() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function sup() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function svg() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function table() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function tbody() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function td() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function template() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function textarea() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function tfoot() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function th() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function thead() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function time() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function title() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function tr() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function track() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function unarticulated_style() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  };
}

function ul() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function variable() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function video() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}

function wbr() {
  return {
    property_l: [{property_name: '', property_type: '', property_range: [], property_unit: [], property_definition: ''}],
    event_l: [],
    html_element: []
  }
}