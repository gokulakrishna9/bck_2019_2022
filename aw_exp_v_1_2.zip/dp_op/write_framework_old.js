/* 
  global_scope, op_group_execution_sequence_label_list, 
  component_list{group_execution_label: '', group_execution_sequence_label_list: [], scope_entity_filter_list: {root_filter: { entity_label: 'table' }, scope_filter_list: [{}]}, component_list}
*/
let _ = require('lodash');
let async = require('async');
let { entityFilter, Entity, EntityProperty, addEntTree, addProperty, entityObjFilter } = require('../db_op/entity_op');
let { isString, isObjectEmpty } = require('../helper_op/object');
exports.writeFrameworkToDB = function (dpPObj, dbObjL, languageFrameworkL, fnlClb) {
  let applicationId = dbObjL[0].entity.application_id;
  let componentListScope = [];
  // global scope, call entity filter method, use map
  console.log('Page Object');
  console.log(dpPObj);
  let applicationScope = entityFilterList(dbObjL, dpPObj.global_scope);

  async.waterfall([
    function (oawfClb) {
      // component scope, call entity filter method, foreach component filter use map, add result to component
      _.forEach(dpPObj.component_list, (com) => {
        if (isObjectEmpty(com.scope_entity_filter)) {
          return;
        }
        com.component_scope = [];
        com.component_scope = entityFilterList(dbObjL, com.scope_entity_filter);
      });
      // for each component in component list, for each scope filter entity create component add scope entity as ref to component
      async.concat(dpPObj.component_list, (com, asCnClb) => {
        let dpEOpL = [];
        if (isObjectEmpty(com.component_scope)) {
          dpEOpL.push(dpOpList(com.component_list, {}, applicationId));
        } else {
          _.forEach(com.component_scope, (scp) => {
            dpEOpL.push(dpOpList(com.component_list, scp.entity, applicationId));   // BUG FIX
          });
        }
        dpEOpL = _.flattenDeep(dpEOpL);
        addEntTree(dpEOpL, (err, dpEOpLR) => {
          if (isObjectEmpty(com.component_scope))
            com.component_scope = { entity: { entity: { entity_id: 0 } } };
          asCnClb(err, { group_execution_level: com.group_execution_label, group_execution_sequence_label_list: com.group_execution_sequence_label_list, scope: com.component_scope, op_list: dpEOpLR });
        });     // You have all operations in here
      }, (err, pageL) => {
        // perform a map, with entity_id as filter
        oawfClb(err, pageL);
      });
    },
    function (pageL, clb) {
      dpObjPropDBR(dpPObj.op_group_execution_sequence_label_list, pageL, dpPObj.op_object, applicationId, (err, dbTemplateL) => {
        oawfClb(err, dbTemplateL);
      });
    },
    function (rsltL, clb) {
      let opList = [];
      // evaluate the template, write to file
    }
  ], (err, rslt) => {

  });
  // if not empty global_scope filter, get filter data

  // sort components by group_execution_sequence_label_list, group label
  // sort group label by op_group_execution_sequence_label_list
  // execute the component filters/methods */
}

function entityFilterList(objL, filter) {
  if (isObjectEmpty(filter))
    return [];
  let entityL = entityFilter(objL, filter.entity);
  let entSL = [];
  _.forEach(entityL, (entity) => {
    let entS = [];
    _.forEach(filter.scope, (scp) => {
      let entSF = entityFilter(objL, { ...scp, containing_entity_id: entity.entity.entity_id });
      entS.push(...entSF, entity);
    });
    entSL.push({ entity: entity, scope: entS });
  });
  return entSL;
}

// for each entity create dpOpList, or page
function dpOpList(dpOpL, page, applicationId) {
  let cmpEL = [];
  _.forEach(dpOpL, (dpo) => {
    // create a component make it a child of previous component
    if (isObjectEmpty(page))
      page = { entity: { entity: { entity_id: 0 } } };  // application entity list, let the framework op add this
    // make all ops children of current component
    let opEl = opEntL(dpo, page.entity.entity_id, applicationId);
    cmpEL.push(opEl);
  });
  return cmpEL;
}

function opEntL(opL, refId, applicationId) {
  let opEL = [];
  let chOpL = [];
  _.forEach(opL, (op) => {
    if (op === undefined)
      return;
    if (!_.isString(op) && Array.isArray(op)) {
      chOpL.push(...opEntL(op, refId, applicationId));
    } else {
      console.log(op);
      console.log(refId);
      if (!_.isEmpty(chOpL)) {
        opEL.push({ parent: { entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op), new EntityProperty(0, 'root_entity', 'ce_ref', 'ref', refId)] }, child: chOpL });
        chOpL = [];
      } else {
        opEL.push({ entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op), new EntityProperty(0, 'root_entity', 'ce_ref', 'ref', refId)] });
      }
    }
  });
  return opEL;
}

function dpObjPropDBR(groupSeq, pageL, opL, applicationId, fnlClb) {
  // for each group seq, asyncSeries
  let tOpL = _.map(pageL, (pg) => {
    let op_obj = []
    _.forEach(pg.op_list, (op) => {
      let opName = op.entity.entity_name;
      if (_.has(opL, (opName))) {
        op_obj.push({ ...opL[opName], ...op.entity, db_property: op.property });
      } else {
        console.log(opName + ' operator not found!');
      }
    });
    return { ...pg, op_obj_l: op_obj };
  });   // Got all op entities
  // execution_label not set
  let eLNotSet = _.filter(opL, (op) => {
    return !_.has(op, 'execution_label') || _.trim(op.execution_label).length == 0;
  });
  _.forEach(eLNotSet, (op) => {
    console.log('Execution Label not set on object');
    // find the parent of the op
    console.log(op);
  });
  // group_execution_level: com.group_execution_label, group_execution_sequence_label_list: com.group_execution_sequence_label_list, scope: com.component_scope, op_list: dpEOpLR, per page
  /*
  _.forEach(tOpL, (opL) => {
    _.forEach(opL.op_obj_l, (op) => {
      console.log(op);
    });
  });
  */
  // pick group_execution level
  let pipelineObL = [];
  async.concatSeries(groupSeq, (gpExS, gpExClb) => {
    // filter matching group
    console.log(gpExS);
    let grpL = _.find(tOpL, { group_execution_level: gpExS });
    if (isObjectEmpty(grpL)) {
      gpExClb(null, null);
      return;
    }
    async.concatSeries(grpL.group_execution_sequence_label_list, (opExS, opExClb) => {
      let opL = getExSeq(opExS, grpL.op_obj_l);
      console.log('Group Scope');
      console.log(grpL.scope);
      let scope = _.reduce(grpL.scope, (scpL, scp) => {
        return scpL.push(...scp.scope);
      }, []);
      applyFilter(opL, [...scope, ...pipelineObL], grpL.op_obj_l, (err, rslt) => {
        pipelineObL.push(...rslt);
      });
      opExClb(null, null);
    }, (err, rslt) => {
      gpExClb(null, null);
    });
  }, (err, rslt) => {

  });
}

function getExSeq(opExS, opObjL) {
  // get op matching execution label and empty properties or
  let opObjMtchL = _.filter(opObjL, { execution_label: opExS });
  // get properties matching execution label
  let prpMtchExLbl = [];
  _.forEach(opObjMtchL, (opObj) => {
    prpMtchExLbl.push(..._.map(
      _.filter(opObj.property_list, { execution_label: opExS })),
      (prp) => { return { property_entity_id: opObj.entity_id, ...prp } });
  });
  // get properties without value, and add them to sequence end as filter
  _.forEach(opObjMtchL, (opObj) => {
    prpMtchExLbl.push(
      ..._.map(_.filter(opObj.property_list, (prp) => {
        if (!prp.hasOwnProperty('execution_label') || prp.execution_label === "" || prp.execution_label === opExS) {
          return true;
        }
      }), (prp) => { return { property_entity_id: opObj.entity_id, ...prp } })
    );
  });
  return prpMtchExLbl;
}

// copy one filter here, and apply all operations
function applyFilter(opL, scopeObL, pipelineObL, fnlClb) {
  let propertyL = _.filter(opL, (op) => {
    return op.hasOwnProperty('ce_property_value');
  });
  let propertyRefL = _.filter(opL, (op) => {
    return !op.hasOwnProperty('ce_property_value');
  });
  let filterL = _.filter(opL, (op) => {
    return op.hasOwnProperty('filter_name') && op.hasOwnProperty('filter') && !_.isEmpty(op.filter);
  });
  let filterRefL = _.filter(opL, (op) => {
    return op.hasOwnProperty('filter_name') && !op.hasOwnProperty('filter');
  });

  async.waterfall([
    function (wfClb) {
      console.log('Property List');
      propertyL = _.map(propertyL, (prp) => {
        if (prp.hasOwnProperty('property_on')) {
          let opEnt = _.find(pipelineObL, { entity_id: prp.property_entity_id });
          opEnt = _.find(pipelineObL, { entity_id: opEnt.containing_entity_id });
          return [
            new EntityProperty(opEnt.entity_id, 'ce_property', prp.ce_property_name, 'value', prp.ce_property_value),
            new EntityProperty(prp.property_entity_id, 'ce_property', prp.ce_property_name, 'ref', '')
          ];
        } else {
          return new EntityProperty(prp.property_entity_id, 'ce_property', prp.ce_property_name, 'value', prp.ce_property_value);
        }
      });
      async.concat(propertyL, (prp, asClb) => {
        if (Array.isArray(prp)) {
          addProperty(prp[0], (err, rslt1) => {
            prp[1].property_value = prp[0].property_id;
            addProperty(prp[1], (err, rslt2) => {
              asClb(err, [rslt1, rslt2]);
            });
          });
        } else {
          addProperty(prp, (err, rslt) => { asClb(err, rslt); });
        }
      }, (err, db_prp) => {
        wfClb(err, _.flattenDeep(db_prp));
      });
    },
    function (propertyList, wfClb) {
      //console.log('Property Pipeline');
      //console.log(_.filter(pipeline, { property_type: 'ref' }));
      // filter type{} invoke the method
        // filter scope
      // console.log('Filter List');         // search scope{entity translates to root entity}, search pipeline
      // console.log(filterL);               // default ref ref, or ref, {entity, property}
      console.log('Filter');
      console.log(scopeObL);
      async.concat(filterL, (flt, asyFlt) => {
        if(flt.hasOwnProperty('filter_type') && flt.filter_type !== '') {
          // containing_entity_id, root_entity_id, and scope          
          scope.push(...entityObjFilter(scope, flt));
          /*
          console.log('New Pipeline');
          console.log(pipeline);          
          console.log(flt.filter_type);
          console.log(flt.filter_name);
          */
        } else {
          console.log(flt.filter_name);
        }        
        asyFlt(null, null);
      }, (err, clb) => {

      });
    },
    function (rslt, wfClb) {
      console.log('Property Ref List');   // find in scope
      console.log(propertyRefL);
    },
    function (rslt, wfClb) {
      console.log('Filter Ref List');     // add refs to refs, search scope, search pipeline
      console.log(filterRefL);
    }
  ], (err, rslt) => {
    fnlClb(null, null)
  });

  return [];
}