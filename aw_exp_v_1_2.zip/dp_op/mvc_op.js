let { opOnEntChRec, Entity, EntityProperty, entPropFilter, addEntityProperty, addEntTree, entityFilter, entityChDec, entityToObj } = require('../db_op/entity_op');
let _ = require('lodash');
exports.mvcDP = function () {
  return {
    dp_head: 'mvc',
    // component filters
    input_entity_label_list: ['table', 'column', 'relation', 'database'],
    application_page_scope_entity_list: [{ entity: 'table', child: ['column', 'relation'], parent: 'database' }],
    call_sequence: ['model', 'controller', 'view', 'final'],
    dp_ent_op: [
      {
        op_list: [['default_add_m', 'default_update_m', 'default_delete_m', 'default_query_m'], 'model']
      },
      {
        op_list: [['controller_remap', 'default_add', 'default_update', 'default_delete', 'default_query'], 'controller']
      },
      {
        op_list: [
          ['header', 'leftnav', ['alert_info', [['form'], 'form_grid'], [
          [[[['default_filter'], 'form_grid'], ['default_pagination', 'default_table']], 'tab']
          [[['default_having'], 'form_grid'], [['default_grouping'], 'form_grid'], [['default_order_by'], 'form_grid'], ['default_pagination', 'default_summary_table'], 'tab'], 'tab_group'], 'content_grid'], 'page_grid'], 'view']
      }
    ],
    dp_op: [
      {
        op_list: [['default_authentication_m', 'default_authorization_m', 'default_create_user_m', 'default_update_user_m', 'default_delete_user_m', 'default_get_user_m'], 'model']
      },
      {
        op_list: [['default_create_user', 'default_update_user', 'default_delete_user', 'default_get_user', 'default_authorize_user'], 'controller']
      },
      {
        op_list: [['header', 'content_grid', ['alert_info', [['login_form'], 'login_form_grid'], 'login_content_grid'], 'page_grid'], 'view']
      },
      {
        // create user form
      }
    ],
    ///*
    op_stmtg: {
      'default_add_m': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = { input_array: 'user_input', method_name: 'add_record' };
        // property ref
        // model method template -> parent
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // input template -> child
        let inputTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // insert template -> child
        let insertTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // console.log('Model, default_add_m');
        // return what needs to be added to scope, what needs to me added to method list
        clbck(null, []);
      },
      'default_update_m': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = { input_array: 'user_input', filter_array: 'filter_input', method_name: 'update_record' };
        // model method template -> parent
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // input template -> child
        let inputTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // filter template -> child
        let filterTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // update template -> child
        let updateTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // console.log('Model, default_update_m');
        clbck(null, []);
      },
      'default_delete_m': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = { filter_array: 'filter_input' };
        // property ref
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // filter template -> child
        let filterTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // update template -> child
        let deleteTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // console.log('Model, default_delete_m');
        clbck(null, []);
      },
      'default_query_m': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {
          input_array: 'user_input',
          filter_array: 'filter_input',
          method_name: 'query_entity'
        };
        // method statement
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // where filter template -> child
        let whereFilterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // having filter template -> child
        let havingFilterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // grouping filter template -> child
        let groupingFilterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // order filter template -> child
        let orderFilterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // select template -> child
        let selectTemplate = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // join template -> child
        let joinTemplate = _.map(entityFilter(page.child, { entity_label: 'relation' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // return template -> child
        let returnTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // console.log('Model, default_query_m');
        clbck(null, []);
      },
      'model_constructor': (op, page, pageList, scope, executionLevel, clbck) => {
        // method statement
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        clbck(null, []);
      },
      'model': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // model statement
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // console.log('Model, model');
        clbck(null, []);
      },
      'default_get_user_m': (op, page, pageList, scope, executionLevel, clbck) => {
        // method statement
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // where filter template -> child
        let whereFilterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // select template -> child
        let selectTemplate = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // join template -> child
        let joinTemplate = _.map(entityFilter(page.child, { entity_label: 'relation' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // return template -> child
        let returnTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // console.log('Model, default_query_m');
        clbck(null, []);
      },
      'default_create_user_m': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Model, default_create_user_m');
        let op_scope = { input_array: 'user_input', method_name: 'add_record' };
        // property ref
        // model method template -> parent
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // input template -> child
        let inputTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // insert template -> child
        let insertUserTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnUserTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // insert template -> child
        let insertUserPrivilageTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnUserPrivilageTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        let returnFinalTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        clbck(null, []);
      },
      'default_update_user_m': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Model, default_update_user_m');
        let op_scope = { input_array: 'user_input', method_name: 'add_record' };
        // property ref
        // model method template -> parent
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // input template -> child
        let filterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // insert template -> child
        let updateUserTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnUserTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // insert template -> child
        let updateUserPrivilageTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnUserPrivilageTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        let returnFinalTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        clbck(null, []);
      },
      'default_delete_user_m': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Model, default_delete_user_m');
        let op_scope = { input_array: 'user_input', method_name: 'add_record' };
        // property ref
        // model method template -> parent
        let parent = { parent: { entity: new Entity(), property: [new EntityProperty()] }, child: [] };
        // input template -> child
        let filterTemplateL = _.map(entityFilter(page.child, { entity_label: 'column' }), (col) => {
          return { entity: new Entity(), property: [new EntityProperty()] };
        });
        // insert template -> child
        let deleteUserTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnUserTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // insert template -> child
        let deleteUserPrivilageTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        // return template -> child
        let returnUserPrivilageTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        let returnFinalTemplate = { entity: new Entity(), property: [new EntityProperty()] };
        clbck(null, []);
      },
      'controller_remap': (op, page, pageList, scope, executionLevel, clbck) => {
        // controller method template,
        // load authentication model and get user details
        // check if the user is authenticated
        // check if the user is authorized
        // call method, or call default and logout user and return to login
        // console.log('Controller, controller_remap');
        clbck(null, []);
      },
      'default_add': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // controller method template
        // check for required fields if missing filed, set error data, set field data
        // load the model and invoke the add method, set return data
        // load view master data
        // load view table data
        // load views
        // console.log('Controller, default_add');
        clbck(null, []);
      },
      'default_update': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // controller method template
        // check for required fields if missing filed, set error data
        // load the model and invoke the update method, set return data
        // load view master data
        // load view table data
        // load views
        // console.log('Controller, default_update');
        clbck(null, []);
      },
      'default_delete': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // controller method template
        // check for required fields if missing filed, set error data
        // load the model and invoke the update method, set return data
        // load view master data
        // load view table data
        // load views
        // console.log('Controller, default_delete');
        clbck(null, []);
      },
      'default_query': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // controller method template
        // check for filter required fields if missing filed, set error data
        // load the model and invoke the select method, set return data
        // load filter master data
        // load view table data
        // load views
        // console.log('Controller, default_query');
        clbck(null, []);
      },
      'controller': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // controller template
        // console.log('Controller, controller');
        clbck(null, []);
      },
      'header': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // header container
        // header url, from view data
        // console.log('View, header');
        clbck(null, []);
      },
      'leftnav': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // leftnav container
        // leftnav url, from view data
        // console.log('View, leftnav');
        clbck(null, []);
      },
      'alert_info': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // alert container, alert class based on return data{loading, alert, info, error, warning}
        // console.log('View, alert_info');
        clbck(null, []);
      },
      'form': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = {};
        // form ui element from column list
        // form grid
        // form action, event
        // console.log('View, form');
        clbck(null, []);
      },
      'form_grid': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, form_grid');
        clbck(null, []);
      },
      'default_filter': (op, page, pageList, scope, executionLevel, clbck) => {
        let op_scope = [];
        // form ui element from column list
        // filter grid
        // form action, event
        // console.log('View, default_filter');
        clbck(null, []);        
      },
      'filter_grid': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, filter_grid');        
        clbck(null, []);
      },
      'default_pagination': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, default_pagination');
        // form ui element from column list
        // pagination grid
        // form action, event
        clbck(null, []);
      },
      'default_table': (op, page, pageList, scope, executionLevel, clbck) => {
        // ref to model query return, primary key, master keys
        let op_scope = {};
        // console.log('View, default_table');
        // table container
        // table, header, cell, row, cell
        // cell action, row action
        clbck(null, []);
      },
      'default_summary_table': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, default_summary_table');
        // table container
        // table, header, cell, row, cell
        // row action
        clbck(null, []);
      },
      'tab': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, tab');
        // tab name, tab action, events
        clbck(null, []);
      },
      'tab_group': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, tab_group');
        // group name, styles, events
        clbck(null, []);
      },
      'content_grid': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, content_grid');
        // {row, column{size}}, styles, events
        clbck(null, []);
      },
      'page_grid': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, page_grid');
        // {row, column{size}}, styles, events
        clbck(null, []);
      },
      'view': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, view');
        // styles, events
        clbck(null, []);
      },
      'default_create_user': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Controller, default_create_user');
        // user form element
        // acl form element
        // form grid
        // form action
        clbck(null, []);
      },
      'default_update_user': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Controller, default_update_user');
        clbck(null, []);
      },
      'default_delete_user': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Controller, default_delete_user');
        clbck(null, []);
      },
      'default_get_user': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Controller, default_get_user');
        // table grid
        // table{header{row, column{action}}, body{row{action}, column{action}}}
        clbck(null, []);
      },
      'acl_controller': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('Controller, acl_controller');
        clbck(null, []);
      },
      'public_header': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, header');
        clbck(null, []);
      },
      'login_form': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, login_form');
        // content grid, form grid
        // login form elements, action, event
        clbck(null, []);
      },
      'default_having': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, login_form');
        // content grid, form grid
        // login form elements, action, event
        clbck(null, []);
      },
      'default_grouping': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, login_form');
        // content grid, form grid
        // login form elements, action, event
        clbck(null, []);
      },
      'default_order_by': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, login_form');
        // content grid, form grid
        // login form elements, action, event
        clbck(null, []);
      },
      'default_summary_table': (op, page, pageList, scope, executionLevel, clbck) => {
        // console.log('View, login_form');
        // content grid, form grid
        // login form elements, action, event
        clbck(null, []);
      }
    },
    //*/
    additional_method: {
      // add view calls to controller -- later
    }
  }
}