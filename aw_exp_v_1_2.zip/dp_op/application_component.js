let _ = require('lodash');
let { entityToObj } = require('../db_op/entity_op');
exports.application_component_list = function(applicationDefinition, metaData) {
  let entity = applicationDefinition.entity;
  let entityChild = applicationDefinition.child_entity;
  let parentEntity = applicationDefinition.parent_entity;
  metaData = _.map(metaData, (mt) => { return entityToObj(mt); });
  let entityL = _.filter(metaData, {entity_label: entity});  
  let apCL = [];
  _.forEach(entityL, (ent) => {
    let entityChildL = {};
    _.forEach(entityChild, (ec) => {
      entityChildL[ec] = _.filter(metaData, {containing_entity_id: ent.entity_id, entity_label: ec});
    });
    apCL.push({entity_name: entity, entity: ent, entity_child_list: entityChildL, parent: _.find(metaData, {entity_id: ent.containing_entity_id, entity_label: parentEntity})});
  });
  return apCL;
}