exports.mvcScaffold = function () {
  let entity_label = { table: 'table', column: 'column', relation: 'relation' };
  let property_name = {
    table_name: 'table_name', column_type: 'column_type', column_size: 'column_size',
    column_key: 'column_key', column_label: 'column_label', label_column: 'label_column',
    column_name: 'column_name', column_comment: 'column_comment',
    '1_table': '1_table', '1_column': '1_column', '2_table': '2_table', '2_column': '2_column'
  };
  let alias_name = {
    method_name_prefix: 'method_name_prefix', model_name: 'model_name', controller_name: 'controller_name'
  }
  let filter_type = {
    find_entity: 'find_entity', filter_entity: 'filter_entity', copy_filter: 'copy_filter', 
    copy_ref: 'copy_ref', action_filter: 'action_filter', step_filter: 'step_filter'
  };
  let filter_name = {
    entity_name: 'entity_name', input_statement: 'input_statement', primary_key_input_filter: 'primary_key_input_filter'
  };
  
  let property_on = { parent: 'parent', self: 'self' };
  let ce_property_name = { template_name: 'template_name', variable_name: 'variable_name', method_name: 'method_name' };
  
  let scope_label = { entity: 'entity', all_scope: 'pipeline', global: 'global' };
  let component_name_obj = {
    find_entity_table: 'find_entity_table', input_field: 'input_field', declare_array: 'declare_array',
    insert_query: 'insert_query', return_result: 'return_result', default_add_m: 'default_add_m',
    primary_key_input_filter: 'primary_key_input_filter',
    update_query: 'update_query', default_update_m: 'default_update_m',
    where_input_filter: 'where_input_filter', default_delete_m: 'default_delete_m', delete_query: 'delete_query',
    having_input_filter: 'having_input_filter', grouping_input_filter: 'grouping_input_filter',
    order_by_filter: 'order_by_filter', write_select: 'write_select', write_join: 'write_join',
    write_where: 'write_where', write_having: 'write_having', write_grouping: 'write_grouping',
    write_order_by: 'write_order_by', default_query_m: 'default_query_m', model: 'model',
    authenticate_user: 'authenticate_user', authorize_user: 'authorize_user', remap: 'remap',
    controller_remap: 'controller_remap', load_model: 'load_model', add_record: 'add_record', valid: 'valid', invalid: 'invalid',
    set_error_message: 'set_error_message', validate_input: 'validate_input', load_form_data: 'load_form_data',
    load_filter_data: 'load_filter_data', load_table_data: 'load_table_data', load_add_view: 'load_add_view',
    default_add: 'default_add', update_record: 'update_record', validate_primary_key_input: 'validate_primary_key_input',
    load_update_view: 'load_update_view', default_update: 'default_update', delete_record: 'delete_record',
    load_delete_view: 'load_delete_view', default_delete: 'default_delete', filter_table_data: 'filter_table_data',
    validate_filter: 'validate_filter', load_query_view: 'load_query_view', default_query: 'default_query', controller: 'controller',
    header: 'header', leftnav: 'leftnav', alert_info: 'alert_info', form: 'form', form_grid: 'form_grid',
    default_filter: 'default_filter', form_grid: 'form_grid', default_pagination: 'default_pagination',
    default_table: 'default_table', tab: 'tab', default_having: 'default_having', form_grid: 'form_grid',
    default_grouping: 'default_grouping', form_grid: 'form_grid', default_order_by: 'default_order_by',
    default_pagination: 'default_pagination', default_summary_table: 'default_summary_table', tab: 'tab',
    tab_group: 'tab_group', content_grid: 'content_grid', page_grid: 'page_grid', view: 'view'
  };
  let execution_seq_obj = {
    model_start: 'model_start', model: 'model', model_end: 'model_end',
    controller_start: 'controller_start', controller: 'controller', controller_end: 'controller_end',
    view_start: 'view_start', view: 'view', view_end: 'view_end',
    controller_view: 'controller_view', final_code: 'final_code'
  };
  return {
    // {property_name: {filter_object, method}}, {application_properties, database_properties}, scope_level
    global_scope: [{ entity: { entity_label: 'application' }, scope: [{ entity_label: 'database' }] }],
    op_group_execution_sequence_label_list: ['scaffold_op', 'entity_op'],
    component_list: [
      {
        group_execution_label: 'entity_op',
        group_execution_sequence_label_list: [
          execution_seq_obj.model_start, execution_seq_obj.model, execution_seq_obj.model_end,
          execution_seq_obj.controller_start, execution_seq_obj.controller, execution_seq_obj.controller_end,
          execution_seq_obj.view_start, execution_seq_obj.view, execution_seq_obj.view_end,
          execution_seq_obj.controller_view, execution_seq_obj.final_code
        ],
        scope_entity_filter: { entity: { entity_label: 'table' }, scope: [{ entity_label: entity_label.column }, { entity_label: 'relation' }] },
        component_list: [
          [
            [
              [[component_name_obj.find_entity_table, [component_name_obj.input_field], component_name_obj.declare_array, component_name_obj.insert_query, component_name_obj.return_result], component_name_obj.default_add_m],
              [[component_name_obj.find_entity_table, [component_name_obj.input_field], component_name_obj.declare_array, [component_name_obj.primary_key_input_filter], component_name_obj.declare_array, component_name_obj.update_query, component_name_obj.return_result], component_name_obj.default_update_m],
              [[component_name_obj.find_entity_table, [component_name_obj.primary_key_input_filter], component_name_obj.declare_array, component_name_obj.update_query, component_name_obj.return_result], component_name_obj.default_delete_m],
              [[component_name_obj.find_entity_table, [component_name_obj.where_input_filter], component_name_obj.declare_array, [component_name_obj.having_input_filter], component_name_obj.declare_array, [component_name_obj.grouping_input_filter], component_name_obj.declare_array, [component_name_obj.order_by_filter], component_name_obj.declare_array, component_name_obj.write_select, component_name_obj.write_join, component_name_obj.write_where, component_name_obj.write_having, component_name_obj.write_grouping, component_name_obj.write_order_by, component_name_obj.return_result], component_name_obj.default_query_m]
            ],
            component_name_obj.model
          ],
          [
            [component_name_obj.authenticate_user, component_name_obj.authorize_user, component_name_obj.remap], component_name_obj.controller_remap,
            [[component_name_obj.load_model, [[component_name_obj.add_record], component_name_obj.valid, [component_name_obj.set_error_message], component_name_obj.invalid], component_name_obj.validate_input, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_table_data, component_name_obj.load_add_view], component_name_obj.default_add],
            [[component_name_obj.load_model, [[component_name_obj.update_record], component_name_obj.valid, [component_name_obj.set_error_message], component_name_obj.invalid], component_name_obj.validate_primary_key_input, [component_name_obj.valid, component_name_obj.invalid], component_name_obj.validate_input, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_table_data, component_name_obj.load_update_view], component_name_obj.default_update],
            [[component_name_obj.load_model, [[component_name_obj.delete_record], component_name_obj.valid, [component_name_obj.set_error_message], component_name_obj.invalid], component_name_obj.validate_primary_key_input, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_table_data, component_name_obj.load_delete_view], component_name_obj.default_delete],
            [[component_name_obj.load_model, [[component_name_obj.filter_table_data], component_name_obj.valid, [component_name_obj.set_error_message, component_name_obj.load_table_data], component_name_obj.invalid], component_name_obj.validate_filter, component_name_obj.load_form_data, component_name_obj.load_filter_data, component_name_obj.load_query_view], component_name_obj.default_query],
            component_name_obj.controller
          ],
          [[component_name_obj.header, component_name_obj.leftnav, [
            component_name_obj.alert_info,
            [[component_name_obj.form], component_name_obj.form_grid],
            [
              [
                [[[[component_name_obj.default_filter], component_name_obj.form_grid], [component_name_obj.default_pagination, component_name_obj.default_table]], component_name_obj.tab]
                [
                [[component_name_obj.default_having], component_name_obj.form_grid],
                [[component_name_obj.default_grouping], component_name_obj.form_grid],
                [[component_name_obj.default_order_by], component_name_obj.form_grid],
                [component_name_obj.default_pagination, component_name_obj.default_summary_table], component_name_obj.tab
                ]
              ],
              component_name_obj.tab_group
            ],
            component_name_obj.content_grid
          ],
          component_name_obj.page_grid], component_name_obj.view]
        ]
      },
      /*
      {
        group_execution_label: 'add_on_op',
        group_execution_sequence_label_list: [
          execution_seq_obj.model_start, execution_seq_obj.model, execution_seq_obj.model_end,
          execution_seq_obj.controller_start, execution_seq_obj.controller, execution_seq_obj.controller_end,
          execution_seq_obj.view_start, execution_seq_obj.view, execution_seq_obj.view_end,
          execution_seq_obj.controller_view, execution_seq_obj.final_code
        ],
        scope_entity_filter: {},
        component_list: [
          [[authenticate_user, authorize_user], login_model],
          [[login_authenticate_user, login_authorize_user], login_controller],
          [[[login_form], login_page_grid], login_view]
        ]
      } */
    ],
    op_object: {
      [component_name_obj.find_entity_table]: {
        execution_label: execution_seq_obj.model_start,
        // make this a filter
        property_list: [
          {
            filter_type: filter_type.find_entity,
            scope: scope_label.entity,
            execution_label: execution_seq_obj.model_start,
            filter_name: filter_name.entity_name,
            filter: [{
              entity_label: entity_label.table
            }],
            reject: [],
            get_property: [property_name.table_name],
            define_an_alias: [alias_name.method_name_prefix, alias_name.model_name, alias_name.controller_name]
          }
        ]
      },      // correct
      [component_name_obj.input_field]: {
        execution_label: execution_seq_obj.model_start,
        // declare statement, set object name in parent element
        property_list: [
          { ce_property_name: ce_property_name.template_name, ce_property_value: 'input_statement' },
          {
            filter_type: filter_type.filter_entity,
            scope: scope_label.entity,
            execution_label: execution_seq_obj.model_start,
            // add filter name as property, and property_label to db
            filter_name: filter_name.input_statement,
            filter: [{ entity_label: entity_label.column }],
            reject: [{ property_name: 'PRI', property_value: 'true' }],
            get_property: [property_name.column_name],
            define_an_alias: []
          },
          {
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'input_array',
            execution_label: execution_seq_obj.model_end
          },
        ]
      },    // correct
      [component_name_obj.declare_array]: {
        execution_label: execution_seq_obj.model,
        // set array name property with empty value
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'array_declaration'
          }
        ]
      },    // correct
      [component_name_obj.insert_query]: {
        execution_label: execution_seq_obj.model_end,
        // query for input array name
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'insert_record_query'
          },
          {
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'query_result'
          },
          {
            ce_property_name: 'input_array'
          }
        ]
      },    // correct
      [component_name_obj.return_result]: {
        execution_label: execution_seq_obj.model_end,
        // query for input array name, declare return array
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'return_result'
          },
          {
            ce_property_name: 'input_array'
          },
          {
            ce_property_name: 'query_result'
          }
        ]
      },      // correct
      [component_name_obj.default_add_m]: {
        execution_label: execution_seq_obj.model_start,
        // get table name property 
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'model_method'
          },
          {
            ce_property_name: 'method_name',
            ce_property_value: 'add_record'
          }
        ]
      },      // correct
      [component_name_obj.primary_key_input_filter]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'primary_key_input_filter'
          },  // correct
          {
            filter_type: filter_type.filter_entity,
            scope: scope_label.entity,
            execution_label: execution_seq_obj.model_start,
            // add filter name as property, and property_label to db
            filter_name: filter_name.primary_key_input_filter,
            filter: [{ entity_label: entity_label.column, property_name: 'PRI', property_value: 'true' }],
            reject: [],
            get_property: ['column_name'],
            define_an_alias: []
          },
          {
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'primary_key_input',
            execution_label: execution_seq_obj.model_end
          },  // correct
        ]
      },  // correct
      [component_name_obj.update_query]: {
        execution_label: execution_seq_obj.model_end,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'update_query'
          },
          {
            ce_property_name: 'input_array'
          },
          {
            ce_property_name: 'primary_key_input'
          }
        ]
      },  // correct
      [component_name_obj.default_update_m]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'model_method'
          },
          {
            ce_property_name: 'method_name',
            ce_property_value: 'update_record'
          }
        ]
      },  // correct
      [component_name_obj.default_delete_m]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'model_method'
          },
          {
            ce_property_name: 'method_name',
            ce_property_value: 'delete_record'
          }
        ]
      },    // correct
      [component_name_obj.delete_query]: {
        execution_label: execution_seq_obj.model_end,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'delete_query'
          },
          {
            ce_property_name: 'primary_key_input'
          }
        ]
      },    // correct
      [component_name_obj.where_input_filter]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            property_value: 'where_input_filter'
          },
          {
            filter_type: filter_type.filter_entity,
            scope: scope_label.entity,
            execution_label: execution_seq_obj.model_start,
            // add filter name as property, and property_label to db
            filter_name: 'label_filter_input',
            filter: [
              { entity_label: entity_label.column, property_name: 'label', property_value: 'true' }, 
              { entity_name: 'relation' /*entity_name.relation*/, property_name: property_name['1_column'] }
            ],
            reject: [],
            get_property: ['column_name'],
            define_an_alias: []
          },
          {
            property_on: property_on.parent, ce_property_name: ce_property_name.variable_name, 
            ce_property_value: 'where_input', execution_label: execution_seq_obj.model_end
          },
        ]
      }, // correct
      [component_name_obj.having_input_filter]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'having_input_filter'
          },
          {
            filter_name: 'label_filter_input'
          },
          {
            property_on: property_on.parent,
            ce_property_name: 'variable_name',
            ce_property_value: 'having_input',
            execution_label: execution_seq_obj.model_end
          },
        ]
      },    // correct
      [component_name_obj.grouping_input_filter]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'grouping_input_filter'
          },
          {
            filter_name: 'label_filter_input'
          },
          {
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'having_input',
            execution_label: execution_seq_obj.model_end
          },
        ]
      },    // correct
      [component_name_obj.order_by_filter]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'order_by_input_filter'
          },
          {
            filter_name: 'label_input_filter'
          },
          {
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'order_input',
            execution_label: execution_seq_obj.model_end
          },
        ]
      },
      [component_name_obj.write_select]: {
        execution_label: execution_seq_obj.model,
        property_list: [
          // ref to primary_key, where, grouping, having
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'select_join'  // add join here only
          },
          // column list
          {
            filter_name: 'column'
          },
          {
            filter_name: 'primary_key_filter'
          },
          {
            filter_name: 'where_filter'
          },
          {
            filter_name: 'having_filter'
          },
          {
            filter_name: 'order_by_filter'
          },
          {
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'select_array'
          }
        ]
      },
      [component_name_obj.write_where]: {
        execution_label: execution_seq_obj.model,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'where_query'
          },
          {
            filter_name: 'where_filter'
          }
        ]
      },
      [component_name_obj.write_having]: {
        execution_label: execution_seq_obj.model,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'having_query'
          },
          {
            filter_name: 'having_filter'
          },
        ]
      },
      [component_name_obj.write_grouping]: {
        execution_label: execution_seq_obj.model,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'grouping_query'
          },
          {
            filter_name: 'grouping_filter'
          },
        ]
      },
      [component_name_obj.write_order_by]: {
        execution_label: execution_seq_obj.model,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'order_by_query'
          },
          {
            filter_name: 'order_by_filter'
          }
        ]
      },
      [component_name_obj.default_query_m]: {
        execution_label: execution_seq_obj.model_end,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'model_method'
          },
          {
            ce_property_name: 'method_name',
            ce_property_value: 'query_record'
          }
        ]
      },
      [component_name_obj.model]: {
        execution_label: execution_seq_obj.model_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'model_class'
          },
          {
            filter_name: filter_name.entity,
            property_value: ['table_name']
          }
        ]
      },
      [component_name_obj.authenticate_user]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          },
          {
            ce_property_name: 'method_name',
            ce_property_value: component_name_obj.authenticate_user
          }
        ]
      },
      [component_name_obj.authorize_user]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          },
          {
            ce_property_name: 'method_name',
            ce_property_value: component_name_obj.authenticate_user
          },
          // filter model name, pipeline

        ]
      },    // Pending
      [component_name_obj.remap]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_remap'
          },
          {
            
          }
        ]
      },  // Pending
      [component_name_obj.controller_remap]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_remap'
          },
          {
            filter_type: filter_type.filter_entity,
            scope: scope_label.pipeline,
            execution_label: execution_seq_obj.controller_start,
            // add filter name as property, and property_label to db
            filter_name: 'authenticate_authorize',
            filter: [
              { entity_label: 'operator', property_name: 'method_name', property_value: component_name_obj.authorize_user },
              { entity_label: 'operator', property_name: 'method_name', property_value: component_name_obj.authenticate_user }
            ],
            reject: [],
            get_property: ['method_name'],
            define_an_alias: []
          },
        ]
      },      // Correct
      [component_name_obj.load_model]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'load_model'
          },
          {
            filter_type: filter_type.step_filter,
            scope: scope_label.pipeline,
            execution_label: execution_seq_obj.controller_start,
            // add filter name as property, and property_label to db
            filter_name: 'load_model',
            filter: [
              { entity_label: 'relation', property_name: '2_table' },
              // check if model containing entity is entity
              { containing_entity_id: '__result.property_value', entity_label: 'model' }
            ],
            reject: [],
            get_property: ['model_name'],
            get_property_value: ['query_record'],
            define_an_alias: []
          },
          {
            filter_type: filter_type.filter_entity,
            scope: scope_label.entity,
            execution_label: execution_seq_obj.controller_start,
            // add filter name as property, and property_label to db
            filter_name: 'entity_model',
            filter: [
              { entity_label: 'model' }
            ],
            reject: [],
            get_property: ['model_name'],
            get_property_value: ['add_record', 'update_record', 'delete_record', 'query_record'],
            define_an_alias: []
          },
        ]
      },
      [component_name_obj.add_record]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'add_record'
          },
          {
            filter_type: filter_type.copy,
            filter_name: 'entity_model',
            reject: [],
            get_property_value: ['add_record'],
            define_an_alias: []
          }
        ]
      },
      [component_name_obj.valid]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'if_condition'
          }
        ]
      },
      [component_name_obj.set_error_message]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'set_input_error'
          },
          {
            // filter add_record model method
            // filter input elements
            filter_name: 'label_filter_input'
          }
        ]
      },
      [component_name_obj.invalid]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'else_condition'
          }
        ]
      },
      [component_name_obj.validate_input]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'validate_input'
          },
          {
            // required fields list
            filter_name: 'label_filter_input'
          },
          {
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'validate_input'
          }
        ]
      },
      [component_name_obj.load_form_data]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form_data'
          },
          {
            // filter add_record model method
            filter_type: filter_type.chain_filter_entity,
            scope: scope_label.pipeline,
            execution_label: execution_seq_obj.controller_start,
            // add filter name as property, and property_label to db
            filter_name: 'entity_model',
            get_property: [],
            get_property_value: ['get_record'],
            define_an_alias: []
          },
          {
            // declare form data array
            property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'update_data',
            execution_label: execution_seq_obj.model_end
          }
        ]
      },
      // Not required
      [component_name_obj.load_filter_data]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'filter_data'
          },
          {
            // load filter fields from input
          },
          {
            // declare form data array
          }
        ]
      },
      // Not required
      [component_name_obj.load_table_data]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'table_data'
          },
          {
            // load filter fields
          },
          {
            // load model data
          }
        ]
      },
      [component_name_obj.load_add_view]: {
        execution_label: execution_seq_obj.controller_view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'load_view'
          },
          {
            // content
            filter_type: filter_type.chain_filter,
            scope: scope_label.pipeline_end,
            execution_label: execution_seq_obj.pipeline_end,
            // add filter name as property, and property_label to db
            filter_name: 'view',
            filter: [
              { entity_label: 'operator', entity_name: component_name_obj.view }
            ],
            reject: [],
            get_property: ['folder_name', 'file_name'],
            define_an_alias: []
          },
        ]
      },
      [component_name_obj.default_add]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          },
          {
            ce_property_name: ce_property_name.method_name,
            ce_property_value: ''
          }
        ]
      },
      [component_name_obj.update_record]: {
        execution_label: execution_seq_obj.controller_end,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'update_record'
          },
          {
            // filter add_record model method
            filter_type: filter_type.chain_filter_entity,
            scope: scope_label.pipeline,
            execution_label: execution_seq_obj.controller_start,
            // add filter name as property, and property_label to db
            filter_name: 'update_record_model_method',
            filter: [
              { entity_label: 'model', __result: 'model_entity' },
              { containing_entity_id: '__result.property_value', entity_label: 'update_record' }
            ],
            reject: [],
            get_property: ['method_name'],
            define_an_alias: []
          }
        ]
      },
      [component_name_obj.validate_primary_key_input]: {
        execution_label: execution_seq_obj.controller_start,
        // change to add to parent
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'input'
          },
          {
            filter_name: 'primary_key_input_filter'
          }
        ]
      },
      [component_name_obj.load_update_view]: {
        execution_label: execution_seq_obj.controller_view
        // no need for this either
      },
      [component_name_obj.default_update]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          }
        ]
      },
      [component_name_obj.delete_record]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          },
          {
            // filter add_record model method
            filter_type: filter_type.chain_filter_entity,
            scope: scope_label.pipeline,
            execution_label: execution_seq_obj.controller_start,
            // add filter name as property, and property_label to db
            filter_name: 'update_record_model_method',
            filter: [
              { entity_label: 'model', __result: 'model_entity' },
              { containing_entity_id: '__result.property_value', entity_label: 'delete_record' }
            ],
            reject: [],
            get_property: ['method_name'],
            define_an_alias: []
          }
        ]
      },
      [component_name_obj.load_delete_view]: {
        // not required
        execution_label: execution_seq_obj.controller_view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'load_view'
          }
        ]
      },
      [component_name_obj.default_delete]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          },
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'delete_record'
          }
        ]
      },
      [component_name_obj.filter_table_data]: {
        execution_label: execution_seq_obj.controller,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'validate_input'
          },
          {
            // required fields list
            filter_name: 'label_filter_input'
          }
        ]
      },
      [component_name_obj.validate_filter]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'validate_input'
          },
          {
            filter_name: 'label_filter_input'
          },
          {
            ce_property_on: property_on.parent,
            ce_property_name: ce_property_name.variable_name,
            ce_property_value: 'label_filter'
          }
        ]
      },
      // not required use default
      [component_name_obj.load_query_view]: {        
        execution_label: execution_seq_obj.controller_view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'query_view'
          },
          // filters
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'load_view'
          },
          {
            // content
            filter_type: filter_type.chain_filter,
            scope: scope_label.pipeline_end,
            execution_label: execution_seq_obj.pipeline_end,
            // add filter name as property, and property_label to db
            filter_name: 'query_view',
            filter: [
              { entity_label: 'operator', entity_name: component_name_obj.view }
            ],
            reject: [],
            get_property: ['folder_name', 'file_name'],
            define_an_alias: []
          }
        ]
      },
      [component_name_obj.default_query]: {
        execution_label: execution_seq_obj.controller_end,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_method'
          },
          {
            ce_property_name: ce_property_name.method_name,
            ce_property_value: 'query_record'
          }
        ]
      },
      [component_name_obj.controller]: {
        execution_label: execution_seq_obj.controller_start,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'controller_class'
          },
          {
            ce_property_name: 'controller_name',
            ce_property_value: alias_name.controller_name
          }
        ]
      },
      [component_name_obj.header]: {
        execution_label: execution_seq_obj.view
      },
      [component_name_obj.leftnav]: {
        execution_label: execution_seq_obj.view
      },
      [component_name_obj.alert_info]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'alert_info'
          },
          {
            ce_property_name: 'return_object'
          }
        ]
      },
      [component_name_obj.form]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form'
          },
          {
            ce_property_name: 'form_action'
          },
          {
            filter_name: 'input_fields'
          },
          {
            filter_name: 'primary_key_field'
          }
        ]
      },
      [component_name_obj.form_grid]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form_grid'
          },
          {
            ce_property_name: component_name_obj.form
          }
        ]
      },
      [component_name_obj.default_filter]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form'
          },
          {
            filter_name: 'label_filter'
          }
        ]
      },
      [component_name_obj.default_pagination]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'pagination'
          },
          {
            filter_name: 'default_query_action'
          }
        ]
      },
      [component_name_obj.default_table]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'default_table'
          },
          {
            ce_property_name: 'table_name',
            ce_property_value: 'entity_name'
          }
        ]
      },
      [component_name_obj.tab]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'tab'
          }
        ]
      },
      [component_name_obj.default_having]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form'
          },
          {
            filter_name: 'label_filter'
          }
        ]
      },
      [component_name_obj.default_grouping]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form'
          },
          {
            filter_name: 'label_filter'
          }
        ]
      },
      [component_name_obj.default_order_by]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'form'
          },
          {
            filter_name: 'label_filter'
          }
        ]
      },
      [component_name_obj.default_summary_table]: {
        // not required
        execution_label: execution_seq_obj.view
      },
      [component_name_obj.tab_group]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'tab_group'
          }
        ]
      },
      [component_name_obj.content_grid]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'content_grid'
          }
        ]
      },
      [component_name_obj.page_grid]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'page_grid'
          }
        ]
      },
      [component_name_obj.view]: {
        execution_label: execution_seq_obj.view,
        property_list: [
          {
            ce_property_name: ce_property_name.template_name,
            ce_property_value: 'view'
          }
        ]
      }
    }
  }
}