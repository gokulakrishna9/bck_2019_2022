exports.view = function() {
  console.log('View');
}

exports.header = function() {
  console.log('Header');
}

exports.leftnav = function() {
  console.log('Left Nav');
}

exports.content_grid = function() {
  console.log('Content Grid');
}

exports.alert_info = function() {
  console.log('Alert Info');
}

exports.alert_error = function() {
  console.log('Alert Error');
}

exports.alert_progress = function() {
  console.log('Alert Progress');
}

exports.form = function() {
  console.log('Form');
}

exports.form_grid = function() {
  console.log('Form Grid');
}

exports.default_pagination = function() {
  console.log('Default Pagination');
}

exports.default_table = function() {
  console.log('Default Table');
}

exports.tab = function() {
  console.log('Tab');
}

exports.default_filter = function() {
  console.log('Default Filter');
}

exports.default_grouping = function() {
  console.log('Default Grouping');
}

exports.default_having = function() {
  console.log('Default Having');
}

exports.default_pagination = function() {
  console.log('Default Pagination');
}

exports.default_summary_table = function() {
  console.log('Default Summary Table');
}

exports.tab_group = function() {
  console.log('Tab group');
}

exports.page_grid = function() {
  console.log('Page grid');
}

