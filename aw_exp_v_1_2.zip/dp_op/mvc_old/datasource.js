let _ = require('lodash');
let { Entity, EntityProperty, entPropFilter, addEntityProperty, addEntTree, entityFilter, entityChDec, entityToObj } = require('../../db_op/entity_op');

exports.model = function (oe, scope, appEl, appDef) {
  console.log('Data source model');
  let mdlE = {
    entity: new Entity('code_entity', oe.entity_name, appEl.entity.application_id, appEl.entity.entity_id),
    property: [
      new EntityProperty(0, 'name', 'model_name', 'string', appEl.entity.table_name + '_Model')
    ]
  }
  return mdlE;
}

exports.default_add = function (oe, scope, appEl, appDef) {
  // ref to oe, appEl{table}, containing would be model component
  // column list
  // template list{input template, insert template, return template}
  let dfAd = {
    entity: new Entity('code_entity', oe.entity_name, appEl.entity.application_id, 0),
    property: [
      new EntityProperty(0, 'component', 'table', 'ref', appEl.entity.entity_id),
      new EntityProperty(0, 'name', 'method_name', 'string', appEl.entity.table_name + '_add_record'),
    ]
  };

  let dfInsert = {
    entity: new Entity('statement_group', 'insert', appEl.entity.application_id, 0),
    property: []
  }

  let colLst = _.map(appEl.entity_child_list.column, (col) => {
    return {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'component', col.column_name, 'ref', col.entity_id)
      ]
    }
  });

  // console.log('Datasource default add');
  // console.log({ parent: dfAd, child: [{ parent: dfInpt, child: colLst }, dfInsert, dfReturn] });
  return { parent: dfAd, child: [{ parent: dfInsert, child: colLst }] };
}

exports.default_update = function (oe, scope, appEl, appDef) {
  // ref to oe, appEl{table}, containing would be model component
  // column list
  // template list{input template, primary key filter template, update template, return template}
  let dfUpd = {
    entity: new Entity('code_entity', oe.entity_name, appEl.entity.application_id, 0),
    property: [
      new EntityProperty(0, 'table', appEl.entity.entity_name, 'ref', appEl.entity.entity_id),
      new EntityProperty(0, 'operator', oe.entity_name, 'ref', oe.entity_id)
    ]
  };
  let pcolLst = _.partition(appEl.entity_child_list.column, { column_key: 'PRI' });
  let dfUpS = {
    entity: new Entity('statement_group', 'update', appEl.entity.application_id, 0),
    property: []
  };
  let ucolLst = _.map(pcolLst[1], (col) => {
    return {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'component', col.column_name, 'ref', col.entity_id)
      ]
    }
  });
  let flInpt = {
    entity: new Entity('statement_group', 'update_filter', appEl.entity.application_id, 0),
    property: []
  };
  let ufcolLst = {};
  if (!_.isEmpty(pcolLst)) {
    ufcolLst = {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'component', pcolLst[0].column_name, 'ref', pcolLst[0].entity_id)
      ]
    };
  }
  //console.log('Datasource default update');
  //console.log({ parent:dfAd, child: [{ parent: dfInpt, child: ucolLst }, {parent: flInpt, child: [ufcolLst]}, dfUpdate, dfUReturn] });
  // add hidden filter ui component
  return { parent: dfUpd, child: [{ parent: dfUpS, child: [...ucolLst, { parent: flInpt, child: [ufcolLst] }] }] };
}

exports.default_delete = function (oe, scope, appEl, appDef) {
  // ref to oe, appEl{table}, containing would be model component
  // column list
  // template list{input template, primary key filter template, delete template, return template}
  let dfdl = {
    entity: new Entity('code_entity', oe.entity_name, appEl.entity.application_id, 0),
    property: [
      new EntityProperty(0, 'table', appEl.entity.entity_name, 'ref', appEl.entity.entity_id),
      new EntityProperty(0, 'operator', oe.entity_name, 'ref', oe.entity_id)
    ]
  };
  let pcol = _.find(appEl.entity_child_list.column, { column_key: 'PRI' });
  let dLC = {
    entity: new Entity('statement_group', 'delete', appEl.entity.application_id, 0),
    property: []
  };
  let dfColLst = {}
  if (!_.isEmpty(pcol)) {
    dfColLst = {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'component', pcol.column_name, 'ref', pcol.entity_id)
      ]
    };
  }
  let dfDelete = {
    entity: new Entity('statement_group', 'delete_filter', appEl.entity.application_id, 0),
    property: []
  }
  //console.log('Datasource default delete');
  //console.log({ parent: dfdl, child: [{ parent: flInpt, child: [dfcolLst] }, dfDelete, dfDReturn] });
  // add hidden filter ui component
  return { parent: dfdl, child: [{ parent: dLC, child: [{ parent: dfDelete, child: [dfColLst] }] }] };
}

exports.default_query = function (oe, scope, appEl, appDef) {
  // ref to oe, appEl{table}, containing would be model component
  // column list, master label list, filter list
  // template list{filter template, select expression, select statement, join template, where template, group template, return template}
  let dfSlq = {
    entity: new Entity('code_entity', oe.entity_name, appEl.entity.application_id, 0),
    property: [
      new EntityProperty(0, 'table', appEl.entity.entity_name, 'ref', appEl.entity.entity_id),
      new EntityProperty(0, 'operator', oe.entity_name, 'ref', oe.entity_id)
    ]
  };
  let pcol = _.filter(appEl.entity_child_list.column, { column_key: 'PRI' });
  let lblLst = _.filter(appEl.entity_child_list.column, { label_column: true });
  let flCl = {};
  if (!_.isEmpty(pcol)) {
    flCl = pcol[0]
  }
  if (!_.isEmpty(lblLst)) {
    flCl = { ...flCl, ...lblLst };
  }
  let wfcolLst = [];
  let mstLst = _.filter(appEl.entity_child_list.relation, { entity_name: 'master' });
  let mstFlLst = _.map(mstLst, (ms) => {
    return {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'column', '1_column', 'ref', ms['1_column'].property_value)
      ]
    }
  });
  let wflTmpl = {
    entity: new Entity('statement_group', 'where_filter', appEl.entity.application_id, 0),
    property: []
  };
  let wfColLst = [];
  if (!_.isEmpty(flCl)) {
    wfColLst.push(..._.map(flCl, (cl) => {
      //console.log(cl);
      return {
        entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
        property: [
          new EntityProperty(0, 'column', cl.column_name, 'ref', cl.entity_id)
        ]
      }
    }));
    wfColLst.push(...mstFlLst);
  }
  let dfSelect = {
    entity: new Entity('statement_group', 'select_template', appEl.entity.application_id, 0),
    property: []
  }
  let selectElem = _.map(appEl.entity_child_list.column, (cl) => {
    return {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'column', cl.column_name, 'ref', cl.entity_id)
      ]
    }
  });
  selectElem.push(_.flattenDeep(_.map(mstLst, (ms) => {
    return {
      entity: new Entity('t_parameter_l', 'column', appEl.entity.application_id, 0),
      property: [
        new EntityProperty(0, 'component', 'column', 'ref', ms['select_col'].property_value)
      ]
    }
  })));
  // where, having, grouping --> done  
  let grpTmpl = { entity: new Entity('statement_group', 'sql_group', appEl.application_id, 0), property: [] }
  let grpcolLst = mstFlLst;
  let hfTmpl = { entity: new Entity('statement_group', 'having_group', appEl.application_id, 0), property: [] };
  let hfcolLst = _.map(wfcolLst, (wf) => { return wf; });
  //console.log('Only Query');
  //console.log('Datasource default update');
  //console.log({ parent: dfSlq, child: [{ parent: wflTmpl, child: wfColLst }, { parent: dfSelect, child: [{ parent: dfSelectExp, child: selectElem }] }, { parent: grpTmpl, child: [{ parent: grpExpTmpl, child: grpcolLst }] }, { parent: hfTmpl, child: [{ parent: hfExTmpl, child: hfcolLst }] }, selectReturn] });
  return { parent: dfSlq, child: [{ parent: wflTmpl, child: [...wfColLst, { parent: dfSelect, child: [selectElem] }, { parent: grpTmpl, child: [grpcolLst] }, { parent: hfTmpl, child: [hfcolLst] }] }] };
}