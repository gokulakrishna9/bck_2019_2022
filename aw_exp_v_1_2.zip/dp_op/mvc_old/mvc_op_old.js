exports.mvcDP = function () {
  return {
    dp_folder: 'mvc',
    // component filters
    application_definition: { entity: 'table', child_entity: ['column', 'relation'], parent_entity: 'database' },
    component_graph: [
      { parent_group: ['datasource', 'access_control_m'], child_group: ['middleware', 'access_control_c'] },
      { parent_group: ['middleware'], child_group: ['page'] },
      { parent_group: ['access_control_c'], child_group: ['access_control_lp'] },
    ],
    dp_op: [
      {
        op_group: 'datasource', component: 'model', op_list: [
          'default_add', 'default_update',
          'default_delete', 'default_query'
        ]
      },
      {
        op_group: 'access_control_m', component: 'model', op_list: [
          'default_authentication', 'default_authorization', 'default_create_user', 'default_update_user', 'default_delete_user', 'default_get_user'
        ]
      },
      {
        op_group: 'middleware', component: 'controller', op_list: [
          'default_authentication', 'default_authorization', 'default_add', 'default_update',
          'default_delete', 'default_query'
        ]
      },
      {
        op_group: 'page', component: 'view', op_list: [
          ['header', 'leftnav',
            [['alert_info', 'alert_error', 'alert_progress'],
            ['form', 'form_grid'],
            [[['default_filter', 'form_grid'],
            ['default_pagination', 'default_table'], 'tab'],
            [['default_filter', 'form_grid']
            ['default_grouping', 'form_grid'],
            ['default_having', 'form_grid'],
            ['default_pagination', 'default_summary_table'], 'tab'], 'tab_group'], 'content_grid'], 'page_grid']
        ]
      },
      {
        op_group: 'access_control_c', component: 'controller', op_list: [
          'default_create_user', 'default_update_user', 'default_delete_user', 'default_get_user'
        ]
      },
      {
        op_group: 'access_control_lp', component: 'view', op_list: ['header', 'content_grid', [['alert_info', 'alert_error', 'alert_progress'], ['login_form', 'login_form_grid'], 'login_content_grid'], 'page_grid']
      }
    ]
  }
}