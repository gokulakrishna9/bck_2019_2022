exports.controller = function() {
  console.log('Controller');
  // name, template
}

exports.default_authentication = function() {
  console.log('Default Authentication');
  // authentication parameters
}

exports.default_authorization = function() {
  console.log('Default Authorization');
  // authorization parameters
}

exports.default_page = function() {
  // load all page components
}

exports.default_add = function() {
  console.log('Default Add');
  // required fields
}

exports.default_update = function() {
  console.log('Default Update');
  // required fields
}

exports.default_delete = function() {
  console.log('Default Delete');
  // required fields
}

exports.default_query = function() {
  console.log('Default Query');
  // required fields
}