let _ = require('lodash');
let { entityFilter, entityToObj, entPropFilter } = require('../../db_op/entity_op');

exports.code_entity = function (metaDataL) {
  console.log('Code Entity');
  // group_by- 'database', 'table', 'column', 'relation'
  metaDataL = _.map(metaDataL, (md) => {return entityToObj(md);});
  let dbL = _.filter(metaDataL, {entity_label: 'database'});
  let ceL = [];
  _.forEach(dbL, (db) => {
    let tblL = _.filter(metaDataL, { containing_entity_id: db.entity_id, entity_label: 'table' });    
    let tblO = [];
    _.forEach(tblL, (tbl) => {
      let colL = _.filter(metaDataL, { containing_entity_id: tbl.entity_id, entity_label: 'column' });
      let relL = _.filter(metaDataL, { containing_entity_id: tbl.entity_id, entity_label: 'relation' });
      tblO.push({ 
        table: tbl, 
        column_list: _.map(colL, (col) => entityToObj(col)), 
        relation_list: _.map(relL, (rel) => entityToObj(rel)) 
      });
    });
    ceL.push({ database: db, table_list: tblO });
  });
  //console.log('Code Entity List');
  //console.log(ceL);
  return ceL;
}