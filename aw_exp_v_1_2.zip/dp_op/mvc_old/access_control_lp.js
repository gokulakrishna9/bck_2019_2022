exports.view = function() {
  console.log('Login View');
}

exports.header = function() {
  console.log('Login Header');
}

exports.content_grid = function() {
  console.log('Login Content Grid');
}

exports.alert_info = function() {
  console.log('Login Alert Info');
}

exports.alert_error = function() {
  console.log('Login Error Info');
}

exports.alert_progress = function() {
  console.log('Alert Progress');
}

exports.login_form = function() {
  console.log('Login Form')
}

exports.login_form_grid = function() {
  console.log('Login Form Grid');
}

exports.login_content_grid = function() {
  console.log('Login Content Grid');
}

exports.page_grid = function() {
  console.log('Login Page Grid');
}