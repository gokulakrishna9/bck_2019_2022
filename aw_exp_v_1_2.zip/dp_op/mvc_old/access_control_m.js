exports.model = function() {
  console.log('Access control, model');
}

exports.default_authentication = function() {
  console.log('Default Authentication');
}

exports.default_authorization = function() {
  console.log('Default Authorization');
}

exports.default_create_user = function() {
  console.log('Default Create User');
}

exports.default_update_user = function() {
  console.log('Default Update User');
}

exports.default_delete_user = function() {
  console.log('Default Delete User');
}

exports.default_get_user = function() {
  console.log('Default Get User');
}