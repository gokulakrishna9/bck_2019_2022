let _ = require('lodash');
let async = require('async');
let {
  entityFilter, Entity, EntityProperty, addEntTree,
  addProperty, entityObjFilter, opRootEntity, addRefProperty,
  getEntityList, entPropFilter, findProp
} = require('../db_op/entity_op');
let { isString, isObjectEmpty } = require('../helper_op/object');

exports.writeFrameworkToDB = function (dpPObj, dbObjL, languageFrameworkL, fnlClb) {
  let applicationId = dbObjL[0].entity.application_id;
  // entity filter
  console.log('Write Framework to DB')
  _.forEach(dpPObj.component_list, (com) => {
    let filter = entityFilterList(dbObjL, com.scope_entity_filter);
    com.dbEntityL = _.map(filter, (fl) => { return fl.entity; });
    com.dbScopeL = _.map(filter, (fl) => { return fl.scope; });
  });
  // New code comes here
  async.waterfall([
    function (wfToDBClb) {
      console.log('Write components to DB');
      async.concat(dpPObj.component_list, (com, ascLClb) => {
        let dpEOpL = [];
        if (_.isEmpty(com.dbEntityL)) {
          dpEOpL.push(dpOEpL(com.component_list, 0, dpPObj.op_object, applicationId));
        } else {
          _.forEach(com.dbEntityL, (dbE) => {
            dpEOpL.push(dpOEpL(com.component_list, dbE.entity.entity_id, dpPObj.op_object, applicationId));
          });
        }
        dpEOpL = _.flattenDeep(dpEOpL);
        addEntTree(dpEOpL, (err, dpEOpLR) => {
          ascLClb(err, dpEOpLR);
        });
      }, (err, opLst) => {
        wfToDBClb(err, opLst);
      });
    },    // call filters
    function (opLstDB, wfToDBClb) {
      console.log('Get Component Properties by execution sequence');
      let exSeq = [];
      _.forEach(dpPObj.op_group_execution_sequence_label_list, (ges) => {
        let cL = _.filter(dpPObj.component_list, { group_execution_label: ges })[0];
        if (isObjectEmpty(cL))
          return;
        _.forEach(cL.group_execution_sequence_label_list, (gs) => {
          exSeq.push(gs);
        });
      });
      let scpObjL = _.map(dpPObj.component_list, (com) => {
        return com.dbScopeL;
      });
      scpObjL = _.flattenDeep(scpObjL);
      applyFilter(opLstDB, exSeq, scpObjL, dpPObj.op_object, applicationId, (err, scaffFinalObjL) => {
        wfToDBClb(err, scaffFinalObjL);
      });
    },
    function (scaffFinalObjL, wfToDBClb) {
      // write template to db, move this to another location, later
      // 
    },
    function (scaffTempObjL, wfToDBClb) {
      // find all operators with not containing element
      // write to file
    }
  ], (err, rslt) => {
    console.log(err);
  });
}

function applyFilter(opLstDB, exSeq, scopeObL, opPrpFlL, applicationId, fnlClb) {
  opPrpFlL = _.map(opPrpFlL, (op, opName) => {
    return _.map(op.property_list, (prp) => { return { op_name: opName, ...prp } });
  });
  opPrpFlL = _.flattenDeep(opPrpFlL);
  let propertyL = _.filter(opPrpFlL, (op) => {
    return op.hasOwnProperty('property_on');
  });
  let filterL = _.filter(opPrpFlL, (op) => {
    return op.hasOwnProperty('filter_name') && op.hasOwnProperty('filter_type') && !_.isEmpty(op.filter_type);
  });

  async.concat(propertyL, (prp, prpOnClb) => {
    // get property name containing element list
    // for each element in the element list get parent till head is found MAKE THIS A METHOD
    let refPrp = addPropertyToParent(prp, opLstDB);
    addRefProperty(refPrp, (err, refPrpDL) => {          // write this method
      prpOnClb(err, refPrpDL);
    });                                                 // all known properties are in db
  }, (err, rslt) => {
    ///*
    async.concatSeries(exSeq, (exs, exsClb) => {
      console.log('Added Property List');
      async.waterfall([
        // get all op objects join, where on application
        function (flwClb) {
          console.log('Waterfall first method');
          getEntityList({ application_id: applicationId, entity_label: 'operator' }, (err, opEntL) => {
            let flL = _.filter(filterL, { execution_label: exs });
            let aEntL = [...scopeObL, ...opEntL];
            async.concat(flL, (flt, asfltClb) => {
              if (flt.filter_type == 'find_entity') {
                // copy ref
                // scope condition, same root entity
                // get op list by using op name from filter
                //entity: 'entity', all_scope: 'pipeline' 
                findEntity(aEntL, opEntL, flt);
              } else if (flt.filter_type == 'filter_entity') {
                // copy ref
                if (flt.scope_type == 'entity') {
                  filterEntity(scopeObL, opEntL, flt);
                } else if (flt.scope_type == 'pipeline') {
                  filterEntity(opEntL, opEntL, flt);
                }
              } else if (flt.filter_type == 'copy_filter') {
                // copy property
                if (flt.scope_type == 'entity') {
                  copyFilter(scopeObL, opEntL, flt);
                } else if (flt.scope_type == 'pipeline') {
                  copyFilter(opEntL, opEntL, flt);
                }
              } else if (flt.filter_type == 'action_filter') {
                // execute action and get property
                if (flt.scope_type == 'entity') {
                  actionFilter(scopeObL, opEntL, flt);
                } else if (flt.scope_type == 'pipeline') {
                  actionFilter(opEntL, opEntL, flt);
                }
              } else if (flt.filter_type == 'step_filter') {
                // copy ref
                if (flt.scope_type == 'entity') {
                  stepFilter(scopeObL, opEntL, flt);
                } else if (flt.scope_type == 'pipeline') {
                  stepFilter(opEntL, opEntL, flt);
                }
              }
              asfltClb(null, null);
            }, (err, filterDB) => {
              flwClb(null, null)
            });
          });
        },
        function (rslt, flwClb) {
          /*/ filterRefL
          let propertyRefL = _.filter(opObjectL, (op) => {
            return !op.hasOwnProperty('ce_property_value');
          });
          */
          flwClb(null, null);
        }
      ], (err, rslt) => {
        exsClb(null, null);
        // property ref list
      });
    }, (err, rslt) => {
      // final call back
    });
    //*/
  });
  ///*

  //*/
  // get all scope filters
  // iterate through execution labels on scope filter/nested or normal
  // query db for each datapoint
  // apply scope filters write to db
  // get all pipeline filters
  // iterate through execution labels on pipeline filters/nested or normal
  // query db for each datapoint
  // add to db
}

function dpOEpL(opL, rtEntityId, opObjL, applicationId) {
  let opEL = [];
  let chOpL = [];
  _.forEach(opL, (op) => {
    if (op === undefined)
      return;
    if (!_.isString(op) && Array.isArray(op)) {
      chOpL.push(...dpOEpL(op, rtEntityId, opObjL, applicationId));
    } else {
      let opPrp;
      if (opObjL.hasOwnProperty(op)) {
        opPrp = opObjL[op];
        opPrp = _.map(_.filter(opPrp.property_list, (prp) => {
          return prp.hasOwnProperty('ce_property_value') && !prp.hasOwnProperty('property_on');
        }), (prp) => {
          return new EntityProperty(0, 'property', prp.ce_property_name, 'string', prp.ce_property_value);
        });
      }
      if (_.isEmpty(opPrp))
        opPrp = [];
      if (!_.isEmpty(chOpL)) {
        opEL.push({ parent: { entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op), new EntityProperty(0, 'root_entity', 'ce_ref', 'ref', rtEntityId), ...opPrp] }, child: chOpL });
        chOpL = [];
      } else {
        opEL.push({ entity: new Entity('operator', op, applicationId, 0), property: [new EntityProperty(0, 'operator', 'operator_name', 'op', op), new EntityProperty(0, 'root_entity', 'ce_ref', 'ref', rtEntityId), ...opPrp] });
      }
    }
  });

  if (_.isEmpty(opEL))
    opEL = chOpL;
  return opEL;
}

function entityFilterList(dbObjL, filter) {
  if (isObjectEmpty(filter))
    return [];
  let entityL = entityFilter(dbObjL, filter.entity);
  let entSL = [];
  _.forEach(entityL, (entity) => {
    let entS = [];
    _.forEach(filter.scope, (scp) => {
      let entSF = entityFilter(dbObjL, { ...scp, containing_entity_id: entity.entity.entity_id });
      entS.push(...entSF, entity);
    });
    entSL.push({ entity: entity, scope: entS });
  });
  return entSL;
}

function addPropertyToParent(prp, dbOpL) {
  // from prp get op name // from op name get op list
  let opList = entityFilter(dbOpL, { entity_name: prp.op_name });
  // for each op list get parent
  let opPL = [];
  _.forEach(opList, (op) => {
    opPL.push({ op: op, op_p: entityFilter(dbOpL, { entity_id: op.entity.containing_entity_id })[0] });
  });
  // for each op list get root
  let opRt = [];
  _.forEach(opPL, (op) => {
    if (isObjectEmpty(op.op_p))
      return;
    opRt.push({ op_rt: opRootEntity(dbOpL, op.op_p), ...op });         // Pending method
  });
  let opRtP = _.map(opRt, (op) => {
    return {
      property: new EntityProperty(op.op_rt.entity.entity_id, 'property', prp.ce_property_name, 'string', prp.ce_property_value),
      ref_list: [
        new EntityProperty(op.op.entity.entity_id, 'ref_property', prp.ce_property_name, 'ref', 0),
        new EntityProperty(op.op_p.entity.entity_id, 'ref_property', prp.ce_property_name, 'ref', 0)
      ]
    }
  });
  return opRtP[0];
}

function findEntity(entityList, opLst, filter) {
  let opL = entityFilter(opLst, { entity_name: filter.op_name });
  // scope{search for entity with root_entity property} vs pipeline{search entire pipeline}
  /*
  _.forEach(entityList, (el) => {
    console.log(el.property);
  })
  */
  
  async.concat(opL, (op, opLClb) => {
    if (filter.scope == 'entity') {
      let opRtEId = findProp(op, { property_label: 'root_entity' });
      // bug at entPropFilter
     let sEntL = entityObjFilter(entityList, { filter: [{ property_label: 'root_entity', property_value: opRtEId.property_value }, { entity_id: opRtEId.property_value }, {containing_entity_id: opRtEId.property_value}] });
     /*
     _.forEach(sEntL, (el) => {
      console.log(el);
     })
     */
      //let entPrp = entityObjFilter(sEntL, filter);
    } else if (filter.scope == 'pipeline') {

    }
    // add property to db
    opLClb(null, null);
  }, (err, rslt) => {

  });
  //console.log(entityList);
  //console.log('Entity List');
  //console.log(filter);
  //console.log('Filter List');
}

function filterEntity(entityList, opLst, filter) {

}

function copyFilter(entityList, opLst, filter) {

}

function actionFilter(entityList, opLst, filter) {

}

function stepFilter(entityList, opLst, filter) {

}