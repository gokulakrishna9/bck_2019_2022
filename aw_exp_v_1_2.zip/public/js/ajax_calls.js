function getData(url, domClb) {
  console.log('In Ajax get Data');
  $.get(url, function (data, status) {
    _.forEach(data, (dt) => {
      console.log("Data: " + dt);
    });
    domClb(data);
  });
}

function postData(url, formData, domClb) {
  $.ajax({
    type: 'post',
    url: url,
    data: JSON.stringify(formData),
    contentType: "application/json; charset=utf-8",
    traditional: true,
    success: function (response) {
      console.log('Ajax Post Data');
      console.log(response);
      domClb(response)
    }
  });
}