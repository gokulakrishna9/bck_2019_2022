let elementObj = {
  checkbox: _.template(`<input class="w3-check" type="checkbox" name="<%= name %>" value="<%= value %>"><label><%= element_string %></label>`),
  anchor: anchor,
  modal: entityModal
};

function anchor(anchorObj) {
  let property = _.reject(anchorObj.property, (prp) => {
    let prpName = Object.keys(prp)[0];
    return !prpName == 'button_label';
  });
  property = _.map(property, (prp) => {
    return Object.keys(prp)[0] + "='" + prp[Object.keys(prp)[0]] + "'";
  });
  property = _.join(property, ' ');
  let lnkLbl = _.find(anchorObj.property, (prp) => {
    let prpName = Object.keys(prp)[0];
    return !prpName == 'button_label';
  });
  if (typeof lnkLbl !== 'object' || lnkLbl !== null || !lnkLbl.hasOwnProperty('button_label'))
    lnkLbl = { button_label: 'button_label_nd' };
  let tmple = _.template(`<button <%=property %>><%= button_label %></a>`);
  return tmple({ property: property, button_label: lnkLbl.button_label });
}

function entityModal() {

}

function grid(data, elementProperty, colSize) {
  let row = _.template(`<div class='w3-row'><%= col_list %></div>`);
  let col = _.template(`<div class='w3-col m4'><%= col_str %></div>`);
  let elem = elementProperty.hasOwnProperty('element') ? elementObj[elementProperty.element] : _.template(` <%= element_string %> `);
  let rowChunk = _.chunk(data, colSize);
  let hrowLst = [];
  _.forEach(rowChunk, (rowLst) => {
    let colLst = [];
    _.forEach(rowLst, (rowEle) => {
      colLst.push(col({ col_str: elem({ ...elementProperty, ...rowEle }) }));
    });
    hrowLst.push(row({ col_list: _.join(colLst, '\n') }));
  });
  return _.join(hrowLst, '\n');
}

function tableDS(tblData) {
  console.log(tblData);
  let tableStart = _.template(`<table class="w3-table w3-striped">`);
  let tableEnd = _.template(`</table>`);
  let headerEle = _.template(`<th><%= header_data %></th>`);
  let dataRow = _.template(`<tr><%= row_data %></tr>`);
  let dataElement = _.template(`<td><%= cell_data %></td>`)
  let entName = _.map(tblData, (dt) => { return _.find(dt.entity_property, { entity_label: 'property', entity_name: 'name' }); });
  // head label list
  let headLbl = [
    { col_name: 'entity_group', col_label: 'Entity Group', element: 'th' },
    { col_name: 'entity_label', col_label: 'Entity Label', element: 'th' },
    { col_name: 'entity_name', col_label: 'Entity Name', element: 'th' },
    { col_name: 'property_name', col_label: 'Property Name', element: 'th' },
    { col_name: 'property_value', col_label: 'Property Value', element: 'th' },
    { col_name: 'view_entity', col_label: 'View Entity', element: 'th' },
    /*
    { col_name: 'update_entity', col_label: 'Update Entity', element: 'th' },
    { col_name: 'add_property', col_label: 'Add Property', element: 'th' },
    */
  ];
  let bodyMap = [];
  _.forEach(tblData, (ent) => {
    // entity - filter entity, entity_property, entity_object, child_entity, parent_entity    
    if (Array.isArray(ent.entity)) {
      bodyMap.push(..._.map(ent.entity, (et) => { return { property: { ...et, entity_group: 'Filter Entity' }, op: {} }; }));
    } else {
      bodyMap.push({ property: { ...ent.entity, entity_group: 'Filter Entity' }, op: {} });
    }
    bodyMap.push(..._.map(ent.entity_property, (et) => { return { property: { ...et, entity_group: 'Property' }, op: {} }; }));
    bodyMap.push({ property: { ...ent.entity_object, entity_group: 'Entity Object' }, op: {} });
    bodyMap.push(..._.map(ent.parent_entity, (et) => {
      let query = JSON.stringify((JSON.stringify({ entity_id: et.entity_id })));
      return {
        property: { ...et, entity_group: 'Parent' },
        op: {
          view_entity: { element: 'anchor', property: [{ onclick: "runQuery(" + query + ")" }, { class: 'w3-button' }] },
        }
      };
    }));
    bodyMap.push(..._.map(ent.child_entity, (et) => {
      let query = JSON.stringify((JSON.stringify({ entity_id: et.entity_id })));
      return {
        property: { ...et, entity_group: 'Child' },
        op: {
          view_entity: { element: 'anchor', property: [{ onclick: "runQuery(" + query + ")" }, { class: 'w3-button' }] },
        }
      };
    }));
  });
  console.log(bodyMap);
  // row list, op list
  let tableBody = [];
  let hdr = dataRow({
    row_data: _.join(_.map(headLbl, (hd) => {
      return headerEle({ header_data: hd.col_label });
    }), ' ')
  });
  tableBody.push(tableStart({}));
  tableBody.push(hdr)
  _.forEach(bodyMap, (obj) => {
    let row = _.map(headLbl, (hd) => {
      if (obj.property.hasOwnProperty(hd.col_name))
        return dataElement({ cell_data: obj.property[hd.col_name] });
      else if (obj.op.hasOwnProperty(hd.col_name)) {
        let elStr = elementObj[obj.op[hd.col_name].element](obj.op[hd.col_name]);
        return dataElement({ cell_data: elStr });
      } else {
        return dataElement({ cell_data: ' ' });
      }
    });
    tableBody.push(dataRow({ row_data: _.join(row, ' ') }));
  });
  tableBody.push(tableEnd());
  return _.join(tableBody, '\n');
}