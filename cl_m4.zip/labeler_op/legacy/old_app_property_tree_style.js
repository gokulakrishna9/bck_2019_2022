let _ = require('lodash');
let async = require('async');
let { writeFile } = require('../../file_op/write_to_file');
let { getFolderList } = require('../../file_op/read_file');
let { readFiles } = require('../../file_op/read_file');

let scaffoldFolder = './scaffold/';
exports.appList = function (commandObj, callback) {
  getFolderList(scaffoldFolder, (err, result) => { _.forEach(result, (rs) => { console.log(rs); }); callback() });
}

/*
'select_entity_add_property',
'app_name: app_name->app_value', 
'filter: filter->property=prp_val1[&|]property=prp_val2>filter_op>filter_label, property>prp_val1[|]prp_val2>filter_op>filter_label,...', 
'filter_op(empty, sub_string, size_less_than, size_greater_than)', 
'Property((entity_name...entity_name.property_name), empty)', 
'set: set->property_name>property_value+property_name>property_value>filter_label, property_name>property_value',
'combine_filter: combine_filter:filter_label[&|]filter_label, filter_label[&|]filter_label, ...',
'Array operation is multi-element'
*/
exports.selectEntityAddProperty = function (commandObj, callback) {
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' })[0].property_value[0];
  if (_.isEmpty(appName)) {
    console.log('Set the app_name property');
    callback();
    return;
  }
  async.waterfall([
    function (cb) {
      let file = [];
      getFolderList(scaffoldFolder + '/' + appName, (err, folders) => {
        if (err) {
          console.log('Error!');
          console.log(err);
        }
        _.forEach(folders, (folder) => {
          // get files from each folder
          readFiles(scaffoldFolder + appName + '/' + folder, (err, files) => {
            file.push(..._.map(files, (file) => { return { ...file, frm_folder: folder, content: JSON.parse(file.content) }; }));
            cb(err, file);
          });
        });
      });
    },
    function (files, cb) {
      // check if commandObj.properties has filter set
      // 'filter: filter->folder_name>property>prp_val>filter_op>filter_label, folder_name>property>prp_val>filter_op>filter_label, ...',
      let filterProperty = _.filter(commandObj.properties, { property_name: 'filter' });
      if (!_.isEmpty(filterProperty)) {
        let filter = [];
        _.forEach(filterProperty, (prop) => {
          _.forEach(prop.property_value, (pv) => {
            let p = _.split(pv, '>');
            filter.push({ folder: p[0], property: p[1], filter_op: p[2], filter_value: p[3], filter_label: p.length > 4 ? p[4] : '' });
          });
        });
        // get labeled properties
        let lbld = _.filter(filter, (pr) => { return !_.isEmpty(pr.filter_label); });
        // apply the folder
        let selection = [];
        console.log(filter);
        _.forEach(filter, (fl) => {
          let pL = _.split(fl.property, '.');
          console.log(pL);
          let fileArray = _.filter(files, { frm_folder: fl.folder });
          // Got the corresponding object
          _.forEach(fileArray, (fil) => {
            let ob = fil.content;
            _.forEach(pL, (pN) => {
              console.log(pN);
              ob = ob[pN];
              if(Array.isArray(ob)) {
                return false;
              }
            });
            console.log(ob);
          });          
        });
        // apply the properties
        // perform filter search
        // update if requried
        // write to file
      }
      else {
        _.forEach(files, (file, folder) => {
          // get object keys   
          console.log(folder);
          _.forEach(file, (fl) => {
            let keyVal = objectStr(fl.content);
            console.log(_.join(_.compact(_.split(keyVal, ',')), '\n'));
            return false;
          });
        });
      }
      cb(null, files);
    }
  ], (err, rslt) => { callback() });
}

function objectStr(fl, p = '') {
  let tree = '';
  p = _.isEmpty(p) ? '' : p + ' > ';
  // check if object, if object, get keys and return
  // if array get first element check if object, get keys and return
  if (typeof fl != 'string' && typeof fl === 'object' && typeof fl !== 'undefined' && fl !== null) {
    let keys = [];
    if (Array.isArray(fl) && !_.isEmpty(fl)) {
      keys = Object.keys(fl[0]);
    } else {
      keys = Object.keys(fl);
    }
    _.forEach(keys, (key) => {
      let ck = _.isEmpty(p) ? '' : key + ' > ';
      tree += p + ck + objectStr(fl[key], p + key) + ',';
    });
  } else if (typeof fl == 'string') {
    tree += p + ',';
  }
  return tree.length == 0 ? '' : tree;
}

function getElement(fl) {

}


function objectTree(fl) {
  let tree = [];
  // check if object, if object, get keys and return
  // if array get first element check if object, get keys and return
  if (typeof fl === 'object' && typeof fl !== 'undefined' && fl !== null) {
    let keys = [];
    if (Array.isArray(fl) && !_.isEmpty(fl)) {
      keys = Object.keys(fl[0]);
    } else {
      keys = Object.keys(fl);
    }
    _.forEach(keys, (key) => {
      tree.push({ [key]: objectTree(fl[key]) });
    });
  }
  return tree.length == 0 ? '' : tree;
}