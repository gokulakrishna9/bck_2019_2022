exports.getOps = function () {
  return [
    /*
    {
      op_name: 'db_er_labeler',
      op_file: './labeler_op/db_er_labeler',
      op_method: 'labelERM',
      help_text: ['Label table by table name', 'Properties: table_label->table_substr|label, ...', 'Labels: admin_master, link, root_enitity{master in link|parent}']
    },
    
    {
      op_name: 'select_entity_add_property',             // Global operator
      op_file: './labeler_op/app_property',
      op_method: 'selectEntityAddProperty',
      help_text: [
        '{ app_name: app_name->app_value', 
        'filter: filter->folder_name.property>prp_val>filter_op>filter_label, folder_name.property>prp_val>filter_op>filter_label, ...', 
        'combine_filter: combine_filter:filter_label[&|]filter_label, filter_label[&|]filter_label, ...',
        'filter_op(empty, sub_string, size_less_than, size_greater_than)', 
        'Property((entity_name...entity_name.property_name), empty)', 
        'set: set->property_name>property_value + property_name>property_value>filter_label, property_name>property_value',
        'Array operation is multi-element }']
    },
    */
   
  ];
}