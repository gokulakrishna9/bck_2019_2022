// parent_context, link-link_mst_subsrt{default multiselect, manually set to single}
// get files from scaffold/app_name/db_scaffold
let _ = require('lodash');
let { readFiles } = require('../../file_op/read_file');
exports.labelERM = function (commandObj, callback) {
  console.log('In Labeler');
  // properties: table_label->table_substr|label, ...
  // admin_master, link, root_enitity{master|parent}
  let scaffold = './code/';
  let folder = '/db_scaffold';
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' });
  if (_.isEmpty(appName)) {
    console.log('Input app_name property');
    callback();
    return;
  }
  appName = appName[0].property_value;
  let label = _.filter(commandObj.properties, { property_name: 'table_label' });
  if (_.isEmpty(label)) {
    console.log('Input table_label property');
    callback();
    return;
  }
  let subLbl = [];
  _.forEach(label, (lb) => {
    _.forEach(lb.property_value, (pv) => {
      let pV = _.split(pv, '|');
      subLbl.push({ property_name: pV[0], property_value: pV[1] });
    });
  });
  // Got labels
  console.log(subLbl);
  // get scaffold files
  readFiles(scaffold + appName + '/db_scaffold/' + folder, (err, files) => {
    files = _.map(files, (file) => { return JSON.parse(file.content); });
    if (err)
      console.log(err);
    else
      writeSeq(files, labelerFunction);
    callback();
  });
  callback();
}