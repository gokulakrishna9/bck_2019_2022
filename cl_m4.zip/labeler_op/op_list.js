exports.getOps = function () {
  return [
    
  ];
}