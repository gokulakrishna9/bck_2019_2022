// write all components from antd
// import_view_component{component_name->library}
// contained_by{component_name->library}, contain{component_name->library}
// property, event, template

exports.antDButton = function () {
  return [
    {
      group_label: 'import',
      component: 'Button',
      component_type: 'element',
      library: 'antd'
    },
    {
      group_label: 'template',
      component: 'Button',
      template: `<Button type="<%= button_type %>"><%= button_label %></Button>`,
      template_property: [{ button_type: 'type' }, { button_label: 'string' }]
    },
    {
      group_label: 'import',
      component: 'Tooltip',
      component_type: 'container',
      parent_component: 'Tooltip',
      child_component: ['Button']
    },
    {
      group_label: 'template',
      component: 'Tooltip',
      template: `<Tooltip title="<%= tooltip_text %>"><%= button_component %></Tooltip>`,
      template_property: [{ tooltip_text: 'string' }],
    },
    {
      group_label: 'import',
      component: 'radio',
      component_type: 'container',
      parent_component: 'Radio.Group',
      child_component: 'Radio.Button'
    },
    {
      group_label: 'template',
      component: 'Radio.Group',
      component_type: 'container',
      parent_component: 'Radio.Group',
      child_component: 'Radio.Button'
    },
    {
      group_label: 'import',
      component: 'Menu',
      component_type: 'container',
      parent_component: 'Menu',
      child_component: 'Menu.Item'
    },
    {
      group_label: 'import',
      component: 'Dropdown',
      component_type: 'container',
      parent_component: 'Dropdown.Button',
      child_component: 'property_component'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'type',
      property_value: ['primary', 'dashed', 'text', 'link'], default: '', help: 'Background Color, border, html element type'
    },
    {
      group_label: 'property', component: 'Radio.Group', property_name: 'value', property_value: 'integer', help: ''
    },
    {
      group_label: 'property', component: 'Radio.Button', property_name: 'value', property_value: ['large', 'default', 'small'], help: ''
    },
    {
      group_label: 'property', component: 'Menu', parent_component: 'Radio.Group', property_name: 'value', property_value: 'integer', help: ''
    },
    {
      group_label: 'property', component: 'Menu', child_component: 'Radio.Button', property_name: 'value', property_value: ['large', 'default', 'small'], help: ''
    },
    {
      group_label: 'property', component: 'Dropdown', parent_component: 'Radio.Group', property_name: 'value', property_value: 'integer', help: ''
    },
    {
      group_label: 'property', component: 'Dropdown', child_component: 'Radio.Button', property_name: 'value', property_value: ['large', 'default', 'small'], help: ''
    },
    {
      group_label: 'property', component: 'Button', property_name: 'size',
      property_value: ['large', 'small'], default: '', help: 'Button Size'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'shape',
      property_value: ['circle', 'round'], default: '', help: 'Button shape circle button, or rounded edges'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'ghost',
      help: 'Button with transparent background'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'disabled',
      help: 'Disabled button'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'danger',
      help: 'Add red color to background, or boder depending on the type'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'icon',
      property_value: 'get_icon_components', default: '', help: 'Add icon to button display, displayed before text'
    },
    {
      group_label: 'property', component: 'Button', property_name: 'loading',
      property_value: [true, false], default: '', help: 'Displays rolling arch as long as property value is set to true'
    },
    {
      group_label: 'event', component: 'Button', event_name: 'onClick', help: 'Button click event handler'
    },
    {
      group_label: 'event', component: 'Button', parent_component: 'Radio.Group', event_name: 'onClick', help: 'Button click event handler'
    },
    {
      group_label: 'event', component: 'Button', parent_component: 'Radio.Button', event_name: 'onClick', help: 'Button click event handler'
    }
  ];
}
