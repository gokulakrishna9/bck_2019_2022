let readline = require('readline');
let _ = require('lodash');
let { getOpsList } = require('./op_list');

console.log('It is a matrix app if you think at the level of pixel, "n" dimensional matrix.');
console.log('Type help to list all commands, or help: command_name to get command help.');
console.log('Command syntax: command1: prop1->value1; prop2->list_item1, list_item2, ...; ...');
let rl = readline.createInterface(process.stdin, process.stdout);

rl.setPrompt('matrix_op> ');
rl.prompt();
rl.on('line', function (line) {
  if (line === 'exit') {
    rl.close();
  }
  else if (line === 'clear') {
    console.clear();
    rl.prompt();
  } else if(_.isEmpty(line)) {
    rl.prompt();
  } else {
    let commandObj = buildCommandObj(line);    
    if(commandObj.command == 'help') {
      showHelp(commandObj);
    } else{
      runCommand(commandObj);
    }
  }
}).on('close', function () {
  process.exit(0);
});

function buildCommandObj(line) {
  let commandObj = {command: '', properties: []}
  let commandSpl = _.split(line, ':');
  commandObj.command = commandSpl[0];
  let props = _.split(commandSpl[1], ';');
  _.forEach(props, (prop) => {
    let prSpl = _.split(prop, '->');
    commandObj.properties.push({
      property_name: _.trim(prSpl[0]), 
      property_value: _.map(_.split(prSpl[1], ','), (val) => { return _.trim(val); })
    });
  });
  return commandObj;
}

function showHelp(commandObj) {
  let opMaps = getOpsList();
  console.log('Command syntax: command1: prop1->value1; prop2->list_item1, list_item2, ...; ...');
  if(!_.isEmpty(commandObj.properties)  && !_.isEmpty(commandObj.properties[0].property_name)){
    op_map = _.filter(opMaps, { op_name: commandObj.properties[0].property_name })[0];
    if(!_.isEmpty(op_map)) {
      console.log('Command Name: ' + op_map.op_name);
      console.log(op_map.help_text);
    } else {
      console.log(commandObj.properties[0].property_name + ' command Not Found!');
    } 
  } else {
    _.forEach(opMaps, (map) => {
      console.log(map.op_name + ': ' + _.join(map.help_text, '\n'));
    });
  }
  prompt();
}

function runCommand(commandObj) {
  console.log('Running Command: ' + commandObj.command);
  console.log('Properties: ');
  _.forEach(commandObj.properties, (property) => {
    console.log(property);
  });
  let opMaps = getOpsList();
  let op_map = _.filter(opMaps, { op_name: commandObj.command })[0];
  if (_.isEmpty(op_map)) {
    console.log('Error: Invalid Operator!');
    prompt();
    return;
  }
  let c_file = op_map.op_file;
  try {
    let controller = require(c_file);
    let method = op_map.op_method;
    controller[method](commandObj, () => { prompt(); });
  } catch (e) {
    console.log(e);
    console.log('Error: Operator Not Found!');
    prompt();
    return;
  }
}

function prompt() {
  rl.prompt();
}