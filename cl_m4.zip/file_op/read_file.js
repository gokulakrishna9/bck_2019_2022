// https://stackoverflow.com/questions/10049557/reading-all-files-in-a-directory-store-them-in-objects-and-send-the-object
const fs = require('fs');
let async = require('async');
let _ = require('lodash');

// Build the entire string and call the callback
exports.readAppScaffold = function (folder_name, callback) {
  async.waterfall([
    function (clbck) {
      fs.readdir(folder_name, { recursive: true }, (err, filenames) => {
        let contents = [];
        if (err) {
          console.log(err);
        }
        clbck(err, filenames);
      });
    },
    function (filenames, clbck) {
      async.concat(filenames, (filename, clb) => {
        fs.readFile(folder_name + '/' + filename, 'utf-8', (err, content) => {
          if (err) {
            console.log(err);
            return err;
          }
          clb(err, content);
        });
      }, (err, results) => { callback(err, results); });
    }
  ],
    () => {

    });
}

exports.readFiles = function (folder_name, callback) {
  async.waterfall([
    function (clbck) {
      let folders = [folder_name];
      let files = [];
      while (!_.isEmpty(folders)) {
        let folder_name = folders.pop();
        let filenames;
        try {
          filenames = _.map(fs.readdirSync(folder_name), (file) => { return folder_name + '/' + file; });
        } catch (err) {
          console.log(err)
        }
        _.forEach(filenames, (fileName) => {
          let fileStat = fs.lstatSync(fileName);
          if (fileStat.isFile())
            files.push(fileName);
          else
            folders.push(fileName);
        });
      }
      clbck(null, files);
    },
    function (filenames, clbck) {
      async.concat(filenames, (filename, clb) => {
        fs.readFile(filename, 'utf-8', (err, content) => {
          if (err) {
            console.log(err);
            return err;
          }
          clb(err, { file_name: filename, content: content });
        });
      }, (err, results) => { callback(err, results); });
    }
  ],
    () => {

    });
}

exports.readFile = function (filePath, callback) {
  fs.readFile(filePath, 'utf-8', (err, content) => {
    if (err) {
      console.log(err);
      return err;
    }
    callback(err, { file_name: filePath, content: content });
  });
}

exports.getFolderList = function (folder_name, callback) {
  async.waterfall([
    function (clbck) {
      fs.readdir(folder_name, { recursive: true }, (err, filenames) => {
        if (err) {
          console.log(err);
        }
        let folders = [];
        _.forEach(filenames, (file) => {
          fs.stat(folder_name + '/' + file, (err, stats) => {
            if (stats.isDirectory())
              folders.push(file);
          })
        });
        clbck(err, filenames);
      });
    }
  ], (err, results) => { callback(err, results); });
}