exports.SCAFFOLD_FOLDER = 'D:\\2_startup_projects\\javascript\\cl_m4_app_scaffold\\';
exports.MVC_ER_MODEL_FILE = '_er_model.json';
exports.MVC_CONFIG_FILE = '_mvc_config.json';