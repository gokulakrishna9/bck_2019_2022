// subform of, multiform, workflow
// column method
// subform, link -> parent id from session, or input{get from previous in hierarchy, common column}
// workflow, multiform -> parent id from parameter, or input
// order of preference input -> parameter -> session
