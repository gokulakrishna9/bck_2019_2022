let _ = require('lodash');
let async = require('async');

let { readFiles, readFile } = require('../file_op/read_file');
let { writeFile, writeFileOverwrite } = require('../file_op/write_to_file');
let { SCAFFOLD_FOLDER, MVC_ER_MODEL_FILE, MVC_CONFIG_FILE } = require('../label_constant/scaffold_folder');
let { findCaseInsensitiveSubString } = require('../helper_op/string_function');
let { getPrimaryKeyCol } = require('./mvc_op');
let { fileModOp } = require('./async_op');

function getConfig(appName, clb) {
  let configFile = SCAFFOLD_FOLDER + appName + '/' + appName + MVC_CONFIG_FILE;
  readFile(configFile, (err, file) => {
    if (err) {
      console.log('Entity File Not Found');
      console.log(err);
      clb(err, null)
    }
    clb(null, { file_name: file.file_name, content: JSON.parse(file.content) });
  });
}

function getErModel(appName, clb) {
  let erFile = SCAFFOLD_FOLDER + appName + '/' + appName + MVC_ER_MODEL_FILE;
  readFile(erFile, (err, file) => {
    if (err) {
      console.log('Entity File Not Found');
      console.log(err);
      clb(err, null)
    }
    clb(null, { file_name: file.file_name, content: JSON.parse(file.content) });
  });
}

function getCommandProperty(commandObj, property) {
  let linkPtn = _.filter(commandObj.properties, { property_name: property });
  let propertyVal = _.map(linkPtn, (pt) => { return pt.property_value });
  return { property_name: property, property_value: _.flattenDeep(propertyVal) };
}

function queryConfig(commandObj, clbck) {
  // if emtpy commandObj, list group_label with its properties
  // filter->[filter->value, filter->value]
}

function setConfigProperty(commandObj, clbck) {
  // multi
}

function queryErModel(commandObj, clbck) {
  // if emtpy commandObj, list group_label with its properties
  // filter->[filter->value, filter->value]
}

function setQueryErModelProperty(commandObj, clbck) {

}

function setLabelPtn(commandObj, clbck) {

}

function setLabel(commandObj, clbck) {

}

// link table, link master pattern
function addLinkTablePtn(commandObj, clbck) {
  // console.log(commandObj);
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' });
  if (_.isEmpty(appName)) {
    console.log('Set App Name Property');
    clbck();
    return;
  }
  let linkPtn = _.filter(commandObj.properties, { property_name: 'link' });
  if (_.isEmpty(linkPtn)) {
    console.log('Set link Property');
    clbck();
    return;
  }
  appName = appName[appName.length - 1].property_value;
  async.waterfall([
    function (clb) {
      getConfig(appName, (err, file) => { clb(err, file); });
    },
    function (rslt, clb) {
      getErModel(appName, (err, file) => { clb(err, { er_model: file, config: rslt }); });
    },
    function (rslt, clb) {
      // get link pattern in er_model relation
      let link = _.filter(rslt.er_model.content, { group_label: 'relation', relation_type: 'master' });
      linkPtn = _.flattenDeep(_.map(linkPtn, (ptn) => { return ptn.property_value }));
      let alLink = [];
      _.forEach(linkPtn, (ptn) => {
        // branch_on, master_table_name, relation_root
        let ptnAr = _.split(ptn, '-');
        let lnk = _.filter(link, (lk) => {
          return findCaseInsensitiveSubString(ptnAr[0], lk.table_name);
        });
        let uniqLnk = getUnique(lnk, 'table_name');
        let linkObj = _.map(uniqLnk, (un) => {
          let mst = _.filter(lnk, (lk) => {
            return lk.table_name == un && findCaseInsensitiveSubString(ptnAr[1], lk.master_table_name);
          });
          if (_.isEmpty(mst))
            return [];
          let rec = _.filter(lnk, (lk) => {
            return lk.table_name == un && findCaseInsensitiveSubString(ptnAr[2], lk.master_table_name);
          });
          if (_.isEmpty(rec))
            return [];
          let linkPk = getPrimaryKeyCol(rslt.er_model.content, mst[0].table_name);
          return {
            group_label: 'link_table', link_table_name: mst[0].table_name, link_table_primary_column: linkPk.column_name,
            master_table_name: mst[0].master_table_name, master_table_column: mst[0].master_table_column,
            record_table_name: rec[0].master_table_name, record_column_name: rec[0].master_table_column
          };
        });
        alLink.push(linkObj);
      });
      clb(null, { ...rslt, link_table: _.flattenDeep(alLink) });
    },
    function (rslt, clb) {
      let config = [...rslt.config.content, ...rslt.link_table];
      writeFileOverwrite([{ folder_name: SCAFFOLD_FOLDER + appName, file_name: appName + MVC_CONFIG_FILE, file_contents: JSON.stringify(config), extension: '' }], (err, results) => { clbck() });
    }
  ]);
}

function getUnique(entityList, objectProperty) {
  let propVal = _.map(entityList, (el) => { return el[objectProperty]; });
  let uniqueProp = [];
  _.forEach(propVal, (pv) => {
    if (_.indexOf(uniqueProp, pv) > -1)
      return;
    uniqueProp.push(pv);
  });
  return uniqueProp;
}

function modConf(op, clbkOp) {

}

function addLinkTable(commandObj, clbck) {
  clbck();
}

function addMaster(commandObj, clbck) {
  // master->master_table-master_column-rector_table-record_column, ...
  let appName = getCommandProperty(commandObj, 'app_name').property_value;
  appName = appName[appName.length - 1];
  let mstrs = getCommandProperty(commandObj, 'master');
  fileModOp([SCAFFOLD_FOLDER + appName + '/' + appName + MVC_CONFIG_FILE,
  SCAFFOLD_FOLDER + appName + '/' + appName + MVC_ER_MODEL_FILE], (fileList) => {
    let configFile = _.filter(fileList, { file_name: SCAFFOLD_FOLDER + appName + '/' + appName + MVC_CONFIG_FILE });
    if (_.isEmpty(configFile)) {
      console.log('Config File not found. Use commmand mvc_config');
      return false;
    }
    configFile = configFile[0];
    let erModelFile = _.filter(fileList, { file_name: SCAFFOLD_FOLDER + appName + '/' + appName + MVC_ER_MODEL_FILE });
    if (_.isEmpty(erModelFile)) {
      console.log('Config File not found. Use commmand app_init');
      return false;
    }
    erModelFile = erModelFile[0].content;
    // you can have split at
    mstrs = _.map(mstrs.property_value, (mst) => {
      return _.split(mst, '-');
    });
    let configObj = [];
    _.forEach(mstrs, (mst) => {
      console.log(mst);
      let msF = _.findIndex(erModelFile, { table_name: mst[0] });
      if (msF < 0) {
        console.log('Master Table: ' + mst[0] + ' Not Found!');
      }
      let msC = _.findIndex(erModelFile, { table_name: mst[0], column_name: mst[1] });
      if (msC < 0) {
        console.log('Column: ' + mst[0] + '.' + mst[1] + ' Not Found!');
      }
      let drF = _.findIndex(erModelFile, { table_name: mst[2] });
      if (drF < 0) {
        console.log('Derived Table: ' + mst[2] + ' Not Found!');
      }
      let drC = _.findIndex(erModelFile, { table_name: mst[2], column_name: mst[3] });
      if (drC < 0) {
        console.log('Column: ' + mst[2] + '.' + mst[3] + ' Not Found!');
      }
      let lbl = '';
      if (mst.length == 5)
        lbl = mst[4];
      configObj.push({
        "group_label": "master_table",
        "table_name": mst[2],
        "column_name": mst[3],
        "master_table": mst[0],
        "master_table_column": mst[1],
        "master_label_column": lbl,
        "active": true
      });
    });
    return { folder_name: SCAFFOLD_FOLDER + appName, file_name: appName + MVC_CONFIG_FILE, content: [...configFile.content, ...configObj] };
  }, clbck);
}

function addMasterPtn(commandObj, clbck) {

}

function addSubForm(commandObj, clbck) {
  // parent_form->parent_table-parent_column-child_table-child_column, ...
  let appName = getCommandProperty(commandObj, 'app_name').property_value;
  appName = appName[appName.length - 1];
  let mstrs = getCommandProperty(commandObj, 'master');
  fileModOp([SCAFFOLD_FOLDER + appName + '/' + appName + MVC_CONFIG_FILE,
  SCAFFOLD_FOLDER + appName + '/' + appName + MVC_ER_MODEL_FILE], (fileList) => {
    let configFile = _.filter(fileList, { file_name: SCAFFOLD_FOLDER + appName + '/' + appName + MVC_CONFIG_FILE });
    if (_.isEmpty(configFile)) {
      console.log('Config File not found. Use commmand mvc_config');
      return false;
    }
    configFile = configFile[0];
    let erModelFile = _.filter(fileList, { file_name: SCAFFOLD_FOLDER + appName + '/' + appName + MVC_ER_MODEL_FILE });
    if (_.isEmpty(erModelFile)) {
      console.log('ErModel File not found. Use commmand app_init');
      return false;
    }
    erModelFile = erModelFile[0].content;
    // you can have split at
    mstrs = _.map(mstrs.property_value, (mst) => {
      return _.split(mst, '-');
    });
    let configObj = [];
    _.forEach(mstrs, (mst) => {
      console.log(mst);
      let msF = _.findIndex(erModelFile, { table_name: mst[0] });
      if (msF < 0) {
        console.log('Form Master Table: ' + mst[0] + ' Not Found!');
      }
      let msC = _.findIndex(erModelFile, { table_name: mst[0], column_name: mst[1] });
      if (msC < 0) {
        console.log('Column: ' + mst[0] + '.' + mst[1] + ' Not Found!');
      }
      let drF = _.findIndex(erModelFile, { table_name: mst[2] });
      if (drF < 0) {
        console.log('Derived Table: ' + mst[2] + ' Not Found!');
      }
      let drC = _.findIndex(erModelFile, { table_name: mst[2], column_name: mst[3] });
      if (drC < 0) {
        console.log('Column: ' + mst[2] + '.' + mst[3] + ' Not Found!');
      }
      let lbl = '';
      if (mst.length == 5)
        lbl = mst[4];      
      configObj.push({
        "group_label": "sub_form_table",
        "type": "",
        "table_name": mst[2],
        "column_name": mst[3],
        "form_master_table": mst[0],
        "master_table_column": mst[1],
        "master_label_column": lbl,
        "active": true
      });
    });
    return { folder_name: SCAFFOLD_FOLDER + appName, file_name: appName + MVC_CONFIG_FILE, content: [...configFile.content, ...configObj] };
  }, clbck);
}

function addSubFormPtn(commandObj, clbck) {

}

function addMultiFormEntPtn(commandObj, clbck) {

}

function addMultiFormEnt(commandObj, clbck) {
  // form_list->table_one, table_two, table_three..., multiform global
}

function addWorkFlow(commandObj, clbck) {
  // workflow global command object parameter
  /* 
  {
    "group_label": "work_flow_table",
    "table_name": "",
    "table_column": "",
    "master_table": "",
    "master_column": "",
    "type": "",
    "stage": 0,
    "add_to_stage": [],
    "get_from_stage": [],
    "work_flow_group": "",
    "stage_label": "",
    "stage_comment": "",
    "active": true
  },
  */
}

function addUserGlobal() {
  // used by acl{and what else?}, stage parameter
}

function addApplicationGlobal() {
  // used across users, acl{and what else?}, stages
}

function publicPage() {
  
}

exports.addSubForm = addSubForm;
exports.addLinkTablePtn = addLinkTablePtn;
exports.addMaster = addMaster;