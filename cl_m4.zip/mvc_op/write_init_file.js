// table types[programmer, acl, admin_master_table, application_master_table, link_table
// parent]
let { readFiles, readFile } = require('../file_op/read_file');
let { writeFile } = require('../file_op/write_to_file');
let { SCAFFOLD_FOLDER } = require('../label_constant/scaffold_folder');
let { getTableList, getPrimaryKeyCol, getLabelCol } = require('./mvc_op');

let _ = require('lodash');

exports.tableRouting = function (commandObj, callback) {
  let scaffoldFolder = SCAFFOLD_FOLDER;
  // Next level have a map from these labels to other operators
  let routingOps = [
    {
      group_label: 'label_list',
      entity_group_label: [
        'route_record', 'label_help', 'table', 'master_table', 'link_table',
        'sub_form_table', 'multi_form_table', 'work_flow_table',
        'framework', 'programmer', 'admin_master_table', 'acl']
    },
    {
      group_label: 'route_record'
    },
    { group_label: 'label_help', label: 'sub_form_table', comment: 'Subform style layout, hierarchy lowest first, select_exp should be a function or object with all required component parameters, join_on_column for cases when auto join is not possible- defined on table one' },
    { group_label: 'label_help', label: 'work_flow_table', comment: 'A single record state change capture, hierarchy lowest first, select_exp should be a function or object with all required component parameters' },
    { group_label: 'label_help', label: 'multi_form_table', comment: 'Capture records for multiple forms in the same page, hierarchy lowest first should be the parent, select_exp should be a function or object with all required component parameters' },
    {
      group_label: 'master_table', table_name: '', column_name: '',
      derived_table_name: '', derived_table_column: '', type: '', active: true
    },
    { group_label: 'master_table', select_exp: '', active: true },
    { group_label: 'link_table', table_name: '', link_master: '', link_record: '', type: '', active: true },
    { group_label: 'link_table', select_exp: '', active: true },
    { group_label: 'sub_form_table', table_name: '', table_column: '', type: '', form_master_table: '', master_table_column: '', hierarchy: 0, active: true },
    { group_label: 'sub_form_table', select_exp: '', active: true },
    { group_label: 'multi_form_table', table_name: '', table_column: '', master_table: '', master_column: '', type: '', hierarchy: 0, active: true },
    { group_label: 'multi_form_table', select_exp: '', active: true },
    { group_label: 'work_flow_table', table_name: '', table_column: '', master_table: '', master_column: '', type: '', stage_name: '', stage: 0, stage_field: [], work_flow_group: '', active: true },
    { group_label: 'work_flow_table', select_exp: '', active: true },
    { group_label: 'framework', table_name: '', column_name: '', type: '', active: true },
    { group_label: 'framework', select_exp: '', active: true },
    { group_label: 'programmer', table_name: '', column_name: '', type: '', active: true },
    { group_label: 'programmer', select_exp: '', active: true },
    { group_label: 'admin_master_table', column_name: '', table_name: '', type: '', active: true },
    { group_label: 'admin_master_table', select_exp: '', active: true },
    { group_label: 'acl', table_name: '', column_name: '', type: '', active: true },
    { group_label: 'acl', select_exp: '', active: true },
    { group_label: 'table', table_name: '', active: true }
  ];
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' });
  if (_.isEmpty(appName)) {
    console.log('Set app_name property.');
    callback();
    return;
  }
  appName = appName[appName.length - 1].property_value[0];

  let erModelFile = appName + '/' + appName + '_er_model.json';
  let configFile = appName + '_mvc_config';
  readFile(scaffoldFolder + erModelFile, (err, file) => {
    file = JSON.parse(file.content);
    let fileC = [...routingOps, ...writeMaster(file), ...ciTable(file), ...allTable(file)];
    writeFile([{ folder_name: scaffoldFolder + appName, file_name: configFile, file_contents: JSON.stringify(fileC), extension: '.json' }], (err, results) => { callback() });
  });
}

function allTable(file) {
  return _.map(getTableList(file), (tbl) => {
    return {
      "group_label": "table",
      "table_name": tbl,
      "active": true
    };
  });
}

function writeMaster(file) {
  console.log('Write Master');
  // console.log(file);
  // all tables having derived
  let derived = _.filter(file, { group_label: 'relation', relation_type: 'master' });
  derived = _.map(derived, (drv) => {
    // master table name, master table label, master table column, derived table name, derived table column
    let drvLbl = _.filter(file, { group_label: 'column_property', db: drv.db, table_name: drv.master_table_name, property_name: 'label', property_value: true });
    drvLbl = _.isEmpty(drvLbl) ? '' : drvLbl[0].column_name;
    return { group_label: 'master_table', table_name: drv.table_name, column_name: drv.column_name, master_table: drv.master_table_name, master_table_column: drv.master_table_column, master_label_column: drvLbl, active: true };
  });
  return derived;
}

function writeLink(file) {
  console.log('Write Link');
  // identify link table number of masters more than columns
  let table = getTableList(file);
  let linked = [];
  _.forEach(table, (tbl) => {
    let tblEl = _.filter(file, { table_name: tbl });
    let lPKey = getPrimaryKeyCol(file, tbl);
    let master = _.filter(tblEl, { group_label: 'relation', relation_type: 'master' });
    let mPKey = getPrimaryKeyCol(file, tbl);
    let tableColumn = _.filter(tblEl, { group_label: 'table_column' });
    let nonMC = tableColumn.length - master.length;
    if (nonMC >= 4)
      return;
    _.forEach(master, (mst) => {
      // lable list has size attribute which can be used to narrow down to optimal
      let mstLbl = getLabelCol(file, mst.table_name);
      linked.push({
        group_label: 'link_table_master', link_table_name: tbl, link_primary_column: lPKey.column_name, master_table: mst.master_table_name,
        master_primary_column: mst.column_name, master_label_column: mstLbl[0].column_name, active: false
      },
      {
        group_label: 'link_table_record', link_table_name: tbl, link_primary_column: lPKey.column_name, record_table: mst.master_table_name, record_primary_column: mst.column_name, record_label_column: mstLbl[0].column_name, active: false
      });
    });
  });
  return linked;
}

// DB level layer is over, this part is programmer layer, and programmer changes|labels
function masterSubStr(file, masterList) {
  // make command
}

function addMaster(file) {
  // make this a command
}

function addLink(file) {
  // make this a command
}

function writeSubForm(file) {
  // make this a command
}

function writeMultiForm(file) {
  // make this a command
}

function writeRoute(file) {
  // make this a command
}

function queryProperty(file) {
  // move to common ops
}

function queryObject(file) {
  // move to common ops
}

function ciTable() {
  let ciTable = [];
  let framework = ['ci_session'];
  let acl = ['operator', 'user', 'group', 'user_operator_link_table', 'user_group_link_table'];
  // { group_label: 'framework', table_name: '', type: '', active: true }
  // { group_label: 'acl', table_name: '', type: '', active: true }
  ciTable.push(..._.map(framework, (fr) => { return { group_label: 'framework', table_name: fr, type: 'codeigniter', active: true } }));
  ciTable.push(..._.map(acl, (cl) => { return { group_label: 'framework', table_name: cl, type: 'codeigniter', active: true } }));
  return ciTable;
}

function pageComponentDefault() {

}

function addPageComponent() {

}