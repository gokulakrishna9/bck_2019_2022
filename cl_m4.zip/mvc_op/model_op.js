// model defines the labels on table, and columns
// add required
let { readFiles } = require('../file_op/read_file');
let { writeFile } = require('../file_op/write_to_file');
let { SCAFFOLD_FOLDER } = require('../label_constant/scaffold_folder');
let _ = require('lodash');
let async = require('async');
exports.writeModel = function (commandObj, callback, labelerFunction = {}) {
  // add filter, session, input rules to commandObj
  // {filter, session, input}{select, update, delete}, {session, input}insert
  let scaffold = SCAFFOLD_FOLDER;
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' });
  if (_.isEmpty(appName)) {
    console.log('Set Application Name:- app_name property');
    callback();
    return;
  }
  appName = appName[0].property_value;
  console.log(appName);
  async.waterfall([
    function (clb) {
      readFiles(scaffold + appName, (err, fileList) => {
        if (err) {
          console.log('Error: ');
          console.log(err);
          clb(err, null);
          return;
        }
        fileList = _.map(fileList, (file) => { return JSON.parse(file.content); });
        clb(null, fileList);
      });
    },
    function (fileList, clb) {
      // write the sequence to scaffold
      fileList = _.map(writeSeq(fileList), (entity) => {
        let ent = _.filter(entity, { group_label: 'entity_record' })[0];
        return { folder_name: scaffold + appName, file_name: ent.file_name, file_contents: JSON.stringify(entity), extension: '.json' };
      });
      ///*
      writeFile(fileList, (err, results) => {
        if(err){
          console.log('Error: ');
          console.log(err);
        }
        // console.log(results);
        callback();
      });
      //*/
    }
  ]);
}

let groupLabel = {
  ENTITY_RECORD: 'entity_record',
  MVC_MODEL: 'mvc_model',
  BROWSER_FILTER: 'browser_filter',
  SELECT_STRING: 'select_string',
  JOIN: 'join',
  JOIN_PROPERTY: 'join_property',           // change query_group to join_property
  BROWSER_INPUT: 'browser_input',
  BROWSER_SESSION_INPUT: 'browser_session_input',
  PARAMETER_INPUT: 'parameter_input',
  COLUMN_PROPERTY: 'column_property'        // multi_select_master_label to column property
}

function writeSeq(scaffFileList) {
  let erModel = _.filter(scaffFileList, (file) => { return _.filter(file, { group_label: 'db_er_record' }).length > 0 });
  let route = _.filter(scaffFileList, (file) => { return _.filter(file, { group_label: 'route_record' }).length > 0 })[0];
  let model = _.map(erModel, (md) => {
    let ent = _.filter(md, { group_label: 'entity_record' })[0];
    return [
      {
        group_label: 'label_list',
        entity_group_label: Object.values(groupLabel)
      },
      {
        group_label: 'entity_record', folder_name: ent.folder_name, file_name: 'mvc_model_' + ent.db + '_' + ent.table_name,
        extension: '.json', db: ent.db, table_name: ent.table_name
      },
      {
        group_label: "mvc_model"
      },
      ...addInsert(erModel, md, route),
      ...addUpdate(erModel, md, route),
      ...addDelete(erModel, md, route),
      ...addSelectDetailed(erModel, md, route)
    ];
  });
  return model;
}

// 
function addInsert(erModel, md, route) {
  // subform of, multiform, workflow
  // column method
  // subform -> parent id from session, or input                               <-- DONE
  // link, multiform -> parent id from parameter, or input
  // workflow{get from previous in hierarchy, common column}
  // order of preference input -> parameter -> session
  // find labels -> link_table, sub_form_table, multi_form_table, work_flow_table
  // map to -> session, parameter, input, check for duplicates in each
  let statement = [];
  statement.push(...getSubForm(erModel, md, route, 'insert'));
  statement.push(...getLink(erModel, md, route, 'insert'));
  //let workflow = _.filter(route, { group_label: 'work_flow_table' });         // get the hierarchy table, check if the column is part of master relation
  //let multiform = _.filter(route, { group_label: 'multi_form_table' });       // get the hierarchy table, find the immediate previous table in master relation
  // group label input, session, parameter, column_properties
  statement.push(...inputField(md, statement, 'insert'));     // check for duplicates
  return statement;
}

function addUpdate(erModel, md, route, op) {
  // subform of, multiform, workflow
  // column method
  // subform -> parent id from session, or input                               <-- DONE
  // link, workflow{get from previous in hierarchy, common column}, multiform -> parent id from parameter, or input
  // order of preference input -> parameter -> session
  // find labels -> link_table, sub_form_table, multi_form_table, work_flow_table
  // map to -> session, parameter, input, check for duplicates in each
  let statement = [];
  statement.push(...getSubForm(erModel, md, route, 'update'));
  statement.push(...getLink(erModel, md, route, 'update'));
  //let workflow = _.filter(route, { group_label: 'work_flow_table' });         // get the hierarchy table, check if the column is part of master relation
  //let multiform = _.filter(route, { group_label: 'multi_form_table' });       // get the hierarchy table, find the immediate previous table in master relation
  // group label input, session, parameter, column_properties

  statement.push({ group_label: 'browser_filter', operator: op, table_name: getTableName(md), column_name: getPrimaryKey(md).column_name, column_type: md.column_type, column_size: md.column_size, column_key: md.column_key, active: true});
  statement.push(...inputField(md, statement, 'update'));     // check for duplicates
  return statement;
}

function addDelete(erModel, md, route, op) {
  let statement = [];
  statement.push({ group_label: 'browser_filter', operator: op, key_type: 'pri', table_name: getTableName(md), column_name: getPrimaryKey(md).column_name, column_type: md.column_type, column_size: md.column_size, column_key: md.column_key, active: true  });
  return statement;
}

function addSelectDetailed(erModel, md, route, op) {
  // filter
  // select {link masters?, concat{counts on masters label}, display upto UI{op, summary}} 
  return [
    ...getTableSelectFilter(erModel, md, route, 'select_detailed'),     // select_string, browser_filter, session_filter
    ...getMasterSelectFilterJoin(erModel, md, route, 'select_detailed'),
    ...getlinkSelectFilterJoin(erModel, md, route, 'select_detailed')
  ];
}

function getTableSelectFilter(erModel, md, route, op) {
  let mdCol = _.filter(md, { group_label: 'table_column' });
  mdCol = _.map(mdCol, (col) => {
    return { group_label: 'select_string', select_group: col.table_name, table_name: col.table_name, column_name: col.column_name, column_op: '', select_as: '', active: true };
  });
  let mdLbl = getLabelObj(md);
  console.log(mdLbl); 
  let filter = _.map(mdLbl, (recLbl) => {
    return [
      { group_label: 'browser_filter', operator: op, key_type: 'string', filter_group: recLbl.table_name, table_name: recLbl.table_name, column_name: recLbl.column_name, multi: false, string_search: false, active: true },
      { group_label: 'select_string', select_group: recLbl.table_name, table_name: recLbl.table_name, column_name: recLbl.column_name, column_op: '', select_as: '', active: true }
    ];
  });
  let mdP = getPrimaryKey(md);
  filter.push({ group_label: 'browser_filter', operator: op, filter_group: mdP.table_name, table_name: mdP.table_name, column_name: mdP.column_name, column_type: mdP.column_type, column_size: mdP.column_size, column_key: mdP.column_key, multi: false, string_search: false, active: true });
  return [...mdCol, ...filter];
}

function getMasterSelectFilterJoin(erModel, md, route, op) {
  // get tables masters check in route, add filter, select, join
  let mst = _.filter(route, { group_label: 'master_table' });
  let mdRel = _.filter(md, { group_label: 'relation', relation_type: 'master' });
  
  let mstRel = _.filter(mdRel, (rl) => {
    return _.filter(mst, { table_name: rl.table_name }).length > 0;
  });
  
  let mstselfiljn = _.map(mstRel, (mr) => {
    if (_.isEmpty(mr))
      return;
    // filter, join, display all four
    let recP = getPrimaryKeyObj(md);    // md
    let mE = getEntityObj(erModel, [{ property_name: 'group_label', property_value: 'entity_record' }, { property_name: 'table_name', property_value: mr.table_name }]);
    let mEP = getPrimaryKeyObj(mE);
    let mELbl = getLabelObj(mE);
    // lt get branch_to entity, then primary key, label
    let filter = [
      { group_label: 'browser_filter', operator: op, key_type: 'pri', filter_group: mEP.table_name, table_name: mEP.table_name, column_name: mEP.column_name, column_type: mEP.column_type, column_size: mEP.column_size, column_key: mEP.column_key, multi: false, string_search: false, active: true },
      { group_label: 'browser_filter', operator: op, filter_group: recP.table_name, table_name: recP.table_name, column_name: recP.column_name, column_type: recP.column_type, column_size: recP.column_size, column_key: recP.column_key, multi: false, string_search: false, active: true }
    ];
    // check if link master is a session_input_table under group_label: 'sub_form_table'{table_name, session_input_table}
    // in that case add session_filter as well browser_session_filter
    let subFR = _.filter(route, { group_label: 'sub_form_table', table_name: getTableName(md), session_input_table: mEP.table_name });
    if (!_.isEmpty(subFR))
      filter.push({ group_label: 'brower_session_filter', operator: op, key_type: 'pri', filter_group: mEP.table_name, table_name: mEP.table_name, column_name: mEP.column_name, column_type: mEP.column_type, column_size: mEP.column_size, column_key: mEP.column_key,multi: false, string_search: false, active: true });
    let querySelect = [];
    _.forEach(mELbl, (lbl) => {
      querySelect.push({ group_label: 'select_string', operator: op, select_group: lbl.table_name, table_name: lbl.table_name, column_name: lbl.column_name, column_op: '', select_as: '', active: true });
      filter.push({ group_label: 'browser_filter', operator: op, key_type: 'string', filter_group: lbl.table_name, table_name: lbl.table_name, column_name: lbl.column_name, column_type: lbl.column_type, column_size: lbl.column_size, column_key: lbl.column_key, multi: false, string_search: true, active: true });
    });
    let mJoin = [
      // rec-tbl -> link, link -> linkM
      { group_label: 'join', operator: op, query_group: mEP.table_name, table_one: mEP.table_name, table_one_key: mEP.column_name, table_two: recP.table_name, table_two_key: recP.column_name, join_type: 'left', active: true },
      { group_label: 'query_group', operator: op, query_group: mEP.table_name, enabled: true },
      { group_label: 'query_group', operator: op, query_group: mEP.table_name, sql_group_by: true, active: true },
      { group_label: 'query_group', operator: op, query_group: mEP.table_name, sql_having: true, active: true }
    ];
    return [...filter, ...querySelect, ...mJoin];
  });  
  return _.flattenDeep(mstselfiljn);
}

function addSummarySelect(erModel, md, route, op) {
  // on labels of all masters  
}

function addDynamicGrouping(erModel, md, route) {
  // start with count, ignore missing grouping condition, if grouping codition required in filter add to query without grouping label
  // join across and self, with having, and where
  // dynamic ui{filter, session, input}select{aggregate{AVG COUNT, SUM, MAX, MIN, GROUP_CONCAT()}, {COALESCE, GREATEST, LEAST, ISNULL}, INNER JOIN}
  // add_labels{controller{s}, view{s}}
  // query grouping, filter grouping
}

function customSelectDetailed(erModel, tableStr) {

}

function customSelectSummary(erModel, tableStr) {

}

function customSelectDynamicGroupint(erModel, tableStr) {

}

function getPrimaryKey(tableOb) {
  return _.filter(tableOb, { group_label: 'table_column', column_key: 'PRI' })[0];
}

function inputField(md, statement, op) { 
  // browser_session_input, browser_input
  let column = _.reject(_.filter(md, { group_label: 'table_column' }), (col) => {
    return _.filter(statement, { group_label: 'browser_input', column_name: col.column_name }).length > 0 || _.filter(statement, { group_label: 'browser_input', column_name: col.column_name }).length > 0;
  });
  return _.map(column, (col) => { return { group_label: 'browser_input', operator: op, table_name: col.table_name, column_name: col.column_name, column_type: col.column_type, column_size: col.column_size, column_key: col.column_key, active: true } });
}

function getTableName(mdl) {
  let table = _.filter(mdl, { group_label: 'entity_record' });
  table = table[0].table_name;
  return table;
}

function getSubForm(erModel, md, route, op) {
  let subform = _.filter(route, { group_label: 'sub_form_table', table_name: getTableName(md), active: true });           // session_input_table, should be part of master relation
  if (_.isEmpty(subform))
    return [];
  // session group, input group, label group
  subform = subform[subform.length - 1];
  let mstr = _.filter(erModel, (file) => { return _.filter(file, { group_label: 'entity_record', table_name: subform.session_input_table }).length > 0 });
  if (_.isEmpty(mstr)) {
    // Error
    console.log('Master set in routes on table: ' + subform.session_input_table + ' but not found in DB: ');
    return [];
  }
  // MASTER CONTEXT
  let autoRel = _.filter(mstr[0], { group_label: 'relation', relation_type: 'master' });
  if (_.isEmpty(autoRel)) {
    // Error
    console.log('Subform method tables are not automatically linked table one: ' + getTableName(md) + 'table two: ' + subform.session_input_table);
  }
  let sessionInput = _.filter(mstr[0], { group_label: 'table_column', column_key: 'PRI' });
  let session = _.map(sessionInput, (si) => { return { group_label: 'browser_session_input', operator: op, master_table: si.table_name, column_name: si.column_name, order: 0, active: true } });
  let input = _.map(sessionInput, (si) => { return { group_label: 'browser_input', operator: op, master_table: si.table_name, column_name: si.column_name, order: 0, active: true } });
  let label = _.filter(mstr[0], { group_label: 'column_property', property_name: 'label', property_value: true });
  label = _.map(label, (lbl) => { return { group_label: 'master_label', operator: op, master_table: subform.session_input_table, column_name: lbl.column_name, active: true } });
  return _.flattenDeep([...session, ...input, ...label]);
}

function linkTableInput(erModel, md, route, op) {
  // TRYING TO BUILD A LINK TABLE, don't have to care about link in master
  let linkedTo = getEntityObj(erModel, [
    { property_name: 'group_label', property_value: 'relation' },
    { property_name: 'table_name', property_value: linkTable.table_name },
    { property_name: 'relation_type', property_value: 'branching_derived' },
    { property_name: 'branch_to', property_value: linkTable.link_master }
  ]);
}

function getlinkSelectFilterJoin(erModel, md, route, op) {
  // check if derived tables of md are part of link_table
  // if so apply the following
  if (!_.isEmpty(_.filter(route, { group_label: 'link_table', table_name: getTableName(md), active: true })))
    return [];

  let linkTable = _.filter(route, { group_label: 'link_table', active: true });
  if (_.isEmpty(linkTable))
    return [];
  let linkRelTo = [];
  _.forEach(linkTable, (rlt) => {
    if (_.isEmpty(rlt.table_name))
      return;
    linkRelTo.push(..._.filter(md, { group_label: 'relation', relation_type: 'branching_master', table_name: rlt.link_master, branch_on: rlt.table_name }));
  });
  if (_.isEmpty(linkRelTo))
    return [];
  let linkFilterJoin = [];
  _.forEach(linkRelTo, (lt) => {
    if (_.isEmpty(lt))
      return;
    // filter, join, display all four
    let lnRecP = getPrimaryKeyObj(md);    // md
    let lnE = getEntityObj(erModel, [{ property_name: 'group_label', property_value: 'entity_record' }, { property_name: 'table_name', property_value: lt.branch_on }]);
    let lnP = getPrimaryKeyObj(lnE);
    let lnME = getEntityObj(erModel, [{ property_name: 'group_label', property_value: 'entity_record' }, { property_name: 'table_name', property_value: lt.table_name }]);
    let lnMP = getPrimaryKeyObj(lnME);
    let lnMLbl = getLabelObj(lnME);
    // lt get branch_to entity, then primary key, label
    let filter = [
      { group_label: 'browser_filter', operator: op, filter_group: lnMP.table_name, table_name: lnMP.table_name, column_name: lnMP.column_name, column_type: lnMP.column_type, column_size: lnMP.column_size, column_key: lnMP.column_key, multi: false, string_search: false, active: true },
      { group_label: 'browser_filter', operator: op, filter_group: lnRecP.table_name, table_name: lnRecP.table_name, column_name: lnRecP.column_name, column_type: lnRecP.column_type, column_size: lnRecP.column_size, column_key: lnRecP.column_key, multi: false, string_search: false, active: true }
    ];
    // check if link master is a session_input_table under group_label: 'sub_form_table'{table_name, session_input_table}
    // in that case add session_filter as well browser_session_filter
    let subFR = _.filter(route, { group_label: 'sub_form_table', operator: op, table_name: getTableName(md), session_input_table: lnMP.table_name });
    if (!_.isEmpty(subFR))
      filter.push({ group_label: 'brower_session_filter', operator: op, filter_group: lnMP.table_name, table_name: lnMP.table_name, column_name: lnMP.column_name, column_type: lnMP.column_type, column_size: lnMP.column_size, column_key: lnMP.column_key, multi: false, string_search: false, active: true });
    let querySelect = [];
    _.forEach(lnMLbl, (lbl) => {
      querySelect.push({ group_label: 'select_string', operator: op, select_group: lbl.table_name, table_name: lbl.table_name, column_name: lbl.column_name, column_op: '', select_as: '', active: true });
      filter.push({ group_label: 'browser_filter', operator: op, filter_group: lbl.table_name, table_name: lbl.table_name, column_name: lbl.column_name, column_type: lbl.column_type, column_size: lbl.column_size, column_key: lbl.column_key, multi: false, string_search: true, active: true });
    });
    querySelect.push({ group_label: 'select_string', operator: op, select_group: lnP.table_name, table_name: lnP.table_name, column_name: lnP.column_name, column_op: '', select_as: '', active: true });
    let lnJoin = [
      // rec-tbl -> link, link -> linkM
      { group_label: 'join', operator: op, query_group: lnP.table_name, table_one: lnP.table_name, table_one_key: lnP.column_name, table_two: lnRecP.table_name, table_two_key: lnRecP.column_name, join_type: 'left', active: true },
      { group_label: 'join', operator: op, query_group: lnP.table_name, table_one: lnMP.table_name, table_one_key: lnMP.column_name, table_two: lnP.table_name, table_two_key: lnP.column_name, join_type: 'left', active: true },
      { group_label: 'query_group', operator: op, query_group: lnP.table_name, enabled: true },
      { group_label: 'query_group', operator: op, query_group: lnP.table_name, sql_group_by: true, active: true },
      { group_label: 'query_group', operator: op, query_group: lnP.table_name, sql_having: true, active: true }
    ];
    linkFilterJoin.push(...filter, ...querySelect, ...lnJoin);
  });
  return linkFilterJoin;
}

// write a method for link, link is multiform


// pass in an array of properties
function getEntityObj(erModel, filterList) {
  let filter = {};
  _.forEach(filterList, (fl) => {
    filter[fl['property_name']] = fl['property_value'];
  });
  let entity = _.filter(erModel, (file) => {
    return _.filter(file, filter).length > 0
  });
  return entity[entity.length - 1];
}

function getPrimaryKeyObj(entity) {
  let msPk = _.filter(entity, { group_label: 'table_column', column_key: 'PRI' });
  return _.isEmpty(msPk) ? { table_name: '', column_name: '' } : msPk[0];
}

function getLabelObj(entity) {
  let lbl = _.filter(entity, { group_label: 'column_property', property_name: 'label' });
  return lbl;
}

function getLink(erModel, md, route, op) {
  // check if it is part of derived relation, if so add to param and input
  // "group_label": "link_table", "table_name": "emplyr_job_post_skill_link", "link_master": "adms_skill_id", "type": "", "active": true
  let multiSelect = _.filter(route, { group_label: 'link_table', table_name: getTableName(md), active: true });
  if (_.isEmpty(multiSelect))
    return [];
  // session group, input group, label group
  multiSelect = multiSelect[multiSelect.length - 1];
  let lnkMstr = _.filter(erModel, (file) => {
    return _.filter(file, { group_label: 'entity_record', table_name: multiSelect.link_master }).length > 0
  });
  if (_.isEmpty(lnkMstr)) {
    // Error
    console.log('Link Master set in routes on table: ' + multiSelect.link_master + ' but not found in DB: ');
    return [];
  }
  // DERIVED CONTEXT
  let autoRel = _.filter(lnkMstr[0], { table_name: getTableName(md), group_label: 'relation', relation_type: 'derived' });
  let paramInput = {};
  let browserInput = {};
  if (_.isEmpty(autoRel)) {
    // Error
    console.log('Multiselect tables are not automatically linked table one: ' + getTableName(md) + ' table two: ' + multiSelect.link_master);
    paramInput = { group_label: 'parameter_input', operator: op, master_table: multiSelect.link_master, operator: op, column_name: '', active: false };
    browserInput = { group_label: 'browser_input', operator: op, master_table: multiSelect.link_master, operator: op, column_name: '', active: false };
  } else {
    paramInput = { group_label: 'parameter_input', operator: op, master_table: multiSelect.link_master, operator: op, column_name: autoRel[0].column_name, active: false };
    browserInput = { group_label: 'browser_input', operator: op, master_table: multiSelect.link_master, operator: op, column_name: autoRel[0].column_name, active: false };
  }
  let label = _.filter(lnkMstr[0], { group_label: 'column_property', property_name: 'label', property_value: true });
  label = _.map(label, (lbl) => { return { group_label: 'column_property', operator: op, master_table: multiSelect.link_master, label_column_name: lbl.column_name, multi_select: true, active: true } });
  let multiSelectKey = _.filter(lnkMstr[0], { group_label: 'table_column', column_key: 'PRI' });
  let mlk = {};
  if (_.isEmpty(multiSelectKey)) {
    console.log('Primary Key not set on: ' + multiSelect.link_master);
    mlk = { group_label: 'column_property', operator: op, master_table: multiSelect.link_master, column_name: '', active: false };
  } else {
    mlk = { group_label: 'column_property', operator: op, master_table: multiSelect.link_master, column_name: multiSelectKey[0].column_name, multi_select: true, active: true };
  }
  return _.flattenDeep([paramInput, browserInput, ...label, mlk]);
}

function getMultiForm(erModel, md, route, op) {
  // multiform
}

function workflow(erModel, md, route, op) {
  // workflow
}