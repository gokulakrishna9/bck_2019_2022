let _ = require('lodash');

exports.getPrimaryKeyObj = getPrimaryKeyObj;
exports.getLinkField = getLinkField;
exports.inputField = inputField;
exports.getUpdateDataSource = getUpdateDataSource;
exports.getViewTableObj = getViewTableObj;
exports.getEntityObj = getEntityObj;
exports.getLabelObj = getLabelObj;
exports.getTableName = getTableName;
exports.getLinkFieldAction = getLinkFieldAction;
exports.getFormAction = getFormAction;
exports.getViewTableFilter = getViewTableFilter;
exports.getViewTablePagination = getViewTablePagination;

// get link entities
function getLink(erModel, tblEnt, dbConfig) {
  let relDM = _.filter(tblEnt, { group_label: 'relation', relation_type: 'branching_master' });
  let lnkT = _.filter(relDM, (dm) => {
    return _.filter(dbConfig, { group_label: 'link_table', table_name: dm.branch_on, link_master: dm.table_name }).length > 0;
  });
  return lnkT;
}

// Add required condition
function getLinkField(erModel, tblEnt, dbConfig) {
  // check if tblEnt has a link in relation{derived + masters}    --> Done
  // get links from dbConfig check for links in relation      --> Done
  let lnkT = getLink(erModel, tblEnt, dbConfig);
  if (_.isEmpty(lnkT))
    return [];
  // if so get labels/primary_key from masters 
  // group_label: 'browser_input', input_type: 'multi_select_master', table_name, master_table, master_primary_column, link_table, link_primary_column
  // group_label: 'browser_input_property', master_table, master_label_column
  let lnkCol = _.map(lnkT, (lt) => {
    let msTbl = getEntityObj(erModel, { group_label: 'entity_record', table_name: lt.table_name });
    let lnkE = getEntityObj(erModel, { group_label: 'entity_record', table_name: lt.branch_on });
    if (_.isEmpty(lnkE))
      return [];
    return [
      { group_label: 'browser_input', input_type: 'multi_select_master', rec_table_name: getTableName(tblEnt), master_table: getTableName(msTbl), master_primary_column: getPrimaryKeyObj(msTbl).column_name, table_name: getTableName(lnkE), table_column: getPrimaryKeyObj(lnkE).column_name, required: false },
      ..._.map(getLabelObj(msTbl), (lbl) => { return { group_label: 'browser_input_property', table_name: lbl.table_name, column_name: lbl.column_name, property_name: 'master_label', property_value: true } })
    ];
  });
  return _.flattenDeep(lnkCol);
}

function getLinkFieldAction(erModel, tblEnt, dbConfig) {
  // add, delete
  let linkField = _.filter(getLinkField(erModel, tblEnt, dbConfig), { group_label: 'browser_input' });
  let linkAction = _.map(linkField, (fld) => {
    return [
      { group_label: 'field_operator', event: 'add_multi', table_name: fld.table_name, column_name: fld.column_name, property_name: 'link_column', property_value: fld.table_name + '_' + 'add_record' },
      { group_label: 'field_operator', event: 'add_multi', table_name: fld.table_name, column_name: fld.column_name, property_name: 'link_column', property_value: fld.table_name + '_' + 'delete_record' },
    ]
  });
  return _.flattenDeep(linkAction);
}

// Add required condition
function inputField(erModel, tblEnt, dbConfig) {
  // get all columns
  let column = _.map(_.filter(tblEnt, { group_label: 'table_column' }), (col) => {
    return { group_label: 'browser_input', input_type: col.column_type, table_name: getTableName(tblEnt), table_column: col.column_name, operator: '', required: false }
  });
  // get masters columns
  let master = _.filter(tblEnt, { group_label: 'relation', relation_type: 'master' });
  // check masters in dbConfig
  master = _.filter(master, (mst) => {
    return _.filter(dbConfig, { group_label: 'master_table', table_name: mst.table_name }).length > 0;
  });
  // get masters labels
  master = _.map(master, (mst) => {
    let msE = getEntityObj(erModel, { group_label: 'entity_record', table_name: mst.table_name });
    let label = getLabelObj(msE);
    return _.map(label, (lb) => { return { group_label: 'browser_input_property', table_name: lb.table_name, column_name: lb.column_name, property_name: 'master_label', property_value: true }; });
  });
  return _.flattenDeep([...column, ...master]);
}

function getFormAction(erModel, tblEnt, dbConfig) {
  // add, update, delete, acl_op{only error handling on client, overall on the application}
  let tableName = getTableName(tblEnt);
  return [
    { group_label: 'form_operator', event: 'submit', table_name: tableName, property_name: 'form_action', property_value: tableName + '_' + 'add_record' },
    { group_label: 'form_operator', event: 'submit', table_name: tableName, property_name: 'form_action', property_value: tableName + '_' + 'update_record' },
    { group_label: 'form_operator', event: 'submit', table_name: tableName, property_name: 'form_action', property_value: tableName + '_' + 'delete_record' }
  ];
}

// MODEL METHOD
function getUpdateDataSource(erModel, tblEnt, dbConfig) {
  // updated existing values, including link values
  // get the form data with link data
}

function controllerMethod(erModel, tblEnt, dbConfig) {
  // views, validation, transaction, masters{link}
}

function getViewTableObj(erModel, tblEnt, dbConfig) {
  // transpose input fields into table obj, including master labels
  // add ops, update, delete multi, sub-form add op
}

function getViewTableFilter(erModel, tblEnt, dbConfig) {
  // get masters, labels
}

function getViewTablePagination(erModel, tblEnt, dbConfig) {
  // get select op on tblEnt
}

function getEntityObj(erModel, filterObj) {
  let entity = _.filter(erModel, (file) => {
    return _.filter(file, filterObj).length > 0
  });
  return entity[entity.length - 1];
}

function getPrimaryKeyObj(entity) {
  let msPk = _.filter(entity, { group_label: 'table_column', column_key: 'PRI' });
  return _.isEmpty(msPk) ? { table_name: '', column_name: '' } : msPk[0];
}

function getLabelObj(entity) {
  let lbl = _.filter(entity, { group_label: 'column_property', property_name: 'label', property_value: true });
  return lbl;
}

function getTableName(mdl) {
  let table = _.filter(mdl, { group_label: 'entity_record' });
  table = table[0].table_name;
  return table;
}

