exports.getOps = function () {
  return [
    {
      op_name: 'app_list',
      op_file: './mvc_op/app_property',
      op_method: 'appList',
      help_text: ['Lists existing applications.']
    },
    {
      op_name: 'mvc_init',
      op_file: './mvc_op/mvc_op',
      op_method: 'mvcInit',
      help_text: ['app_name: app_name->app_value']
    },
    {
      op_name: 'mvc_config',
      op_file: './mvc_op/write_init_file',
      op_method: 'tableRouting',
      help_text: ['Write the Route initialisation file', 'Properties: app_name->app_name', 'framework->[ci]']
    },
    {
      op_name: 'link_master_ptn',
      op_file: './mvc_op/scf_mod_op',
      op_method: 'addLinkTablePtn',
      help_text: ['Update config file with Link Tables given sub string contained in link_table, master_table, record_table', 
      'Properties: app_name->app_name', 'link->link_table_ptn-master_table_ptn-record_table_ptn, ...']
    },
    {
      op_name: 'add_master',
      op_file: './mvc_op/scf_mod_op',
      op_method: 'addMaster',
      help_text: ['Update config file with Master Tables given sub string contained in record_table, master_table', 
      'Properties: app_name->app_name', 'master->master_table-master_column-derived_table-derived_column-master_label_column, ...']
    },
  ];
}