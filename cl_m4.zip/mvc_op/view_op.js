// apply op to view
// create new view
// connect model method to view component
let _ = require('lodash');
let async = require('async');

let { readFiles } = require('../file_op/read_file');
let { writeFile } = require('../file_op/write_to_file');
let { SCAFFOLD_FOLDER } = require('../label_constant/scaffold_folder');
let { getLinkField, inputField, getPrimaryKeyObj } = require('./common_op');

exports.writeDefaultView = function (commandObj, callback) {
  // navigation, grid_component{form_grid, form, alert, filter, pagination, table, op}
  // get dbConfigs, get mvc_model
  let scaffold = SCAFFOLD_FOLDER;
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' });
  if (_.isEmpty(appName)) {
    console.log('Set Application Name:- app_name property');
    callback();
    return;
  }
  appName = appName[0].property_value;
  console.log(appName);
  async.waterfall([
    function (clb) {
      readFiles(scaffold + appName, (err, fileList) => {
        if (err) {
          console.log('Error: ');
          console.log(err);
          clb(err, null);
          return;
        }
        fileList = _.map(fileList, (file) => { return JSON.parse(file.content); });

        clb(null, fileList);
      });
    },
    function (fileList, clb) {
      // write the sequence to scaffold
      writeSeq(fileList);
      /*
      fileList = _.map(writeSeq(fileList), (entity) => {
        let ent = _.filter(entity, { group_label: 'entity_record' })[0];
        return { folder_name: scaffold + appName, file_name: ent.file_name, file_contents: JSON.stringify(entity), extension: '.json' };
      });
      ///*
      writeFile(fileList, (err, results) => {
        if (err) {
          console.log('Error: ');
          console.log(err);
        }
        // console.log(results);
        callback();
      });
      //*/
    }
  ]);
}
let groupLabel = {
  ENTITY_RECORD: 'entity_record',
  DEFAULT_VIEW: 'default_view',
  PAGE_HEADER: 'header',
  PAGE_LEFTNAV: 'left_nav',
  PAGE_GRID: 'page_grid',             // define component ordering
  FORM_GRID: 'form_grid',             // define component ordering
  ALERT_INFO: 'alert_info',
  ALERT_WARNING: 'alert_warning',
  ALERT_ERROR: 'alert_error',
  FILTER: 'filter',
  FORM_INPUT: 'form_input',
  PAGINATION: 'pagination',
  TABLE: 'table'
};
function writeSeq(scaffFileList) {
  let erModel = _.filter(scaffFileList, (file) => { return _.filter(file, { group_label: 'db_er_record' }).length > 0 });
  let dbConfig = _.filter(scaffFileList, (file) => { return _.filter(file, { group_label: 'route_record' }).length > 0 })[0];

  let view = _.map(erModel, (tblEnt) => {
    let ent = _.filter(tblEnt, { group_label: 'entity_record' })[0];
    return [
      {
        group_label: 'label_list',
        entity_group_label: Object.values(groupLabel)
      },
      {
        group_label: groupLabel.ENTITY_RECORD, folder_name: ent.folder_name, file_name: 'mvc_default_view_' + ent.db + '_' + ent.table_name, extension: '.json', db: ent.db, table_name: ent.table_name
      },
      {
        group_label: groupLabel.DEFAULT_VIEW
      },
      ...addInsertForm(erModel, tblEnt, dbConfig),
      ...addUpdateForm(erModel, tblEnt, dbConfig),
      ...addDeleteOp(erModel, tblEnt, dbConfig),
      //...addSelectDetailedView(erModel, tblEnt, dbConfig)
    ];
  });
  // return view;
}

function addInsertForm(erModel, tblEnt, dbConfig) {
  let getInputField = inputField(erModel, tblEnt, dbConfig);
  let linkMst = getLinkField(erModel, tblEnt, dbConfig);
  return [...getInputField, ...linkMst];
}

function addUpdateForm(erModel, tblEnt, dbConfig) {
  let getUpdateField = inputField(erModel, tblEnt, dbConfig);
  let linkMst = getLinkField(erModel, tblEnt, dbConfig);
  return [...getUpdateField, ...linkMst];
}

function addDeleteOp(erModel, tblEnt, dbConfig) {
  let entP = getPrimaryKeyObj(tblEnt);
  let deleteOpField = '';
  console.log(deleteOpField);
  return [];
}

function addSelectDetailedView(erModel, tblEnt, dbConfig) {
  let tableCol = _.filter(tblEnt, { group_label: 'select_string' });
  console.log(tableCol);
  return [];
}

function recordOp(erModel, tblEnt, dbConfig) {
  // sub-form, multi
}

function navigation() {
  // manual{list of table entires, with group label and sorting, {futher groupings as properties}}
}