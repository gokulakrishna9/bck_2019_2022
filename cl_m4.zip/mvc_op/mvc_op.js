let _ = require('lodash');
let async = require('async');

let { readFiles, readFile } = require('../file_op/read_file');
let { writeFile } = require('../file_op/write_to_file');
let { SCAFFOLD_FOLDER, MVC_ER_MODEL_FILE, MVC_CONFIG_FILE } = require('../label_constant/scaffold_folder');

let { ucFirst } = require('../helper_op/string_function');

exports.mvcInit = function (commandObj, clbck) {
  // read config file
  // read er_model file
  let appName = _.filter(commandObj.properties, { property_name: 'app_name' });
  if (_.isEmpty(appName)) {
    console.log('Set app name property.');
    clbck();
    return;
  }
  appName = appName[appName.length - 1].property_value[0];
  let erFile = SCAFFOLD_FOLDER + appName + '/' + appName + MVC_ER_MODEL_FILE;
  let configFile = SCAFFOLD_FOLDER + appName + '/' + appName + MVC_CONFIG_FILE;
  async.waterfall([
    // Write files, after building the scaffold, check for existing scaffold, and integrate
    function (clb) {
      readFile(erFile, (err, file) => {
        if (err) {
          console.log('Entity File Not Found');
          console.log(err);
          clb(err, null)
        }
        clb(null, file);
      });
    },
    function (rslt, clb) {
      readFile(configFile, (err, file) => {
        if (err) {
          console.log('Entity File Not Found');
          console.log(err);
          clb(err, null)
        }
        clb(null, { configFile: file, erModel: rslt });
      });
    },
    function (rslt, clb) {
      // group_label, group_type{long string, each separated by a '->'}{add, remove, update}
      // let group_type become group_label
      let erModel = JSON.parse(rslt.erModel.content);
      let appConfig = JSON.parse(rslt.configFile.content);
      let ent = [];
      ent.push(addLabel('model_statement', ''));
      ent.push(addLabel('view_statement', ''));
      ent.push(addLabel('controller_statement', ''));
      ent.push(...tableColumn(erModel, appConfig));
      ent.push(...masterColumn(erModel, appConfig));
      ent.push(...linkMasterColumn(erModel, appConfig));
      ent.push(...subFormColumn(erModel, appConfig));
      ent.push(...multiFormEntity(erModel, appConfig));
      console.log(ent);
    }
  ], (err, rslt) => {
    clbck();
  });
}
// one table in context
let modelSuffix = '_Model';
let controllerSuffix = '_Controller';
let modelgetMethod = 'get_record';
let modelgetSingleRecord = 'get_single';
let modelSessionGet = 'get_session_record';
let selectSuffix = '_select';
let viewSuffix = '_crud';

// Scaffold helper
function addLabel(label, helpText) {
  return { group_label: 'label_list', label: label, help: helpText };
}

function getMaster(appConfig) {
  let confMst = _.filter(appConfig, { group_label: 'master_table', active: true });
  let confMstSubForm = _.filter(appConfig, { group_label: 'sub_form_table', active: true });
  confMst = _.filter(confMst, (cmst) => {
    let msf = _.filter(confMstSubForm, { form_master_table: cmst.master_table }).length;
    return !(msf > 0);
  });
  return confMst;
}

function getPrimaryKeyCol(erModel, tableName) {
  let primaryKey = _.filter(erModel, { group_label: 'table_column', table_name: tableName, column_key: 'PRI' });
  primaryKey = _.isEmpty(primaryKey) ? { table_name: '', column_name: '' } : primaryKey[0];
  return primaryKey;
}

function getLabelCol(erModel, tableName) {
  let labelCol = _.filter(erModel, { group_label: 'column_property', property_name: 'label', property_value: true, table_name: tableName });
  labelCol = _.isEmpty(labelCol) ? [{ table_name: '', column_name: '' }] : labelCol;
  return labelCol;
}

function getColumn(erModel, tableName) {

  return _.filter(erModel, { table_name: tableName, group_label: 'table_column' });
}

function getTableErModel(erModel, tableName) {
  let tableModel = _.filter(erModel, { table_name: tableName });
  return _.isEmpty(tableModel) ? [] : tableModel;
}

function columnExists(columnName, erModel) {

}

function labelColumn(erModel) {
  // iterate over entity
}

function getTableList(erModel) {
  let table = [];
  _.forEach(erModel, (fl) => {
    if (_.includes(table, fl.table_name)) {
      return '';
    }
    table.push(fl.table_name);
  });
  return table;
}

function addGroupLabel(label_name, label_property, label_help) {

}

function addSubGroupLabel(group_label, label_name, label_property, label_help) {

}
// End Scaffold helper

// Code module
function tableColumn(erModel, appConfig) {
  // remove-> master column, sub_form_table  
  console.log('Table Column');
  let tableList = getTableList(erModel);
  let stmt = [];
  _.forEach(tableList, (table) => {
    console.log(table);
    if (table == undefined || _.isEmpty(table))
      return;
    let configMst = _.filter(appConfig, { group_label: 'master_table', table_name: table });           // column_name
    let configSubForm = _.filter(appConfig, { group_label: 'sub_form_table', table_name: table });     // table_column | master_table_column
    let col = getColumn(erModel, table);
    if (_.isEmpty(col))
      return;
    col = _.reject(col, (cl) => {
      return _.filter(configMst, { column_name: cl.column_name, table_name: table }).length > 0;
    });
    col = _.reject(col, (cl) => {
      return _.filter(configSubForm, { column_name: cl.column_name, table_name: table }).length > 0;
    });
    col = _.reject(col, { column_key: 'PRI' });
    // add model, view, controller{update data}
    // model add, update, filter{config}
    _.forEach(col, (cl) => {
      stmt.push({
        group_label: 'model_statement', group_type: 'input', entity_name: cl.table_name,
        model_name: ucFirst(cl.table_name) + modelSuffix, value_field: cl.column_name, statement_order: 0, active: true
      });
      // view input statement with value
      stmt.push({
        group_label: 'view_statement', group_type: 'input', entity_name: cl.table_name,
        controller_name: ucFirst(cl.table_name) + controllerSuffix, view_name: cl.table_name + viewSuffix,
        data_point_name: cl.master_table + selectSuffix, label_column: cl.master_label_column,
        value_column: cl.column_name, value_field: cl.column_name, value_type: cl.column_type,
        view_op: 'html_input', form_op: 'c-u', view_component: 'input', required: true,
        statement_order: 0, active: true
      });
      // controller update  <<-- Here
      stmt.push({
        group_label: 'controller_statement', group_type: 'get_update_data', entity_name: cl.table_name,
        controller_name: ucFirst(cl.table_name) + controllerSuffix, data_point_name: 'update_',
        model_name: cl.table_name + modelSuffix.toLowerCase(), method_name: 'update_',
        controller_op: '', statement_order: 0, active: true
      });
    });
  });
  return stmt;
}

function masterColumn(erModel, appConfig) {
  // iterate over config
  // add input, label, select method
  // add master to controller, view, model filter
  console.log('Master Column!');
  let confMst = getMaster(appConfig);
  let mstStmt = _.map(confMst, (mst) => {
    if (_.isEmpty(mst.table_name))
      return [];
    let st = [];
    // model {group_label:'model_statement', group_type:'filter', value_field:'', active: ''}
    st.push({
      group_label: 'model_statement', group_type: 'filter', entity_name: mst.table_name,
      model_name: ucFirst(mst.table_name) + modelSuffix, value_field: mst.column_name, statement_order: 0, active: true
    });
    st.push({
      group_label: 'model_statement', group_type: 'input', entity_name: mst.table_name,
      model_name: ucFirst(mst.table_name) + modelSuffix, value_field: mst.column_name, statement_order: 0, active: true
    });
    // view {group_label:'view_statement', group_type:'html_select', data_point_name:'', label_field:'', value_field:'', view_op:'', view_component:'', required: '', active:''}
    st.push({
      group_label: 'view_statement', group_type: 'input', entity_name: mst.table_name,
      controller_name: ucFirst(mst.table_name) + controllerSuffix, view_name: mst.table_name + viewSuffix,
      data_point_name: mst.master_table + selectSuffix, label_column: mst.master_label_column,
      value_column: mst.master_table_column, value_field: mst.column_name, view_op: 'html_select', form_op: 'c-u',
      view_component: 'html_select', required: true, statement_order: 0, active: true
    });
    // controller {group_label:'controller_statement', group_type:'data_list', entity_name: '', controller_name: '', data_point_name:'', model_name:'', method_name:'', controller_op:'', active: ''}
    st.push({
      group_label: 'controller_statement', group_type: 'data_list', entity_name: mst.table_name,
      controller_name: ucFirst(mst.table_name) + controllerSuffix, data_point_name: 'select_' + mst.master_table,
      model_name: mst.master_table + modelSuffix.toLowerCase(), method_name: modelgetMethod,
      controller_op: '', statement_order: 0, active: true
    });
    // controller {group_label:'controller_statement', group_type:'required', value_field: '', data_type: '', active: ''}
    st.push({
      group_label: 'controller_statement', group_type: 'required', entity_name: mst.table_name,
      controller_name: ucFirst(mst.table_name) + controllerSuffix, value_field: mst.column_name, statement_order: 0, active: true
    });
    return st;
  });
  // add group label, and group_type
  return _.flattenDeep(mstStmt);
}

function subFormColumn(erModel, appConfig) {
  // iterate over config
  // add input, label, method
  // add session/input to controller, model, view
  console.log('Sub Form Column!');
  let confMstSubForm = _.filter(appConfig, { group_label: 'sub_form_table', active: true });
  // table_name, table_column, form_master_table, master_table_column
  // in table_name view add master info
  // in form_master_table add operator with master column as primary_key
  let subFormElem = _.map(confMstSubForm, (sf) => {
    if (_.isEmpty(sf.table_name) || _.isEmpty(sf.form_master_table))
      return [];
    let iter = [];
    // in table_name model add session, input, with statement_order    
    let subPk = _.isEmpty(sf.table_column) ? getPrimaryKeyCol(erModel, sf.table_name) : { table_name: sf.table_name, column_name: sf.table_column };
    let msPk = _.isEmpty(sf.master_table_column) ? getPrimaryKeyCol(erModel, sf.form_master_table) : { table_name: sf.form_master_table, column_name: sf.master_table_column };
    iter.push({
      group_label: 'model_statement', group_type: 'filter', entity_name: sf.table_name,
      model_name: ucFirst(sf.table_name) + modelSuffix, value_field: subPk.column_name, statement_order: 0, active: true
    });
    // in table_name controller get master_info
    iter.push({
      group_label: 'controller_statement', group_type: 'data_list', entity_name: sf.table_name,
      controller_name: ucFirst(sf.table_name) + controllerSuffix, data_point_name: 'info_' + sf.form_master_table,
      model_name: sf.form_master_table + modelSuffix.toLowerCase(), method_name: modelgetMethod,
      controller_op: '', statement_order: 0, active: true
    });
    // hidden input in form/delete
    iter.push({
      group_label: 'view_statement', group_type: 'input', entity_name: sf.table_name,
      controller_name: ucFirst(sf.table_name) + controllerSuffix, view_name: sf.table_name + viewSuffix,
      data_point_name: 'info_' + sf.form_master_table, value_column: msPk.column_name,
      value_field: msPk.column_name, view_op: '', view_component: 'hidden_input', form_op: 'c-u-d',
      required: true, statement_order: 0, active: true
    });
    return iter;
  });
  return _.flattenDeep(subFormElem);
}

function linkMasterColumn(erModel, dbConfig) {
  console.log('Link Master Column!');
  // you only need dbConfig
  // iterate over config
  // add input, label, select method
  // add link master to controller, model, view
  /*
  {
    "group_label": "link_table",
    "link_table_name": "emplyr_job_industry_link",
    "link_table_primary_column": "emplyr_job_industry_link_id",
    "master_table_name": "adms_industry",
    "master_table_column": "adms_industry_id",
    "record_table_name": "emplyr_job_post",
    "record_column_name": "emplyr_job_post_id"
  }
  */
  let linkConf = _.filter(dbConfig, { group_label: 'link_table' });
  // model_statement, view_statement, controller_statement
  // model{batch_input, master_table from param}, controller{call sequence, master_table, then link}, view{master form, link multi-form}
  let stmt = [];
  _.map(linkConf, (lc) => {
    console.log(lc); 
    stmt.push({
      group_label: 'model_statement', group_type: 'link_input', parent_entity_name: lc.record_table_name, parameter_name: lc.record_table_column, entity_name: lc.link_table_name, model_name: ucFirst(lc.link_table_name) + modelSuffix,
      value_field: lc.record_column_name, statement_order: 0, active: true
    });
  });
  return stmt;
}

function multiFormEntity(erModel, dbConfig) {
  // iterate over config
  // add input, label, method
  // add master to controller, model, view
  console.log('Multi Form Entity!');
  return [];
}

function workFlowEntity(erModel, dbConfig) {
  // iterate over config
  // add input, label, method
  // add master to controller, model, view
  console.log('Work Flow Entity!');
  return [];
}

function addField(erModel) {
  // iterate over entity
}

exports.getTableList = getTableList;
exports.getPrimaryKeyCol = getPrimaryKeyCol;
exports.getLabelCol = getLabelCol;
exports.getTableErModel = getTableErModel;
exports.addGroupLabel = addGroupLabel;
exports.addSubGroupLabel = addSubGroupLabel;