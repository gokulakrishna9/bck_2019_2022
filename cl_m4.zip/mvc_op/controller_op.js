// build controller based on model and view
exports.writeController = function(commandObj, callback) {
  
}