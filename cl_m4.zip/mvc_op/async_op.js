let _ = require('lodash');
let async = require('async');
let { readFiles, readFile } = require('../file_op/read_file');
let { writeFile, writeFileOverwrite } = require('../file_op/write_to_file');
let { SCAFFOLD_FOLDER, MVC_ER_MODEL_FILE, MVC_CONFIG_FILE } = require('../label_constant/scaffold_folder');

function fileModOp(fileNameList, operationToApply, operationCallBack) {
  let wfFunction = [];
  async.map(fileNameList, readFile, function (err, results) {
    results = _.map(results, (file) => { return { file_name: file.file_name, content: JSON.parse(file.content) }; });
    let opRslt = operationToApply(results);
    console.log(opRslt);
    // call the operator here, get the mod, write to file, callback
    writeFileOverwrite([{ ...opRslt, file_contents: JSON.stringify(opRslt.content), extension: '' }], (err, results) => { operationCallBack() });
    console.log(err);
    operationCallBack();
  });
}

exports.fileModOp = fileModOp;