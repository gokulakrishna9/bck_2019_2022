let _ = require('lodash');
let { fieldObj } = require('./scaffold_helper');
// edited, overwrite
exports.dbERModel = function (applObj, clbck) {
  let dbSchemas = applObj.db_schemas;
  // all primary keys
  // all tables
  // related_tables{table_name, link_on, label, relation_type}
  // related_table_columns{table_name{columns, label}}
  let entities = [];
  let allColumns = schemaColumns(dbSchemas);
  let primaryKeys = allPrimaryKeys(allColumns);

  let appName = applObj.application_name;
  let recordGroupLabel = [
    'entity_record', 'entity_property', 'table_column', 'table_property',
    'column_property', 'relation', 'relation_property', 'about_application'
  ];
  let dbList = _.map(dbSchemas, (sch) => { return sch.db_name; });
  entities.push(
    { group_label: 'label_list', entity_group_label: recordGroupLabel },
    { group_label: 'db_er_record' },
    { group_label: 'about_application', db: dbList, application_name: appName }
  );
  let i = 6;
  let j = 1;
  _.forEach(primaryKeys, (primaryKey) => {
    let db = primaryKey.db;
    let tableName = primaryKey.table_name;
    let tableColumn = tblColumns(allColumns, primaryKey);
    let relatedTable = relatedTbls(allColumns, tableColumn);

    let primaryKeyConflict = primaryKeysWithSameName(primaryKeys, primaryKey);
    i++;
    tableColumn = _.map(tableColumn, (col) => { return { group_label: 'table_column', ...col } });
    let columnProperty = _.map(_.filter(tableColumn, { label_column: true }), (col) => { return { group_label: 'column_property', db: col.db, table_name: tableName, column_name: col.column_name, property_name: 'label', property_value: true } });
    // add master table property to column
    _.forEach(tableColumn, (col) => {
      // get master's here
      if (col.column_type != 'int' || col.column_key == 'PRI')
        return;
      columnProperty.push(..._.map(findColMst(allColumns, col), (col) => { return { group_label: 'column_property', table_name: tableName, column_name: col.column_name, property_name: 'master_label', property_value: true, master_table: col.table_name, master_label: col.column_name, master_label_size: col.column_size } }));
    });
    relatedTable = _.map(relatedTable, (col) => { if (_.isEmpty(col)) return {}; return { group_label: 'relation', ...col } });
    entities.push([
      ...tableColumn,
      ...columnProperty,
      ...relatedTable
    ]);
  });
  clbck(null, entities);
}

function primaryKeysWithSameName(primaryKeys, primaryColumn) {
  if (_.isEmpty(primaryColumn))
    return;
  let similarKeys = _.filter(primaryKeys, { COLUMN_NAME: primaryColumn.COLUMN_NAME });
  similarKeys = _.reject(similarKeys, { TABLE_NAME: primaryColumn.TABLE_NAME });
  return _.map(similarKeys, (key) => { return key.TABLE_NAME });
}

function allPrimaryKeys(allColumns) {
  let prmKey = _.filter(allColumns, { column_key: 'PRI' });
  return prmKey;
}

function schemaColumns(dbSchemas) {
  let alC = _.map(dbSchemas, (schema) => {
    return schema.columns;
  });
  return _.map(_.flatten(alC), (col) => { return fieldObj(col); });
}

function tblColumns(allColumns, primaryKey) {
  let tblCol = _.filter(allColumns, { /*db: primaryKey.db,*/ table_name: primaryKey.table_name });
  return tblCol;
}

function findColMst(allColumns, column) {
  let mst = _.filter(allColumns, { db: column.db, column_name: column.column_name, column_key: 'PRI' });
  if (!_.isEmpty(mst)) {
    mst = _.filter(_.filter(allColumns, { db: mst[0].db, table_name: mst[0].table_name }), { label_column: true });
  }
  return mst;
}

function relatedTbls(allColumns, tableColumns) {
  let primaryColumn = _.filter(tableColumns, { column_key: 'PRI' })[0];
  if (_.isEmpty(primaryColumn))
    return;
  let nonPrimColumns = _.filter(_.reject(tableColumns, { column_key: 'PRI' }), { column_type: 'int' });
  //let alCols = _.reject(allColumns, { table_name: primaryColumn.table_name });
  let alCols = allColumns;
  let masters = mastersTables(alCols, nonPrimColumns, 'master');
  let derived = derivedTables(alCols, primaryColumn, 'derived');
  let branching = [];
  // masters, derived format changed, table_name is the relation_root  
  _.forEach({ ...masters, ...derived }, (mst) => {
    if (mst.branch == primaryColumn.table_name)
      return;
    let aC = _.reject(alCols, { table_name: primaryColumn.table_name });
    let nPC = _.reject(_.filter(alCols, { table_name: mst.branch }), { table_name: mst.branch, column_key: 'PRI' });
    let mstB = mastersTables(aC, nPC, 'branching_master');
    mstB = _.map(mstB, (mst) => {
      if (_.isEmpty(mst))
        return [];
      mst.relation_root = primaryColumn.table_name;
      mst.relation_root_column = mst.column_name;
      mst.branch_on = mst.table_name;
      mst.branch_on_column = mst.column_name;
      mst.table_name = mst.relation_root;
      delete mst['column_name'];
      return mst;
    });
    branching.push(...mstB);
  });
  // Derived
  _.forEach({ ...masters, ...derived }, (drv) => {
    if (drv.branch == primaryColumn.table_name)
      return;
    let aC = _.reject(alCols, { table_name: primaryColumn.table_name });
    let pC = _.filter(alCols, { table_name: drv.branch, column_key: 'PRI' });    // link primary key
    if (_.isEmpty(pC)) {
      console.log('Missing Primary Column in table: ' + drv.derived_table_name);
    } else {
      pC = pC[0];
      let drvd = derivedTables(aC, pC, 'branching_derived');
      branching.push(..._.map(drvd, (dr) => {
        dr.relation_root = primaryColumn.table_name;
        dr.relation_root_column = dr.column_name;
        dr.branch_on = dr.table_name;
        dr.branch_on_column = dr.column_name;
        dr.table_name = dr.relation_root;
        return dr;
      }));
    }
  });
  return [...masters, ...derived, ...branching];
}

function mastersTables(alCols, nonPrimColumns, relationType) {
  let masters = [];
  if (_.isEmpty(nonPrimColumns))
    return masters;
  let alC = _.reject(alCols, { table_name: nonPrimColumns[0].table_name });

  _.forEach(nonPrimColumns, (col) => {
    let mastrs = _.filter(alC, { column_name: col.column_name, column_key: 'PRI' });
    if (!_.isEmpty(mastrs)) {
      _.forEach(mastrs, (mCol) => {
        let cl = { ...mCol };
        let mst = cl.table_name;
        let mstc = cl.column_name;
        cl.table_name = col.table_name;
        cl.column_name = col.column_name;
        cl.master_table_name = mst;
        cl.master_table_column = mstc;
        cl.db = col.db;
        cl.db_master = cl.db;
        cl.branch = mst;
        masters.push({ relation_type: relationType, ...cl, active: true });
      });
    }
  });
  return masters;
}

function derivedTables(alCols, primColumn, relationType) {
  let alC = _.reject(alCols, { table_name: primColumn.table_name });
  let dr = _.filter(alC, { column_name: primColumn.column_name });
  if (_.isEmpty(dr))
    return [];
  let derived = _.map(dr, (col) => {
    let cl = { ...col };
    cl.derived_table_name = cl.table_name;
    cl.derived_column_name = cl.column_name;
    cl.table_name = primColumn.table_name;
    cl.column_name = primColumn.column_name;
    cl.db = primColumn.db;
    cl.db_derived = cl.db;
    cl.branch = cl.table_name;
    return { relation_type: relationType, ...cl, active: true }
  });
  return derived;
}