let _ = require('lodash');
let myc_pool = require('./connection_pool_sql_to_application');
let async = require('async');
let { getDBSchema } = require('./db_object');
let { dbERModel } = require('./db_er_model');
let { writeFile } = require('../file_op/write_to_file');   // Change
let { SCAFFOLD_FOLDER } = require('../label_constant/scaffold_folder');

exports.listDB = function (commandObj, callback) {
  myc_pool.getConnection((err, connection) => {
    connection.query('SHOW DATABASES', function (error, result, fields) {
      if (error) {
        callback(error, null);
      } else {
        console.log('DB List: ');
        _.forEach(result, (rs) => { console.log(rs); });
      }
    });
    connection.release();
  });
};

exports.appInit = function (commandObj, callback) {
  let app_name = '';
  let db_list = '';
  _.forEach(commandObj.properties, (prop) => {
    if (prop.property_name == 'app_name')
      app_name = prop.property_value[0];
    if (prop.property_name == 'db_list')
      db_list = prop.property_value;
  });

  // op_data.db_list, op_data.application_name, op_data.application_description, writeFile{[{folder_name, file_name, extension, file_contents}]}
  let op_data = { db_list: db_list, app_name: app_name }; //_.split(op_data.db_list, ', ');
  let scaffoldFolder = SCAFFOLD_FOLDER;

  async.waterfall([
    // Write files, after building the scaffold, check for existing scaffold, and integrate
    function (clbck) {
      console.log('Fetching DB Schema...');
      if (!_.isEmpty(op_data.db_list)) {
        async.concat(op_data.db_list, getDBSchema, (err, results) => {
          clbck(err, { ...op_data, db_schemas: results });
        });
      }
    },
    function (rslt, clbck) {
      console.log('Building DB Entity Relation Model...');
      dbERModel({ application_name: app_name, db_schemas: rslt['db_schemas'] }, (err, entities) => { clbck(err, { ...rslt, entities: entities }); });
    },
    function (rslt, clbck) {
      console.log('Writing the scaffold to file...');
      let erModel = _.flattenDeep(rslt.entities);      
      writeFile([{ folder_name: scaffoldFolder + app_name, file_name: app_name + '_' + 'er_model', file_contents: JSON.stringify(erModel), extension: '.json' }], (err, results) => {
        callback(err, { ...rslt, ...results });
      });
    }
  ]);
}