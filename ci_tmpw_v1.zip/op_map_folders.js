let _ = require('lodash');

let opMapFolders = {
  db_ops: [
    './db_ops/op_map',
    './scaff_ops/op_map',
    './ci_ops/op_map'
  ]
};

exports.getOPMapFolders = function () {
  return opMapFolders;
}

exports.getOpsList = function () {
  let opMp = opMapFolders;
  let ops = [];
  _.forEach(opMp, (opfiles, op_type) => {
    // require call op_map method
    _.forEach(opfiles, (opfile) => {
      let opFile = require(opfile);
      ops.push(...opFile.getOps());
    });
  });
  return ops;
}