exports.getOps = function () {
  return [
    {
      op_name: 'list_apps',
      op_file: './scaff_ops/scaff_ops',
      op_method: 'listApps',
      help_text: 'Lists app scaffolds already built.'
    },
    {
      op_name: 'app_schema',
      op_file: './scaff_ops/scaff_ops',
      op_method: 'appSchema',
      help_text: 'Show app components takes "app_name, table_name" properties.'
    }
  ]
}