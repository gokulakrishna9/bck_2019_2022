let _ = require('lodash');
let { readFiles } = require('../read_files');

exports.readScaffold = function(appName, callback) {
  readFiles('./code/' + appName + '/db_scaffold', (err, files) => {
    files = _.map(files, (file) => {return {...file, content: JSON.parse(file.content)};});
    callback(err, files);
  });
}