let async = require('async');
let _ = require('lodash');
let { readScaffold } = require('./read_scaffold');
let { findCaseInsensitiveSubString } = require('../helper_functions/string_function');

exports.listApps = function (commandObj, callback) {
  readScaffold('', (err, files) => {
    if (!_.isEmpty(err)) {
      console.log('Folder Read Error.')
      console.log(err);
    } else {
      let appFiles = _.filter(files, (file) => { return findCaseInsensitiveSubString('about_application', file.file_name); });
      console.log('Application List:');
      _.forEach(appFiles, (file) => {
        console.log("Application Name: " + file.content.app_name + ', DB List: ' + _.join(file.content.db_list, ', '));
      });
    }
    callback();
  });
}

exports.appSchema = function (commandObj, callback) {
  // sorting operation later
  let appName = '';
  let tableList = [];
  _.forEach(commandObj.properties, (prop) => {
    if (prop.property_name == 'app_name')
      appName = prop.property_value[0];
    if (prop.property_name == 'table_list')
      tableList = prop.property_value;
  });
  readScaffold(appName, (err, files) => {
    if (!_.isEmpty(err)) {
      console.log('Folder Read Error.')
      console.log(err);
    } else {
      // one line summary of number of tables and number of columns
      // db_name, table_name, primary_key, label_column, masters_list
      // Nothing in this as of now
      let aboutApp = _.filter(files, (file) => { return findCaseInsensitiveSubString('about_application', file.file_name); })[0];
      let columns = 0;
      let summary = [];
      if (!_.isEmpty(tableList)) {
        files = _.filter(files, (file) => {
          if(_.isEmpty(file.content.table_name))
            return false;
          let rtV = false;
          _.forEach(tableList, (tbl) => { 
            if(findCaseInsensitiveSubString(file.content.table_name, tbl)){
              rtV = true;
              return false;
            }; 
          }); 
          return rtV;
        });
      }
      _.forEach(files, (file) => {
        file = file.content;
        if(_.isEmpty(file.table_name))
          return;
        columns += file.table_columns.length;
        let primaryKey = _.filter(file.table_columns, { column_key: "PRI" })[0];
        let masters = _.map(_.filter(file.relation, { relation_type: 'masters' }), (mst) => { return { table_name: mst.table_name, db_name: mst.db, column_name: mst.column_name } });
        label = _.isEmpty(file.labels) ? '' : file.labels[0].column_name;
        summary.push({ db_name: file.db, table_name: file.table_name, primary_key: primaryKey.column_name, label_column: label, masters_list: masters });
      });
      console.log('Application Summary: ');
      console.log('Total Entities: ' + files.length + ', Total Columns: ' + columns);
      _.forEach(summary, (smry) => {
        console.log('DB Name: ' + smry.db_name + ', Table Name: ' + smry.table_name + ', Primary Key: ' + smry.primary_key + ', Label Col: ' + smry.label_column);
        if(!_.isEmpty(smry.masters_list)){
          console.log('Masters');
          _.forEach(smry.masters_list, (mstr) => {
            console.log('DB Name: ' + mstr.db_name + ', Table Name: ' + mstr.table_name + ', Join On: ' + mstr.column_name);
          });
        }
        console.log('');
      });
    }
    callback();
  });
}

exports.listTableMasters = function (commandObj, callback) {

}

exports.addTableMasters = function (commandObj, callback) {
  // direct, one to many link table{one order having many tests}
}

exports.removeTableMasters = function (commandObj, callback) {

}

exports.listTableLabels = function (commmandObj, callback) {

}

exports.setLabel = function (commandObj, callback) {

}