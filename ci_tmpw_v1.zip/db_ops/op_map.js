exports.getOps = function () {
  return [
    {
      op_name: 'list_db',
      op_file: './db_ops/db_ops',
      op_method: 'listDB',
      help_text: 'Lists Databases that can be accessed.'
    },
    {
      op_name: 'app_init',
      op_file: './db_ops/db_ops',
      op_method: 'appInit',
      help_text: 'Initialize an application properties{app_name, db_list-comma separated values}.'
    }
  ]
}