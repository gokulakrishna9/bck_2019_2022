let _ = require('lodash');
let myc_pool = require('./connection_pool_sql_to_application');
let async = require('async');
let { getDBSchema } = require('./db_objects');
let { dbModel } = require('./db_model');
let { configTemplate } = require('./app_config');
let { writeFile } = require('../helper_functions/write_to_file');
let { findCaseInsensitiveSubString } = require('../helper_functions/string_function');

exports.listDB = function (commandObj, callback) {
  myc_pool.getConnection((err, connection) => {
    connection.query('SHOW DATABASES', function (error, result, fields) {
      if (error) {
        callback(error, null);
      } else {
        console.log('DB List: ');
        _.forEach(result, (rs) => { console.log(rs); });
      }
    });
    connection.release();
  });
};

exports.appInit = function (commandObj, callback) {
  let app_name = '';
  let db_list = '';
  _.forEach(commandObj.properties, (prop) => {
    if (prop.property_name == 'app_name')
      app_name = prop.property_value[0];
    if (prop.property_name == 'db_list')
      db_list = prop.property_value;
  });

  // op_data.db_list, op_data.application_name, op_data.application_description, writeFile{[{folder_name, file_name, extension, file_contents}]}
  let op_data = { db_list: db_list, app_name: app_name }; //_.split(op_data.db_list, ', ');
  let scaffoldFolder = './code/';
  async.waterfall([
    // Write files, after building the scaffold, check for existing scaffold, and integrate
    function (clbck) {
      console.log('DB Schema');
      if (!_.isEmpty(op_data.db_list)) {
        async.concat(op_data.db_list, getDBSchema, (err, results) => {
          clbck(err, { ...op_data, db_schemas: results });
        });
      }
    },
    function (rslt, clbck) {
      console.log('DB Model');
      dbModel({ application_name: app_name, db_schemas: rslt['db_schemas'] }, (err, entities) => { clbck(err, { ...rslt, entities: entities }); });
    },
    function (rslt, clbck) {
      console.log('Write to file');
      /*
      writeFile([{ folder_name: scaffoldFolder + app_name + '/db_scaffold', file_name: 'application_config', file_contents: JSON.stringify({ ...writeDefaultConfig(rslt.entities), ...op_data }), extension: '.json' }], (err, results) => { });
      */
      writeFile(_.map(rslt.entities, (entity) => { return { folder_name: scaffoldFolder + app_name + '/db_scaffold', file_name: entity.db + '_' + entity.table_name, file_contents: JSON.stringify(entity), extension: '.json' }; }), (err, results) => { callback(err, { ...rslt, ...results }); });
    }
  ]);
}

// MOVE TO df_main
function writeDefaultConfig(entities) {
  // field comments to determine default config properties
  // table_columns, primary key has table type
  let appConfig = {
    admin_master: [],
    application_master: [],
    programmer_table: [],
    value_table: [],
    link_master: [],
    multi_record: [],
    sub_form: [],
    change_log_table: [],   // save only the change
    acl_table: [],
    grouping: [],           // {group_name -> table_list, head_table -> '', head_label -> ''}
    global_log_field: []
  };
  let grouping = [];
  _.forEach(entities, (entity) => {
    let pKey = _.filter(entity.table_columns, { column_key: 'PRI' })[0];
    if (_.isEmpty(pKey))
      return;
    if (_.isEmpty(pKey.column_comment))
      return;
    if (findCaseInsensitiveSubString('admin_master', pKey.column_comment)) {
      appConfig.admin_master.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('application_master', pKey.column_comment)) {
      appConfig.application_master.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('programmer_table', pKey.column_comment)) {
      appConfig.programmer_table.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('value_table', pKey.column_comment)) {
      appConfig.value_table.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('link_master', pKey.column_comment)) {
      appConfig.link_master.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('multi_record', pKey.column_comment)) {
      appConfig.multi_record.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('sub_form', pKey.column_comment)) {
      appConfig.sub_form.push(entity.table_name);
    } else if (findCaseInsensitiveSubString('acl_table', pKey.column_comment)) {
      appConfig.acl_table.push(entity.table_name);
    }
    let tableProps = [];
    _.forEach(_.split(pKey.column_comment, ';'), (key_val) => { tableProps.push(_.split(key_val, '-')); });
    _.forEach(tableProps, (prop) => {
      if (_.isEmpty(prop[0]))
        return;
      if (findCaseInsensitiveSubString('group_name', prop[0])) {
        grouping.push({ [prop[1]]: entity.table_name });
      };
    });
  });
  return appConfig;
  // {server_admin, config_master, programmer, value_table, link_master, multi_record, sub_form, acl_table, global_config_fields}
  // search column comments for table_label
}

/*
{
  "server_admin": [],
  "config_master": [],
  "programmer": [],
  "value_table": [],
  "link_master": [],
  "multi_record": [],
  "sub_form": [],
  "acl_table": [],
  "routing": [],
  "global_config_fields": [],
  "comment": "config_masters,\n    not the bulk data; config_link_table,\n    multi select masters; access control tables; routing[main menu, sub menu{grouping}, ...]",
  "db_list": [
    "coders_tribe"
  ],
  "app_name": "coders_tribe"
}
*/