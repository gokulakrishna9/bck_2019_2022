exports.configTemplate = function() {
  return {
    server_admin: [],
    config_master: [],
    programmer: [],
    value_table: [],
    link_master: [],
    multi_record: [],
    sub_form: [],
    acl_table: [],
    routing: [],
    global_config_fields: [],
    comment: 
    `config_masters,
    not the bulk data; config_link_table,
    multi select masters; access control tables; routing[main menu, sub menu{grouping}, ...]`
  }
}