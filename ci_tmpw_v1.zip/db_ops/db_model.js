let _ = require('lodash');
let { fieldObj } = require('./scaffold_helper');
exports.dbModel = function (applObj, clbck) {
  let dbSchemas = applObj.db_schemas;
  // all primary keys
  // all tables
  // related_tables{table_name, link_on, label, relation_type}
  // related_table_columns{table_name{columns, label}}
  let entities = [];
  let allColumns = schemaColumns(dbSchemas);
  let primaryKeys = allPrimaryKeys(allColumns);
  let appName = applObj.application_name;
  _.forEach(primaryKeys, (primaryKey) => {
    let db = primaryKey.db;
    let tableName = primaryKey.table_name;
    let ops = [
      { op_name: '', params: {} },
    ];
    let tableColumns = tblColumns(allColumns, primaryKey);
    let labelColumns = findLabelFields(tableColumns);
    let tableType = _.isEmpty(labelColumns) ? 'link_table' : '';
    let relatedTables = relatedTbls(allColumns, tableColumns);
    entities.push({
      entity_type: 'sql_table', folder_name: appName + '/scaffold', file_name: db + '_' + tableName, extension: '.json', table_type: tableType,
      app_name: appName, db: db, table_name: tableName,
      ops: ops, table_columns: tableColumns, labels: labelColumns,
      relation: relatedTables
    });
  });
  
  clbck(null, entities);
}

function allPrimaryKeys(allColumns) {
  return _.filter(allColumns, { column_key: 'PRI' });
}

function schemaColumns(dbSchemas) {
  let allColumns = _.map(dbSchemas, (schema) => {
    return schema.columns;
  });
  return _.map(_.flatten(allColumns), (col) => { return fieldObj(col); });
}

function tblColumns(allColumns, primaryKey) {
  return _.filter(allColumns, { db: primaryKey.db, table_name: primaryKey.table_name });
}

// given table columns deduct label field
// THIS IS A RULE --WILL GET STUCK
function findLabelFields(tableColumns) {
  let labelColumns = _.filter(tableColumns, (column) => {
    return (column.column_type == 'varchar' || column.column_type == 'char')
  });
  return labelColumns;
}

function relatedTbls(allColumns, tableColumns) {
  let primaryColumn = _.filter(tableColumns, { column_key: 'PRI' })[0];
  if (_.isEmpty(primaryColumn))
    return;
  let nonPrimColumns = _.filter(_.reject(tableColumns, { column_key: 'PRI' }), { column_type: 'int' });
  let alCols = _.reject(allColumns, { table_name: primaryColumn.table_name });
  let masters = mastersTables(alCols, nonPrimColumns, 'masters');
  let derived = derivedTables(alCols, primaryColumn, 'derived');
  let branching = [];
  _.forEach({ ...masters, ...derived }, (lnk) => {
    let aC = _.reject(alCols, { table_name: lnk.table_name });
    let pC = _.filter(allColumns, { table_name: lnk.table_name, column_key: 'PRI' });
    let nPC = _.reject(_.filter(alCols, { table_name: lnk.table_name }), { table_name: lnk.table_name, column_key: 'PRI' });
    branching.push(
      ..._.map(mastersTables(aC, nPC, 'branching_masters'), (mst) => { return { ...mst, branch_on: lnk.table_name } }),
      ..._.map(derivedTables(aC, pC, 'branching_derived'), (dr) => { return { ...mst, branch_on: lnk.table_name } })
    );
  });
  return [...masters, ...derived, ...branching];
}

function mastersTables(alCols, nonPrimColumns, relationType) {
  let masters = [];
  _.forEach(nonPrimColumns, (col) => {
    let mastrs = _.filter(alCols, { column_name: col.column_name, column_key: 'PRI' });
    if (!_.isEmpty(mastrs)) {
      _.forEach(mastrs, (col) => {
        masters.push({ ...col, relation_type: relationType, active: true });
      });
    }
  });
  return masters;
}

function derivedTables(alCols, primColumn, relationType) {
  return _.map(_.filter(alCols, { column_name: primColumn.column_name }), (col) => { return { ...col, relation_type: relationType, active: true } });
}