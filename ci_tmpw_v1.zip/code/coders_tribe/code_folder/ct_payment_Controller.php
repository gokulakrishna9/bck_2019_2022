<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 class ct_payment_Controller extends CI_CONTROLLER {
  public function _remap($method) {
    if(!$this->authenticate_user()) {
      $this->authentication_failure();
      return;
    }
    if(!$this->authorize_user($method)) {
      $this->authorization_failure();
      return;
    }
    if(method_exists($this, $method)) {
      $this->$method();
    } else {
      $this->default_handler($method);
    }
  }
  function add_record() {
    $this->load->model('ct_student_model');
    $this->data['parent_record']['ct_student'] = $this->ct_student->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->load->model('ct_payment_model');
    $this->data['ct_payment_record'] = $this->ct_payment_model->get_record();
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
      $this->data['form_data']['ct_payment_id'] = is_null($this->input->post('ct_payment_id')) ? '' : $this->input->post('ct_payment_id');
      $this->data['form_data']['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
      $this->data['form_data']['payment'] = is_null($this->input->post('payment')) ? '' : $this->input->post('payment');
      $this->data['form_data']['check_number'] = is_null($this->input->post('check_number')) ? '' : $this->input->post('check_number');
      $this->data['form_data']['account_holder_name'] = is_null($this->input->post('account_holder_name')) ? '' : $this->input->post('account_holder_name');
      $this->data['form_data']['account_number'] = is_null($this->input->post('account_number')) ? '' : $this->input->post('account_number');
      $this->data['form_data']['bank_name'] = is_null($this->input->post('bank_name')) ? '' : $this->input->post('bank_name');
      $this->data['form_data']['ifsc_code'] = is_null($this->input->post('ifsc_code')) ? '' : $this->input->post('ifsc_code');
      $this->data['form_data']['transaction_type'] = is_null($this->input->post('transaction_type')) ? '' : $this->input->post('transaction_type');
      $this->data['form_data']['transaction_id'] = is_null($this->input->post('transaction_id')) ? '' : $this->input->post('transaction_id');
      $this->data['form_data']['transaction_date'] = is_null($this->input->post('transaction_date')) ? '' : $this->input->post('transaction_date');
      $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
      $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    }
    else {
      $this->data['add_record'] = $this->ct_payment_model->add_record();
    }
    $this->data['method_name'] = 'add_record';
    $this->load->view('ct_payment_vwcom/default_grid', $this->data);
  }
  function update_record() {
    $this->load->model('ct_student_model');
    $this->data['parent_record']['ct_student'] = $this->ct_student->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    if($this->input->get('get_record')) {
        $update_record = $this->ct_payment->get_record()[0]->result;
        $this->data['form_data']['ct_payment_id'] = $update_record->ct_payment_id;
        $this->data['form_data']['ct_batch_id'] = $update_record->ct_batch_id;
        $this->data['form_data']['payment'] = $update_record->payment;
        $this->data['form_data']['check_number'] = $update_record->check_number;
        $this->data['form_data']['account_holder_name'] = $update_record->account_holder_name;
        $this->data['form_data']['account_number'] = $update_record->account_number;
        $this->data['form_data']['bank_name'] = $update_record->bank_name;
        $this->data['form_data']['ifsc_code'] = $update_record->ifsc_code;
        $this->data['form_data']['transaction_type'] = $update_record->transaction_type;
        $this->data['form_data']['transaction_id'] = $update_record->transaction_id;
        $this->data['form_data']['transaction_date'] = $update_record->transaction_date;
        $this->data['form_data']['created_on'] = $update_record->created_on;
        $this->data['form_data']['updated_on'] = $update_record->updated_on;
        unset($_POST['ct_payment_id']);
        $this->data['method_name'] = 'update_record';
    }
    else {
      if($this->form_validation->run() == FALSE) {
        $this->data['error_record'] = validation_errors();
        $this->data['form_data']['ct_payment_id'] = is_null($this->input->post('ct_payment_id')) ? '' : $this->input->post('ct_payment_id');
        $this->data['form_data']['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
        $this->data['form_data']['payment'] = is_null($this->input->post('payment')) ? '' : $this->input->post('payment');
        $this->data['form_data']['check_number'] = is_null($this->input->post('check_number')) ? '' : $this->input->post('check_number');
        $this->data['form_data']['account_holder_name'] = is_null($this->input->post('account_holder_name')) ? '' : $this->input->post('account_holder_name');
        $this->data['form_data']['account_number'] = is_null($this->input->post('account_number')) ? '' : $this->input->post('account_number');
        $this->data['form_data']['bank_name'] = is_null($this->input->post('bank_name')) ? '' : $this->input->post('bank_name');
        $this->data['form_data']['ifsc_code'] = is_null($this->input->post('ifsc_code')) ? '' : $this->input->post('ifsc_code');
        $this->data['form_data']['transaction_type'] = is_null($this->input->post('transaction_type')) ? '' : $this->input->post('transaction_type');
        $this->data['form_data']['transaction_id'] = is_null($this->input->post('transaction_id')) ? '' : $this->input->post('transaction_id');
        $this->data['form_data']['transaction_date'] = is_null($this->input->post('transaction_date')) ? '' : $this->input->post('transaction_date');
        $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
        $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
        $this->data['method_name'] = 'update_record';
      }
      else {
        $this->data['update_record'] = $this->ct_payment_model->update_record();
        $this->data['method_name'] = 'add_record';
      }
    }
    $this->data['ct_payment_record'] = $this->ct_payment_model->get_record();
    $this->load->view('ct_payment_vwcom/default_grid', $this->data);
  }
  function delete_record() {
    $this->load->model('ct_student_model');
    $this->data['parent_record']['ct_student'] = $this->ct_student->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->form_validation->set_rules('ct_payment_id', 'Ct_payment_id', 'required', ' ');
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
    }
    else {
      $this->data['delete_record'] = $this->ct_payment_model->delete_record();
    }
    $this->data['ct_payment_record'] = $this->ct_payment_model->get_record();
    $this->load->view('ct_payment_vwcom/default_grid', $this->data);
  }
  function get_record() {
    $this->load->model('ct_student_model');
    $this->data['parent_record']['ct_student'] = $this->ct_student->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->data['ct_payment_record'] = $this->ct_payment_model->get_record();
    $this->load->view('ct_payment_vwcom/default_grid', $this->data);
  }
  private function authenticate_user(){return true;}
  private function authorize_user(){return true;}
  private function authentication_failure(){show_404();}
  private function authorization_failure(){show_404();}
  private function default_handler(){show_404();}
}