<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 class ct_student_batch_Controller extends CI_CONTROLLER {
  public function _remap($method) {
    if(!$this->authenticate_user()) {
      $this->authentication_failure();
      return;
    }
    if(!$this->authorize_user($method)) {
      $this->authorization_failure();
      return;
    }
    if(method_exists($this, $method)) {
      $this->$method();
    } else {
      $this->default_handler($method);
    }
  }
  function add_record() {
    $this->load->model('ct_student_model');
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->load->model('ct_student_batch_model');
    $this->data['ct_student_batch_record'] = $this->ct_student_batch_model->get_record();
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
      $this->data['form_data']['ct_student_batch_id'] = is_null($this->input->post('ct_student_batch_id')) ? '' : $this->input->post('ct_student_batch_id');
      $this->data['form_data']['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
      $this->data['form_data']['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
      $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
      $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    }
    else {
      $this->data['add_record'] = $this->ct_student_batch_model->add_record();
    }
    $this->data['method_name'] = 'add_record';
    $this->load->view('ct_student_batch_vwcom/default_grid', $this->data);
  }
  function update_record() {
    $this->load->model('ct_student_model');
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    if($this->input->get('get_record')) {
        $update_record = $this->ct_student_batch->get_record()[0]->result;
        $this->data['form_data']['ct_student_batch_id'] = $update_record->ct_student_batch_id;
        $this->data['form_data']['ct_student_id'] = $update_record->ct_student_id;
        $this->data['form_data']['ct_batch_id'] = $update_record->ct_batch_id;
        $this->data['form_data']['created_on'] = $update_record->created_on;
        $this->data['form_data']['updated_on'] = $update_record->updated_on;
        unset($_POST['ct_student_batch_id']);
        $this->data['method_name'] = 'update_record';
    }
    else {
      if($this->form_validation->run() == FALSE) {
        $this->data['error_record'] = validation_errors();
        $this->data['form_data']['ct_student_batch_id'] = is_null($this->input->post('ct_student_batch_id')) ? '' : $this->input->post('ct_student_batch_id');
        $this->data['form_data']['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
        $this->data['form_data']['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
        $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
        $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
        $this->data['method_name'] = 'update_record';
      }
      else {
        $this->data['update_record'] = $this->ct_student_batch_model->update_record();
        $this->data['method_name'] = 'add_record';
      }
    }
    $this->data['ct_student_batch_record'] = $this->ct_student_batch_model->get_record();
    $this->load->view('ct_student_batch_vwcom/default_grid', $this->data);
  }
  function delete_record() {
    $this->load->model('ct_student_model');
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->form_validation->set_rules('ct_student_batch_id', 'Ct_student_batch_id', 'required', ' ');
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
    }
    else {
      $this->data['delete_record'] = $this->ct_student_batch_model->delete_record();
    }
    $this->data['ct_student_batch_record'] = $this->ct_student_batch_model->get_record();
    $this->load->view('ct_student_batch_vwcom/default_grid', $this->data);
  }
  function get_record() {
    $this->load->model('ct_student_model');
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->data['ct_student_batch_record'] = $this->ct_student_batch_model->get_record();
    $this->load->view('ct_student_batch_vwcom/default_grid', $this->data);
  }
  private function authenticate_user(){return true;}
  private function authorize_user(){return true;}
  private function authentication_failure(){show_404();}
  private function authorization_failure(){show_404();}
  private function default_handler(){show_404();}
}