<?php class ct_payment_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['ct_student_id'] = $this->session->has_userdata('ct_student_id') ? $this->session->userdata('ct_student_id') : $add_data['ct_student_id'];
    $add_data['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? $add_data['ct_student_id'] : $this->input->post('ct_student_id');
    $this->session->set_userdata('ct_student_id', $add_data['ct_student_id']);
    $add_data['ct_payment_id'] = is_null($this->input->post('ct_payment_id')) ? '' : $this->input->post('ct_payment_id');
    $add_data['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $add_data['payment'] = is_null($this->input->post('payment')) ? '' : $this->input->post('payment');
    $add_data['check_number'] = is_null($this->input->post('check_number')) ? '' : $this->input->post('check_number');
    $add_data['account_holder_name'] = is_null($this->input->post('account_holder_name')) ? '' : $this->input->post('account_holder_name');
    $add_data['account_number'] = is_null($this->input->post('account_number')) ? '' : $this->input->post('account_number');
    $add_data['bank_name'] = is_null($this->input->post('bank_name')) ? '' : $this->input->post('bank_name');
    $add_data['ifsc_code'] = is_null($this->input->post('ifsc_code')) ? '' : $this->input->post('ifsc_code');
    $add_data['transaction_type'] = is_null($this->input->post('transaction_type')) ? '' : $this->input->post('transaction_type');
    $add_data['transaction_id'] = is_null($this->input->post('transaction_id')) ? '' : $this->input->post('transaction_id');
    $add_data['transaction_date'] = is_null($this->input->post('transaction_date')) ? '' : $this->input->post('transaction_date');
    $add_data['transaction_date'] = empty($add_data['transaction_date']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['transaction_date']));
    $add_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $add_data['created_on'] = empty($add_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['created_on']));
    $add_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $add_data['updated_on'] = empty($add_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['updated_on']));
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('ct_payment', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['not---set'] = $this->session->has_userdata('ct_payment_not---set') ? $this->session->userdata('ct_payment_not---set') : $update_data['not---set'];
    $update_data['not---set'] = is_null($this->input->post('not---set')) ? $update_data['not---set'] : $this->input->post('not---set');
    $this->session->set_userdata('not---set', $update_data['not---set']);
    $update_data['ct_payment_id'] = is_null($this->input->post('ct_payment_id')) ? '' : $this->input->post('ct_payment_id');
    $update_data['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $update_data['payment'] = is_null($this->input->post('payment')) ? '' : $this->input->post('payment');
    $update_data['check_number'] = is_null($this->input->post('check_number')) ? '' : $this->input->post('check_number');
    $update_data['account_holder_name'] = is_null($this->input->post('account_holder_name')) ? '' : $this->input->post('account_holder_name');
    $update_data['account_number'] = is_null($this->input->post('account_number')) ? '' : $this->input->post('account_number');
    $update_data['bank_name'] = is_null($this->input->post('bank_name')) ? '' : $this->input->post('bank_name');
    $update_data['ifsc_code'] = is_null($this->input->post('ifsc_code')) ? '' : $this->input->post('ifsc_code');
    $update_data['transaction_type'] = is_null($this->input->post('transaction_type')) ? '' : $this->input->post('transaction_type');
    $update_data['transaction_id'] = is_null($this->input->post('transaction_id')) ? '' : $this->input->post('transaction_id');
    $update_data['transaction_date'] = is_null($this->input->post('transaction_date')) ? '' : $this->input->post('transaction_date');
    $update_data['transaction_date'] = empty($update_data['transaction_date']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['transaction_date']));
    $update_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $update_data['created_on'] = empty($update_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['created_on']));
    $update_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $update_data['updated_on'] = empty($update_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['updated_on']));
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['ct_payment_id'] =  $update_data['ct_payment_id'];
    $this->db->update('ct_payment', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['ct_payment_id'] = is_null($this->input->post('ct_payment_id')) ? '' : $this->input->post('ct_payment_id');
    $this->db->delete('ct_payment', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    if($this->input->get_post('not---set'))
      $this->session->set_userdata('not---set', $this->input->get_post('not---set'));
    $this->db->where('not---set.not---set', $this->session->userdata('not---set'));
    if($this->input->get_post('ct_batch_id'))
      $this->db->where('ct_batch.ct_batch_id', $ct_batch_id);
    $this->db->select('ct_student.first_name AS first_name, ct_batch.batch_name AS batch_name, ct_payment.ct_payment_id AS ct_payment_id, ct_payment.ct_student_id AS ct_student_id, ct_payment.ct_batch_id AS ct_batch_id, ct_payment.payment AS payment, ct_payment.check_number AS check_number, ct_payment.account_holder_name AS account_holder_name, ct_payment.account_number AS account_number, ct_payment.bank_name AS bank_name, ct_payment.ifsc_code AS ifsc_code, ct_payment.transaction_type AS transaction_type, ct_payment.transaction_id AS transaction_id, ct_payment.transaction_date AS transaction_date, ct_payment.created_on AS created_on, ct_payment.updated_on AS updated_on')->from('ct_payment');
    $this->db->join('ct_student', 'ct_student.ct_student_id = ct_payment.ct_payment_id', 'left');
    $this->db->join('ct_batch', 'ct_batch.ct_batch_id = ct_payment.ct_payment_id', 'left');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}