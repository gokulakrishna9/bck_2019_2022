<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 class ct_batch_Controller extends CI_CONTROLLER {
  public function _remap($method) {
    if(!$this->authenticate_user()) {
      $this->authentication_failure();
      return;
    }
    if(!$this->authorize_user($method)) {
      $this->authorization_failure();
      return;
    }
    if(method_exists($this, $method)) {
      $this->$method();
    } else {
      $this->default_handler($method);
    }
  }
  function add_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    $this->load->model('ct_batch_model');
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
      $this->data['form_data']['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
      $this->data['form_data']['batch_name'] = is_null($this->input->post('batch_name')) ? '' : $this->input->post('batch_name');
      $this->data['form_data']['batch_fee'] = is_null($this->input->post('batch_fee')) ? '' : $this->input->post('batch_fee');
      $this->data['form_data']['batch_start'] = is_null($this->input->post('batch_start')) ? '' : $this->input->post('batch_start');
      $this->data['form_data']['batch_end'] = is_null($this->input->post('batch_end')) ? '' : $this->input->post('batch_end');
      $this->data['form_data']['session_start_time'] = is_null($this->input->post('session_start_time')) ? '' : $this->input->post('session_start_time');
      $this->data['form_data']['session_end_time'] = is_null($this->input->post('session_end_time')) ? '' : $this->input->post('session_end_time');
      $this->data['form_data']['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
      $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
      $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
      $this->data['form_data']['session_days'] = is_null($this->input->post('session_days')) ? '' : $this->input->post('session_days');
      $this->data['form_data']['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    }
    else {
      $this->data['add_record'] = $this->ct_batch_model->add_record();
    }
    $this->data['method_name'] = 'add_record';
    $this->load->view('ct_batch_vwcom/default_grid', $this->data);
  }
  function update_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    if($this->input->get('get_record')) {
        $update_record = $this->ct_batch->get_record()[0]->result;
        $this->data['form_data']['ct_batch_id'] = $update_record->ct_batch_id;
        $this->data['form_data']['batch_name'] = $update_record->batch_name;
        $this->data['form_data']['batch_fee'] = $update_record->batch_fee;
        $this->data['form_data']['batch_start'] = $update_record->batch_start;
        $this->data['form_data']['batch_end'] = $update_record->batch_end;
        $this->data['form_data']['session_start_time'] = $update_record->session_start_time;
        $this->data['form_data']['session_end_time'] = $update_record->session_end_time;
        $this->data['form_data']['sort_order'] = $update_record->sort_order;
        $this->data['form_data']['created_on'] = $update_record->created_on;
        $this->data['form_data']['updated_on'] = $update_record->updated_on;
        $this->data['form_data']['session_days'] = $update_record->session_days;
        $this->data['form_data']['active'] = $update_record->active;
        unset($_POST['ct_batch_id']);
        $this->data['method_name'] = 'update_record';
    }
    else {
      if($this->form_validation->run() == FALSE) {
        $this->data['error_record'] = validation_errors();
        $this->data['form_data']['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
        $this->data['form_data']['batch_name'] = is_null($this->input->post('batch_name')) ? '' : $this->input->post('batch_name');
        $this->data['form_data']['batch_fee'] = is_null($this->input->post('batch_fee')) ? '' : $this->input->post('batch_fee');
        $this->data['form_data']['batch_start'] = is_null($this->input->post('batch_start')) ? '' : $this->input->post('batch_start');
        $this->data['form_data']['batch_end'] = is_null($this->input->post('batch_end')) ? '' : $this->input->post('batch_end');
        $this->data['form_data']['session_start_time'] = is_null($this->input->post('session_start_time')) ? '' : $this->input->post('session_start_time');
        $this->data['form_data']['session_end_time'] = is_null($this->input->post('session_end_time')) ? '' : $this->input->post('session_end_time');
        $this->data['form_data']['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
        $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
        $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
        $this->data['form_data']['session_days'] = is_null($this->input->post('session_days')) ? '' : $this->input->post('session_days');
        $this->data['form_data']['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
        $this->data['method_name'] = 'update_record';
      }
      else {
        $this->data['update_record'] = $this->ct_batch_model->update_record();
        $this->data['method_name'] = 'add_record';
      }
    }
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->load->view('ct_batch_vwcom/default_grid', $this->data);
  }
  function delete_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    $this->form_validation->set_rules('ct_batch_id', 'Ct_batch_id', 'required', ' ');
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
    }
    else {
      $this->data['delete_record'] = $this->ct_batch_model->delete_record();
    }
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->load->view('ct_batch_vwcom/default_grid', $this->data);
  }
  function get_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    $this->data['ct_batch_record'] = $this->ct_batch_model->get_record();
    $this->load->view('ct_batch_vwcom/default_grid', $this->data);
  }
  private function authenticate_user(){return true;}
  private function authorize_user(){return true;}
  private function authentication_failure(){show_404();}
  private function authorization_failure(){show_404();}
  private function default_handler(){show_404();}
}