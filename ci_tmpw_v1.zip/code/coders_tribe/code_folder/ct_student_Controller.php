<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 class ct_student_Controller extends CI_CONTROLLER {
  public function _remap($method) {
    if(!$this->authenticate_user()) {
      $this->authentication_failure();
      return;
    }
    if(!$this->authorize_user($method)) {
      $this->authorization_failure();
      return;
    }
    if(method_exists($this, $method)) {
      $this->$method();
    } else {
      $this->default_handler($method);
    }
  }
  function add_record() {
    $this->load->model('ct_student_model');
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
      $this->data['form_data']['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
      $this->data['form_data']['first_name'] = is_null($this->input->post('first_name')) ? '' : $this->input->post('first_name');
      $this->data['form_data']['last_name'] = is_null($this->input->post('last_name')) ? '' : $this->input->post('last_name');
      $this->data['form_data']['student_mobile'] = is_null($this->input->post('student_mobile')) ? '' : $this->input->post('student_mobile');
      $this->data['form_data']['parent_mobile'] = is_null($this->input->post('parent_mobile')) ? '' : $this->input->post('parent_mobile');
      $this->data['form_data']['guardian_first_name'] = is_null($this->input->post('guardian_first_name')) ? '' : $this->input->post('guardian_first_name');
      $this->data['form_data']['guardian_last_name'] = is_null($this->input->post('guardian_last_name')) ? '' : $this->input->post('guardian_last_name');
      $this->data['form_data']['relation_type_id'] = is_null($this->input->post('relation_type_id')) ? '' : $this->input->post('relation_type_id');
      $this->data['form_data']['last_institution'] = is_null($this->input->post('last_institution')) ? '' : $this->input->post('last_institution');
      $this->data['form_data']['institution_place'] = is_null($this->input->post('institution_place')) ? '' : $this->input->post('institution_place');
      $this->data['form_data']['highest_education'] = is_null($this->input->post('highest_education')) ? '' : $this->input->post('highest_education');
      $this->data['form_data']['age'] = is_null($this->input->post('age')) ? '' : $this->input->post('age');
      $this->data['form_data']['gender'] = is_null($this->input->post('gender')) ? '' : $this->input->post('gender');
      $this->data['form_data']['address_street_line_one'] = is_null($this->input->post('address_street_line_one')) ? '' : $this->input->post('address_street_line_one');
      $this->data['form_data']['address_street_line_two'] = is_null($this->input->post('address_street_line_two')) ? '' : $this->input->post('address_street_line_two');
      $this->data['form_data']['city'] = is_null($this->input->post('city')) ? '' : $this->input->post('city');
      $this->data['form_data']['pin'] = is_null($this->input->post('pin')) ? '' : $this->input->post('pin');
    }
    else {
      $this->data['add_record'] = $this->ct_student_model->add_record();
    }
    $this->data['method_name'] = 'add_record';
    $this->load->view('ct_student_vwcom/default_grid', $this->data);
  }
  function update_record() {
    if($this->input->get('get_record')) {
        $update_record = $this->ct_student->get_record()[0]->result;
        $this->data['form_data']['ct_student_id'] = $update_record->ct_student_id;
        $this->data['form_data']['first_name'] = $update_record->first_name;
        $this->data['form_data']['last_name'] = $update_record->last_name;
        $this->data['form_data']['student_mobile'] = $update_record->student_mobile;
        $this->data['form_data']['parent_mobile'] = $update_record->parent_mobile;
        $this->data['form_data']['guardian_first_name'] = $update_record->guardian_first_name;
        $this->data['form_data']['guardian_last_name'] = $update_record->guardian_last_name;
        $this->data['form_data']['relation_type_id'] = $update_record->relation_type_id;
        $this->data['form_data']['last_institution'] = $update_record->last_institution;
        $this->data['form_data']['institution_place'] = $update_record->institution_place;
        $this->data['form_data']['highest_education'] = $update_record->highest_education;
        $this->data['form_data']['age'] = $update_record->age;
        $this->data['form_data']['gender'] = $update_record->gender;
        $this->data['form_data']['address_street_line_one'] = $update_record->address_street_line_one;
        $this->data['form_data']['address_street_line_two'] = $update_record->address_street_line_two;
        $this->data['form_data']['city'] = $update_record->city;
        $this->data['form_data']['pin'] = $update_record->pin;
        unset($_POST['ct_student_id']);
        $this->data['method_name'] = 'update_record';
    }
    else {
      if($this->form_validation->run() == FALSE) {
        $this->data['error_record'] = validation_errors();
        $this->data['form_data']['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
        $this->data['form_data']['first_name'] = is_null($this->input->post('first_name')) ? '' : $this->input->post('first_name');
        $this->data['form_data']['last_name'] = is_null($this->input->post('last_name')) ? '' : $this->input->post('last_name');
        $this->data['form_data']['student_mobile'] = is_null($this->input->post('student_mobile')) ? '' : $this->input->post('student_mobile');
        $this->data['form_data']['parent_mobile'] = is_null($this->input->post('parent_mobile')) ? '' : $this->input->post('parent_mobile');
        $this->data['form_data']['guardian_first_name'] = is_null($this->input->post('guardian_first_name')) ? '' : $this->input->post('guardian_first_name');
        $this->data['form_data']['guardian_last_name'] = is_null($this->input->post('guardian_last_name')) ? '' : $this->input->post('guardian_last_name');
        $this->data['form_data']['relation_type_id'] = is_null($this->input->post('relation_type_id')) ? '' : $this->input->post('relation_type_id');
        $this->data['form_data']['last_institution'] = is_null($this->input->post('last_institution')) ? '' : $this->input->post('last_institution');
        $this->data['form_data']['institution_place'] = is_null($this->input->post('institution_place')) ? '' : $this->input->post('institution_place');
        $this->data['form_data']['highest_education'] = is_null($this->input->post('highest_education')) ? '' : $this->input->post('highest_education');
        $this->data['form_data']['age'] = is_null($this->input->post('age')) ? '' : $this->input->post('age');
        $this->data['form_data']['gender'] = is_null($this->input->post('gender')) ? '' : $this->input->post('gender');
        $this->data['form_data']['address_street_line_one'] = is_null($this->input->post('address_street_line_one')) ? '' : $this->input->post('address_street_line_one');
        $this->data['form_data']['address_street_line_two'] = is_null($this->input->post('address_street_line_two')) ? '' : $this->input->post('address_street_line_two');
        $this->data['form_data']['city'] = is_null($this->input->post('city')) ? '' : $this->input->post('city');
        $this->data['form_data']['pin'] = is_null($this->input->post('pin')) ? '' : $this->input->post('pin');
        $this->data['method_name'] = 'update_record';
      }
      else {
        $this->data['update_record'] = $this->ct_student_model->update_record();
        $this->data['method_name'] = 'add_record';
      }
    }
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->view('ct_student_vwcom/default_grid', $this->data);
  }
  function delete_record() {
    $this->form_validation->set_rules('ct_student_id', 'Ct_student_id', 'required', ' ');
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
    }
    else {
      $this->data['delete_record'] = $this->ct_student_model->delete_record();
    }
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->view('ct_student_vwcom/default_grid', $this->data);
  }
  function get_record() {
    $this->data['ct_student_record'] = $this->ct_student_model->get_record();
    $this->load->view('ct_student_vwcom/default_grid', $this->data);
  }
  private function authenticate_user(){return true;}
  private function authorize_user(){return true;}
  private function authentication_failure(){show_404();}
  private function authorization_failure(){show_404();}
  private function default_handler(){show_404();}
}