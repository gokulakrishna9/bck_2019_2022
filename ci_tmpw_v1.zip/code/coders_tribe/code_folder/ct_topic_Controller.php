<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 class ct_topic_Controller extends CI_CONTROLLER {
  public function _remap($method) {
    if(!$this->authenticate_user()) {
      $this->authentication_failure();
      return;
    }
    if(!$this->authorize_user($method)) {
      $this->authorization_failure();
      return;
    }
    if(method_exists($this, $method)) {
      $this->$method();
    } else {
      $this->default_handler($method);
    }
  }
  function add_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    $this->load->model('ct_topic_model');
    $this->data['ct_topic_record'] = $this->ct_topic_model->get_record();
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
      $this->data['form_data']['ct_topic_id'] = is_null($this->input->post('ct_topic_id')) ? '' : $this->input->post('ct_topic_id');
      $this->data['form_data']['topic_name'] = is_null($this->input->post('topic_name')) ? '' : $this->input->post('topic_name');
      $this->data['form_data']['topic_description'] = is_null($this->input->post('topic_description')) ? '' : $this->input->post('topic_description');
      $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
      $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
      $this->data['form_data']['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
      $this->data['form_data']['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    }
    else {
      $this->data['add_record'] = $this->ct_topic_model->add_record();
    }
    $this->data['method_name'] = 'add_record';
    $this->load->view('ct_topic_vwcom/default_grid', $this->data);
  }
  function update_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    if($this->input->get('get_record')) {
        $update_record = $this->ct_topic->get_record()[0]->result;
        $this->data['form_data']['ct_topic_id'] = $update_record->ct_topic_id;
        $this->data['form_data']['topic_name'] = $update_record->topic_name;
        $this->data['form_data']['topic_description'] = $update_record->topic_description;
        $this->data['form_data']['created_on'] = $update_record->created_on;
        $this->data['form_data']['updated_on'] = $update_record->updated_on;
        $this->data['form_data']['sort_order'] = $update_record->sort_order;
        $this->data['form_data']['active'] = $update_record->active;
        unset($_POST['ct_topic_id']);
        $this->data['method_name'] = 'update_record';
    }
    else {
      if($this->form_validation->run() == FALSE) {
        $this->data['error_record'] = validation_errors();
        $this->data['form_data']['ct_topic_id'] = is_null($this->input->post('ct_topic_id')) ? '' : $this->input->post('ct_topic_id');
        $this->data['form_data']['topic_name'] = is_null($this->input->post('topic_name')) ? '' : $this->input->post('topic_name');
        $this->data['form_data']['topic_description'] = is_null($this->input->post('topic_description')) ? '' : $this->input->post('topic_description');
        $this->data['form_data']['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
        $this->data['form_data']['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
        $this->data['form_data']['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
        $this->data['form_data']['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
        $this->data['method_name'] = 'update_record';
      }
      else {
        $this->data['update_record'] = $this->ct_topic_model->update_record();
        $this->data['method_name'] = 'add_record';
      }
    }
    $this->data['ct_topic_record'] = $this->ct_topic_model->get_record();
    $this->load->view('ct_topic_vwcom/default_grid', $this->data);
  }
  function delete_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    $this->form_validation->set_rules('ct_topic_id', 'Ct_topic_id', 'required', ' ');
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
    }
    else {
      $this->data['delete_record'] = $this->ct_topic_model->delete_record();
    }
    $this->data['ct_topic_record'] = $this->ct_topic_model->get_record();
    $this->load->view('ct_topic_vwcom/default_grid', $this->data);
  }
  function get_record() {
    $this->load->model('ct_course_model');
    $this->data['parent_record']['ct_course'] = $this->ct_course->get_record();
    $this->data['ct_topic_record'] = $this->ct_topic_model->get_record();
    $this->load->view('ct_topic_vwcom/default_grid', $this->data);
  }
  private function authenticate_user(){return true;}
  private function authorize_user(){return true;}
  private function authentication_failure(){show_404();}
  private function authorization_failure(){show_404();}
  private function default_handler(){show_404();}
}