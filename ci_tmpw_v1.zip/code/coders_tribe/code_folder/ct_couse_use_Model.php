<?php class ct_couse_use_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['ct_course_id'] = $this->session->has_userdata('ct_course_id') ? $this->session->userdata('ct_course_id') : $add_data['ct_course_id'];
    $add_data['ct_course_id'] = is_null($this->input->post('ct_course_id')) ? $add_data['ct_course_id'] : $this->input->post('ct_course_id');
    $this->session->set_userdata('ct_course_id', $add_data['ct_course_id']);
    $add_data['ct_course_use_id'] = is_null($this->input->post('ct_course_use_id')) ? '' : $this->input->post('ct_course_use_id');
    $add_data['key_word'] = is_null($this->input->post('key_word')) ? '' : $this->input->post('key_word');
    $add_data['course_use'] = is_null($this->input->post('course_use')) ? '' : $this->input->post('course_use');
    $add_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $add_data['created_on'] = empty($add_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['created_on']));
    $add_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $add_data['updated_on'] = empty($add_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['updated_on']));
    $add_data['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    $add_data['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('ct_couse_use', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['not---set'] = $this->session->has_userdata('ct_couse_use_not---set') ? $this->session->userdata('ct_couse_use_not---set') : $update_data['not---set'];
    $update_data['not---set'] = is_null($this->input->post('not---set')) ? $update_data['not---set'] : $this->input->post('not---set');
    $this->session->set_userdata('not---set', $update_data['not---set']);
    $update_data['ct_course_use_id'] = is_null($this->input->post('ct_course_use_id')) ? '' : $this->input->post('ct_course_use_id');
    $update_data['key_word'] = is_null($this->input->post('key_word')) ? '' : $this->input->post('key_word');
    $update_data['course_use'] = is_null($this->input->post('course_use')) ? '' : $this->input->post('course_use');
    $update_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $update_data['created_on'] = empty($update_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['created_on']));
    $update_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $update_data['updated_on'] = empty($update_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['updated_on']));
    $update_data['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    $update_data['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['ct_course_use_id'] =  $update_data['ct_course_use_id'];
    $this->db->update('ct_couse_use', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['ct_course_use_id'] = is_null($this->input->post('ct_course_use_id')) ? '' : $this->input->post('ct_course_use_id');
    $this->db->delete('ct_couse_use', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    if($this->input->get_post('not---set'))
      $this->session->set_userdata('not---set', $this->input->get_post('not---set'));
    $this->db->where('not---set.not---set', $this->session->userdata('not---set'));
    $this->db->select('ct_course.course_name AS course_name, ct_couse_use.ct_course_use_id AS ct_course_use_id, ct_couse_use.ct_course_id AS ct_course_id, ct_couse_use.key_word AS key_word, ct_couse_use.course_use AS course_use, ct_couse_use.created_on AS created_on, ct_couse_use.updated_on AS updated_on, ct_couse_use.active AS active, ct_couse_use.sort_order AS sort_order')->from('ct_couse_use');
    $this->db->join('ct_course', 'ct_course.ct_course_id = ct_couse_use.ct_course_use_id', 'left');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}