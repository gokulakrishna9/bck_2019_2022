<?php class user_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['user_id'] = is_null($this->input->post('user_id')) ? '' : $this->input->post('user_id');
    $add_data['user_name'] = is_null($this->input->post('user_name')) ? '' : $this->input->post('user_name');
    $add_data['password'] = is_null($this->input->post('password')) ? '' : $this->input->post('password');
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('user', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['user_id'] = is_null($this->input->post('user_id')) ? '' : $this->input->post('user_id');
    $update_data['user_name'] = is_null($this->input->post('user_name')) ? '' : $this->input->post('user_name');
    $update_data['password'] = is_null($this->input->post('password')) ? '' : $this->input->post('password');
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['user_id'] =  $update_data['user_id'];
    $this->db->update('user', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['user_id'] = is_null($this->input->post('user_id')) ? '' : $this->input->post('user_id');
    $this->db->delete('user', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    $this->db->select('user.user_id AS user_id, user.user_name AS user_name, user.password AS password')->from('user');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}