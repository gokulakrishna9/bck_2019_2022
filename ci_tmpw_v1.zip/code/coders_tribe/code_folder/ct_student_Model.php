<?php class ct_student_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
    $add_data['first_name'] = is_null($this->input->post('first_name')) ? '' : $this->input->post('first_name');
    $add_data['last_name'] = is_null($this->input->post('last_name')) ? '' : $this->input->post('last_name');
    $add_data['student_mobile'] = is_null($this->input->post('student_mobile')) ? '' : $this->input->post('student_mobile');
    $add_data['parent_mobile'] = is_null($this->input->post('parent_mobile')) ? '' : $this->input->post('parent_mobile');
    $add_data['guardian_first_name'] = is_null($this->input->post('guardian_first_name')) ? '' : $this->input->post('guardian_first_name');
    $add_data['guardian_last_name'] = is_null($this->input->post('guardian_last_name')) ? '' : $this->input->post('guardian_last_name');
    $add_data['relation_type_id'] = is_null($this->input->post('relation_type_id')) ? '' : $this->input->post('relation_type_id');
    $add_data['last_institution'] = is_null($this->input->post('last_institution')) ? '' : $this->input->post('last_institution');
    $add_data['institution_place'] = is_null($this->input->post('institution_place')) ? '' : $this->input->post('institution_place');
    $add_data['highest_education'] = is_null($this->input->post('highest_education')) ? '' : $this->input->post('highest_education');
    $add_data['age'] = is_null($this->input->post('age')) ? '' : $this->input->post('age');
    $add_data['gender'] = is_null($this->input->post('gender')) ? '' : $this->input->post('gender');
    $add_data['address_street_line_one'] = is_null($this->input->post('address_street_line_one')) ? '' : $this->input->post('address_street_line_one');
    $add_data['address_street_line_two'] = is_null($this->input->post('address_street_line_two')) ? '' : $this->input->post('address_street_line_two');
    $add_data['city'] = is_null($this->input->post('city')) ? '' : $this->input->post('city');
    $add_data['pin'] = is_null($this->input->post('pin')) ? '' : $this->input->post('pin');
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('ct_student', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
    $update_data['first_name'] = is_null($this->input->post('first_name')) ? '' : $this->input->post('first_name');
    $update_data['last_name'] = is_null($this->input->post('last_name')) ? '' : $this->input->post('last_name');
    $update_data['student_mobile'] = is_null($this->input->post('student_mobile')) ? '' : $this->input->post('student_mobile');
    $update_data['parent_mobile'] = is_null($this->input->post('parent_mobile')) ? '' : $this->input->post('parent_mobile');
    $update_data['guardian_first_name'] = is_null($this->input->post('guardian_first_name')) ? '' : $this->input->post('guardian_first_name');
    $update_data['guardian_last_name'] = is_null($this->input->post('guardian_last_name')) ? '' : $this->input->post('guardian_last_name');
    $update_data['relation_type_id'] = is_null($this->input->post('relation_type_id')) ? '' : $this->input->post('relation_type_id');
    $update_data['last_institution'] = is_null($this->input->post('last_institution')) ? '' : $this->input->post('last_institution');
    $update_data['institution_place'] = is_null($this->input->post('institution_place')) ? '' : $this->input->post('institution_place');
    $update_data['highest_education'] = is_null($this->input->post('highest_education')) ? '' : $this->input->post('highest_education');
    $update_data['age'] = is_null($this->input->post('age')) ? '' : $this->input->post('age');
    $update_data['gender'] = is_null($this->input->post('gender')) ? '' : $this->input->post('gender');
    $update_data['address_street_line_one'] = is_null($this->input->post('address_street_line_one')) ? '' : $this->input->post('address_street_line_one');
    $update_data['address_street_line_two'] = is_null($this->input->post('address_street_line_two')) ? '' : $this->input->post('address_street_line_two');
    $update_data['city'] = is_null($this->input->post('city')) ? '' : $this->input->post('city');
    $update_data['pin'] = is_null($this->input->post('pin')) ? '' : $this->input->post('pin');
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['ct_student_id'] =  $update_data['ct_student_id'];
    $this->db->update('ct_student', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
    $this->db->delete('ct_student', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    $this->db->select('ct_student.ct_student_id AS ct_student_id, ct_student.first_name AS first_name, ct_student.last_name AS last_name, ct_student.student_mobile AS student_mobile, ct_student.parent_mobile AS parent_mobile, ct_student.guardian_first_name AS guardian_first_name, ct_student.guardian_last_name AS guardian_last_name, ct_student.relation_type_id AS relation_type_id, ct_student.last_institution AS last_institution, ct_student.institution_place AS institution_place, ct_student.highest_education AS highest_education, ct_student.age AS age, ct_student.gender AS gender, ct_student.address_street_line_one AS address_street_line_one, ct_student.address_street_line_two AS address_street_line_two, ct_student.city AS city, ct_student.pin AS pin')->from('ct_student');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}