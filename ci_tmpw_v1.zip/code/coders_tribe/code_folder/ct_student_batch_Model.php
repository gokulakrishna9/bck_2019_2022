<?php class ct_student_batch_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['ct_student_batch_id'] = is_null($this->input->post('ct_student_batch_id')) ? '' : $this->input->post('ct_student_batch_id');
    $add_data['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
    $add_data['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $add_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $add_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('ct_student_batch', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['ct_student_batch_id'] = is_null($this->input->post('ct_student_batch_id')) ? '' : $this->input->post('ct_student_batch_id');
    $update_data['ct_student_id'] = is_null($this->input->post('ct_student_id')) ? '' : $this->input->post('ct_student_id');
    $update_data['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $update_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $update_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['ct_student_batch_id'] =  $update_data['ct_student_batch_id'];
    $this->db->update('ct_student_batch', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['ct_student_batch_id'] = is_null($this->input->post('ct_student_batch_id')) ? '' : $this->input->post('ct_student_batch_id');
    $this->db->delete('ct_student_batch', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    if($this->input->get_post('ct_student_id'))
      $this->db->where('ct_student.ct_student_id', $ct_student_id);
    if($this->input->get_post('ct_batch_id'))
      $this->db->where('ct_batch.ct_batch_id', $ct_batch_id);
    $this->db->select('ct_student.first_name AS first_name, ct_batch.batch_name AS batch_name, ct_student_batch.ct_student_batch_id AS ct_student_batch_id, ct_student_batch.ct_student_id AS ct_student_id, ct_student_batch.ct_batch_id AS ct_batch_id, ct_student_batch.created_on AS created_on, ct_student_batch.updated_on AS updated_on')->from('ct_student_batch');
    $this->db->join('ct_student', 'ct_student.ct_student_id = ct_student_batch.ct_student_batch_id', 'left');
    $this->db->join('ct_batch', 'ct_batch.ct_batch_id = ct_student_batch.ct_student_batch_id', 'left');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}