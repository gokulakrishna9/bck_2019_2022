<?php class ct_course_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['ct_course_id'] = is_null($this->input->post('ct_course_id')) ? '' : $this->input->post('ct_course_id');
    $add_data['course_name'] = is_null($this->input->post('course_name')) ? '' : $this->input->post('course_name');
    $add_data['course_description'] = is_null($this->input->post('course_description')) ? '' : $this->input->post('course_description');
    $add_data['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
    $add_data['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    $add_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $add_data['created_on'] = empty($add_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['created_on']));
    $add_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $add_data['updated_on'] = empty($add_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['updated_on']));
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('ct_course', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['ct_course_id'] = is_null($this->input->post('ct_course_id')) ? '' : $this->input->post('ct_course_id');
    $update_data['course_name'] = is_null($this->input->post('course_name')) ? '' : $this->input->post('course_name');
    $update_data['course_description'] = is_null($this->input->post('course_description')) ? '' : $this->input->post('course_description');
    $update_data['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
    $update_data['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    $update_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $update_data['created_on'] = empty($update_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['created_on']));
    $update_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $update_data['updated_on'] = empty($update_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['updated_on']));
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['ct_course_id'] =  $update_data['ct_course_id'];
    $this->db->update('ct_course', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['ct_course_id'] = is_null($this->input->post('ct_course_id')) ? '' : $this->input->post('ct_course_id');
    $this->db->delete('ct_course', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    $this->db->select('ct_course.ct_course_id AS ct_course_id, ct_course.course_name AS course_name, ct_course.course_description AS course_description, ct_course.sort_order AS sort_order, ct_course.active AS active, ct_course.created_on AS created_on, ct_course.updated_on AS updated_on')->from('ct_course');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}