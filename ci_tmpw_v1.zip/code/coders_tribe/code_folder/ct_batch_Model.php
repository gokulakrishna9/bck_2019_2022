<?php class ct_batch_model extends CI_Model {
  function add_record( ) {
    $add_data = [];
    $add_data['ct_course_id'] = $this->session->has_userdata('ct_course_id') ? $this->session->userdata('ct_course_id') : $add_data['ct_course_id'];
    $add_data['ct_course_id'] = is_null($this->input->post('ct_course_id')) ? $add_data['ct_course_id'] : $this->input->post('ct_course_id');
    $this->session->set_userdata('ct_course_id', $add_data['ct_course_id']);
    $add_data['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $add_data['batch_name'] = is_null($this->input->post('batch_name')) ? '' : $this->input->post('batch_name');
    $add_data['batch_fee'] = is_null($this->input->post('batch_fee')) ? '' : $this->input->post('batch_fee');
    $add_data['batch_start'] = is_null($this->input->post('batch_start')) ? '' : $this->input->post('batch_start');
    $add_data['batch_start'] = empty($add_data['batch_start']) ? date("Y-m-d") : date("Y-m-d", strtotime($add_data['batch_start']));
    $add_data['batch_end'] = is_null($this->input->post('batch_end')) ? '' : $this->input->post('batch_end');
    $add_data['batch_end'] = empty($add_data['batch_end']) ? date("Y-m-d") : date("Y-m-d", strtotime($add_data['batch_end']));
    $add_data['session_start_time'] = is_null($this->input->post('session_start_time')) ? '' : $this->input->post('session_start_time');
    $add_data['session_start_time'] = empty($add_data['session_start_time']) ? '23:59' : date("H:i", strtotime($add_data['session_start_time']));
    $add_data['session_end_time'] = is_null($this->input->post('session_end_time')) ? '' : $this->input->post('session_end_time');
    $add_data['session_end_time'] = empty($add_data['session_end_time']) ? '23:59' : date("H:i", strtotime($add_data['session_end_time']));
    $add_data['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
    $add_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $add_data['created_on'] = empty($add_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['created_on']));
    $add_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $add_data['updated_on'] = empty($add_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($add_data['updated_on']));
    $add_data['session_days'] = is_null($this->input->post('session_days')) ? '' : $this->input->post('session_days');
    $add_data['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    $add_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $this->db->insert('ct_batch', $add_data);
    return array('insert_id' => $this->db->insert_id(), 'input_data' => $add_data, success => true);
  }
  function update_record( ) {
    $update_data = [];
    $update_data['not---set'] = $this->session->has_userdata('ct_batch_not---set') ? $this->session->userdata('ct_batch_not---set') : $update_data['not---set'];
    $update_data['not---set'] = is_null($this->input->post('not---set')) ? $update_data['not---set'] : $this->input->post('not---set');
    $this->session->set_userdata('not---set', $update_data['not---set']);
    $update_data['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $update_data['batch_name'] = is_null($this->input->post('batch_name')) ? '' : $this->input->post('batch_name');
    $update_data['batch_fee'] = is_null($this->input->post('batch_fee')) ? '' : $this->input->post('batch_fee');
    $update_data['batch_start'] = is_null($this->input->post('batch_start')) ? '' : $this->input->post('batch_start');
    $update_data['batch_start'] = empty($update_data['batch_start']) ? date("Y-m-d") : date("Y-m-d", strtotime($update_data['batch_start']));
    $update_data['batch_end'] = is_null($this->input->post('batch_end')) ? '' : $this->input->post('batch_end');
    $update_data['batch_end'] = empty($update_data['batch_end']) ? date("Y-m-d") : date("Y-m-d", strtotime($update_data['batch_end']));
    $update_data['session_start_time'] = is_null($this->input->post('session_start_time')) ? '' : $this->input->post('session_start_time');
    $update_data['session_start_time'] = empty($update_data['session_start_time']) ? '23:59' : date("H:i", strtotime($update_data['session_start_time']));
    $update_data['session_end_time'] = is_null($this->input->post('session_end_time')) ? '' : $this->input->post('session_end_time');
    $update_data['session_end_time'] = empty($update_data['session_end_time']) ? '23:59' : date("H:i", strtotime($update_data['session_end_time']));
    $update_data['sort_order'] = is_null($this->input->post('sort_order')) ? '' : $this->input->post('sort_order');
    $update_data['created_on'] = is_null($this->input->post('created_on')) ? '' : $this->input->post('created_on');
    $update_data['created_on'] = empty($update_data['created_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['created_on']));
    $update_data['updated_on'] = is_null($this->input->post('updated_on')) ? '' : $this->input->post('updated_on');
    $update_data['updated_on'] = empty($update_data['updated_on']) ? '23:59' : date("Y-m-d H:i", strtotime($update_data['updated_on']));
    $update_data['session_days'] = is_null($this->input->post('session_days')) ? '' : $this->input->post('session_days');
    $update_data['active'] = is_null($this->input->post('active')) ? '' : $this->input->post('active');
    $update_data['gcda_user_id'] = $this->session->has_userdata('gcda_user_id') ? $this->session->userdata('gcda_user_id') : '';
    $update_filter = [];
    $update_filter['ct_batch_id'] =  $update_data['ct_batch_id'];
    $this->db->update('ct_batch', $update_data, $update_filter);
    return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $update_data, success => true);
  }
  function delete_record( ) {
    $delete_filter = [];
    $delete_filter['ct_batch_id'] = is_null($this->input->post('ct_batch_id')) ? '' : $this->input->post('ct_batch_id');
    $this->db->delete('ct_batch', $delete_filter);
    return array('success' => true);
  }
  function get_record( ) {
    $apply_filter = [];
    if($this->input->get_post('not---set'))
      $this->session->set_userdata('not---set', $this->input->get_post('not---set'));
    $this->db->where('not---set.not---set', $this->session->userdata('not---set'));
    $this->db->select('ct_course.course_name AS course_name, ct_batch.ct_batch_id AS ct_batch_id, ct_batch.ct_course_id AS ct_course_id, ct_batch.batch_name AS batch_name, ct_batch.batch_fee AS batch_fee, ct_batch.batch_start AS batch_start, ct_batch.batch_end AS batch_end, ct_batch.session_start_time AS session_start_time, ct_batch.session_end_time AS session_end_time, ct_batch.sort_order AS sort_order, ct_batch.created_on AS created_on, ct_batch.updated_on AS updated_on, ct_batch.session_days AS session_days, ct_batch.active AS active')->from('ct_batch');
    $this->db->join('ct_course', 'ct_course.ct_course_id = ct_batch.ct_batch_id', 'left');
    return array('result' => $qry->result(), 'filter_array' => $apply_filter);
  }
}