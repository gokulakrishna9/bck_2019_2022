<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 class user_Controller extends CI_CONTROLLER {
  public function _remap($method) {
    if(!$this->authenticate_user()) {
      $this->authentication_failure();
      return;
    }
    if(!$this->authorize_user($method)) {
      $this->authorization_failure();
      return;
    }
    if(method_exists($this, $method)) {
      $this->$method();
    } else {
      $this->default_handler($method);
    }
  }
  function add_record() {
    $this->load->model('user_model');
    $this->data['user_record'] = $this->user_model->get_record();
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
      $this->data['form_data']['user_id'] = is_null($this->input->post('user_id')) ? '' : $this->input->post('user_id');
      $this->data['form_data']['user_name'] = is_null($this->input->post('user_name')) ? '' : $this->input->post('user_name');
      $this->data['form_data']['password'] = is_null($this->input->post('password')) ? '' : $this->input->post('password');
    }
    else {
      $this->data['add_record'] = $this->user_model->add_record();
    }
    $this->data['method_name'] = 'add_record';
    $this->load->view('user_vwcom/default_grid', $this->data);
  }
  function update_record() {
    if($this->input->get('get_record')) {
        $update_record = $this->user->get_record()[0]->result;
        $this->data['form_data']['user_id'] = $update_record->user_id;
        $this->data['form_data']['user_name'] = $update_record->user_name;
        $this->data['form_data']['password'] = $update_record->password;
        unset($_POST['user_id']);
        $this->data['method_name'] = 'update_record';
    }
    else {
      if($this->form_validation->run() == FALSE) {
        $this->data['error_record'] = validation_errors();
        $this->data['form_data']['user_id'] = is_null($this->input->post('user_id')) ? '' : $this->input->post('user_id');
        $this->data['form_data']['user_name'] = is_null($this->input->post('user_name')) ? '' : $this->input->post('user_name');
        $this->data['form_data']['password'] = is_null($this->input->post('password')) ? '' : $this->input->post('password');
        $this->data['method_name'] = 'update_record';
      }
      else {
        $this->data['update_record'] = $this->user_model->update_record();
        $this->data['method_name'] = 'add_record';
      }
    }
    $this->data['user_record'] = $this->user_model->get_record();
    $this->load->view('user_vwcom/default_grid', $this->data);
  }
  function delete_record() {
    $this->form_validation->set_rules('user_id', 'User_id', 'required', ' ');
    if($this->form_validation->run() == FALSE) {
      $this->data['error_record'] = validation_errors();
    }
    else {
      $this->data['delete_record'] = $this->user_model->delete_record();
    }
    $this->data['user_record'] = $this->user_model->get_record();
    $this->load->view('user_vwcom/default_grid', $this->data);
  }
  function get_record() {
    $this->data['user_record'] = $this->user_model->get_record();
    $this->load->view('user_vwcom/default_grid', $this->data);
  }
  private function authenticate_user(){return true;}
  private function authorize_user(){return true;}
  private function authentication_failure(){show_404();}
  private function authorization_failure(){show_404();}
  private function default_handler(){show_404();}
}