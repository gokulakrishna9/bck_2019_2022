let _ = require('lodash');
exports.parentContext = function () {
  return {
    panel: _.template(`<div class="w3-panel w3-pale-green w3-border-green w3-border"><%= panel_content %></div>`),
    row: _.template(`<%= outer_tab %><div class="w3-row">\n<%= nav_bar_content %>\n<%= outer_tab %></div>`),
    column: _.template(`<%= outer_tab %><%= inner_tab %><div class="w3-col m4 l3"><%= url_label %></div>`),
    label: _.template(`<%= outer_tab %><div class="w3-sidebar">\n<%= nav_bar_content %>\n<%= outer_tab %></div>`),
    value: _.template(``)
  }
}