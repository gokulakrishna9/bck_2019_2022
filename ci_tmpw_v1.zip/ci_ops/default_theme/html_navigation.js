let _ = require('lodash');
exports.navElement = function () {
  return {
    header: _.template(`<%= outer_tab %><div class="w3-bar w3-black">\n<%= nav_bar_content %>\n<%= outer_tab %></div>`),
    anchor: _.template(`<%= outer_tab %><%= inner_tab %><a href="<%= url %>" class="w3-bar-item w3-button"><%= url_label %></a>`),
    sidebar: _.template(`<%= outer_tab %><div class="w3-sidebar">\n<%= nav_bar_content %>\n<%= outer_tab %></div>`),
  }
}