let _ = require('lodash');

exports.defaultThemeProperty = function () {
  return {
    theme_name: 'default',
    tab_spaces: { outer_tab: 4, inner_tab: 2},
    left_nav: {},
    header: {},
    page_op: {},
    form_element: {
      class: {
        label: 'w3-text-teal',
        text: 'w3-input w3-border w3-round w3-pale-green',
        checkbox: 'w3-check',
        radio: 'w3-row',
        select: 'w3-select w3-border'
      }
    },
    form_grid: {
      class: {
        row: 'w3-row w3-margin-bottom',
        col: _.template('w3-col w3-mobile s<%= small_col %> m<%= md_col %> l<%= lg_col %> w3-padding-small')
      }
    },
    filter_element: {
      class: {
        label: 'w3-text-green',
        text: 'w3-input w3-border w3-round w3-pale-green',
        checkbox: 'w3-check',
        radio: 'w3-row',
        select: 'w3-select w3-border'
      }
    },
    filter_grid: {
      row: 'w3-row w3-margin-bottom w3-khaki',
      col: _.template('w3-col w3-mobile s<%= small_col %> m<%= md_col %> l<%= lg_col %> w3-padding-small')
    },
    pagination: {
      container_property: [{ property_name: 'class', property_value: 'w3-bar' }],
      next_page_op_property: [{ property_name: 'class', property_value: 'w3-button' }]
    },
    table: {
      table: [{ property_name: 'class', property_value: 'w3-table-all' }],
      thead: [{ property_name: 'class', property_value: 'w3-light-grey' }]
    },
    parent_grid: {
      row: _.template(`<%= outer_tab %><%= inner_tab %><div class='w3-panel w3-pale-blue w3-leftbar w3-row w3-margin-bottom w3-pale-blue'><%= row_content %></div>`),
      col: _.template(`<%= outer_tab %><%= inner_tab %><%= inner_tab %><div class='w3-col w3-mobile s12 m6 l4 w3-padding-small'><%= column_content %></div>`),
      value: _.template(`<%= outer_tab %><%= inner_tab %><%= inner_tab %><%= inner_tab %><p><span class="w3-tag w3-blue"><%= label %>:&nbps;</span><span class="w3-tag w3-blue"><%= value %></span></p>`)
    },
  }
}