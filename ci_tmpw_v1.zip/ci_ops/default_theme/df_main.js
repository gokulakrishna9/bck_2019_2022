let _ = require('lodash');
let { viewDefault } = require('../view_scaffold');
let { modelDefault } = require('../model_def');
let { routingDef } = require('../routing_def');
let async = require('async');
let { writeFile } = require('../../helper_functions/write_to_file');
let { dbLabel } = require('../db_label');
let { writeCIModel } = require('../ci_model');
let { writeCIController } = require('../ci_controller');
let { defaultThemeProperty } = require('./theme_property');
let { applyTheme } = require('../apply_html_theme');
let { ciView } = require('../ci_view');

exports.dfMain = function (entities, clbck) {
  console.log('In Default Main, build default scaffold');
  let mainFolder = 'code/' + entities[0].content.app_name;
  // default form scaffold
  // let appConf = _.filter(entities, (entity) => { return findCaseInsensitiveSubString('application_config', entity.file_name) })[0].content;
  let ent = _.map(entities, (entity) => { return entity.content; });
  let appConf = dbLabel(ent);

  // default model scaffold
  let modelDef = modelDefault(ent, appConf);
  let models = _.map(modelDef, (ent) => { return { folder_name: mainFolder + '/model_scaffold', file_name: ent.file_name, extension: '.json', file_contents: JSON.stringify(ent) } });
  // default routing
  let rtDef = routingDef(modelDef);
  let viewDef = viewDefault(modelDef);
  let ciVw = ciView(viewDef, rtDef);
  applyTheme(viewDef, defaultThemeProperty());
  viewDef = _.map(viewDef, (ent) => { return { folder_name: mainFolder + '/view_scaffold', file_name: ent.file_name, extension: '.json', file_contents: JSON.stringify(ent) } });  
  let routing = [{ folder_name: mainFolder + '/app_wiring', file_name: 'app_wiring', extension: '.json', file_contents: JSON.stringify(rtDef) }];  
  // Edit the scaffold and rerun the script by deleting files to be changed
  // default model
  let ciMDL = _.map(writeCIModel(modelDef), (ent) => { return { folder_name: mainFolder + '/code_folder', file_name: ent.file_name, extension: '.php', file_contents: ent.file_contents } });
  // default controller
  let ciCTL = _.map(writeCIController(modelDef), (ent) => { return { folder_name: mainFolder + '/code_folder', file_name: ent.file_name, extension: '.php', file_contents: ent.file_contents } });
  // default view
  async.waterfall([
    function (callback) {
      console.log('Writing model scaffold');
      writeFile(models, callback);
    },
    function (rslt, callback) {
      console.log('Writing route');
      writeFile(routing, callback);
    },
    function (rslt, callback) {
      console.log('Writing codeigniter models');
      writeFile(ciMDL, callback);
    },
    function (rslt, callback) {
      console.log('Writing codeigniter controllers');
      writeFile(ciCTL, callback);
    },
    function (rslt, callback) {
      console.log('Writing View Scaffold');
      writeFile(viewDef, callback);
    },
  ], (err, rslt) => {

  });
  clbck();
}