// type="<%= input_type %>" class="<%= class_name %>" name="<%= field_name %>" value="<?php echo $input_data-><%= field_name %>; ?>" id="<%= field_id %>
// class="<%= class_name %>" for="<%= field_name %>"
// <?php foreach($<%= master_table %> as $record){ ?>
// <?php } ?>
// <option value="<?php echo $record-><%= primary_column %>; ?>" <?php if($input_data-><%= primary_column %> == $record-><%= primary_column %>) echo 'selected'; ?>><?php echo $record-><%= label_column %>; ?></option>
// class="form-control" name="<%= field_name %>" id="<%= field_name %>" rows="<%= rows %>"
// Value labels form_data->field_name, error_record{echo and see}, 
// table_name_record{insert{insert_id, input_data, success}, update{affected_rows, input_data, success}, 
// delete{success}, get_record{result, filter_data}} for table records
let _ = require('lodash');
// {header{outer_tab, inner_tab, nav_bar_content}, sidebar{outer_tab, inner_tab, nav_bar_content}, anchor{outer_tab, inner_tab, url_label}}
let { navElement } = require('./default_theme/html_navigation');
let { defaultThemeProperty } = require('./default_theme/theme_property');
let { tabSpaces } = require('../helper_functions/string_function');
exports.ciView = function (viewScaff, appWiring) {
  // console.log(viewScaff);
  // write header
  console.log(writeHeader(appWiring));
  console.log(writeLeftNav(appWiring));
  // write parent
  console.log(writeParent(viewScaff));          // view scaffold has the required classes, write the grid function
  // write form grid // break it up into components and tabs
  // added record, record operations
  // write pagination
  // write table grid
}


function writeHeader(appWiring) {
  // route{table_name, label, sort_order, active}
  // use sort order
  let navEle = navElement();
  let navigation = _.map(appWiring.route, (rt, rtn) => {
    rt = _.sortBy(rt, ['sort_order']);
    return navEle.anchor({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab), url: rt[0].table_name, url_label: rt[0].label });
  });
  return navEle.header({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab), nav_bar_content: _.join(navigation, '\n') });
}

function writeLeftNav(appWiring) {
  // sort and build the header
  let navEle = navElement();
  let navigation = _.map(appWiring.route, (rt, rtn) => {
    if (rt.length <= 1)
      return { header: rtn, left_nav: '' };
    rt = _.sortBy(rt, ['sort_order']);
    let lNav = [];
    _.forEach(rt, (ru) => {
      lNav.push(navEle.anchor({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab), url: ru.table_name, url_label: ru.label }));
    });
    return { header: rtn, left_nav: navEle.sidebar({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab), nav_bar_content: _.join(lNav, '\n') }) };
  });
  return navigation;
}

function writeParent(viewScaff) {
  // parent_grid - {outer_tab, inner_tab}row, col, value{label, value}
  _.forEach(viewScaff, (vw) => {
    if (!viewScaff.parent_record['default'])
      return { parent_record: '' };
    let gridEle = [];
    _.forEach(vw.parent_element, (ele) => {
      defaultThemeProperty.parent_grid.value({outer_tab: defaultThemeProperty.tab_spaces.outer_tab, inner_tab: defaultThemeProperty.tab_spaces.inner_tab, label: ele.header, value: ele.value_key});
    });
  });
}