// repititive functions
let _ = require('lodash');

// check if entity has derived table, check if a master of the derived table is part of linkMaster
exports.getMultiSelect = function (linkMaster, derived) {
  let drMst;
  _.forEach(linkMaster, (lmst) => {
    // get derived master
    
    drMst = _.filter(derived.relation, {table_name: lmst.table_name, relation_type: 'master'})[0];
    if(!_.isEmpty(drMst))
      return false;
  });
  return drMst;
}