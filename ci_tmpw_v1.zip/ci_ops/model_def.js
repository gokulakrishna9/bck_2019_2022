let _ = require('lodash');
let { findCaseInsensitiveSubString, splitCapitalize} = require('../helper_functions/string_function');
// The HAVING clause is only for deciding how to form each group or cluster, not for choosing rows in the output.
exports.modelDefault = function (entities, appConf) {
  // field list, field validation, sub form parent to session
  // filter list{{masters and label}, {derived and label}, grouping operator along with SQL methods and operators}
  let models = [];
  _.forEach(entities, (ent) => {
    let tableConf = _.filter(appConf, { table_name: ent.table_name });
    let tableType = _.filter(tableConf, { property_name: 'table_type' });
    if (!_.isEmpty(tableType) && (!_.isEmpty(_.filter(tableType, { property_value: 'programmer_table' })) || !_.isEmpty(_.filter(tableType, { property_value: 'framework_table' }))))
      return;
    let model = {
      file_name: ent.table_name,
      table_name: ent.table_name,
      table_type: [],
      table_groups: [],
      sub_form: '',
      multi_record: '',
      property: [],
      column: [],         // create, update, delete
      op: {}
    };
    model.table_name = model.file_name = ent.table_name;
    // type, key, size, label
    model.column = _.map(ent.table_columns, (col) => {
      let required = !_.isEmpty(_.filter(tableConf, { column_name: col.column_name, column_value: 'required' }));
      let defaultLabel = !_.isEmpty(_.filter(tableConf, { column_name: col.column_name, column_value: 'label_column' }));
      let defaultFilter = !_.isEmpty(_.filter(tableConf, { column_name: col.column_name, column_value: 'filter_column' }));
      let defaultSummary = !_.isEmpty(_.filter(tableConf, { column_name: col.column_name, column_value: 'summary_column' }));
      let mstTbl = _.filter(ent.relation, {relation_type: 'masters', column_name: col.column_name});
      mstTbl = _.isEmpty(mstTbl) ? false : mstTbl[0].table_name;
      if(col.column_key == 'PRI' || defaultLabel)
        defaultFilter = defaultSummary = true;
      return { db: col.db, table: col.table_name, type: col.column_type, column_name: col.column_name, column_size: col.column_size, column_key: col.column_key, column_label: splitCapitalize(col.column_name, ' '), required: required, master_table: mstTbl, default_label: defaultLabel, default_filter: defaultFilter, default_summary: defaultSummary };
    });
    // move filter and session to op
    // model.op.push(detailedReport(entity, entities, appConf));
    model.op['derived'] = derivedOpProps(ent, entities, appConf);
    model.op['master'] =  mastersOpProps(ent, entities, appConf);
    model.table_type.push(..._.map(_.filter(appConf, { table_name: ent.table_name, property_name: 'table_type' }), (ttype) => { return ttype.property_value; }));
    model.sub_form = _.map(_.filter(appConf, { table_name: ent.table_name, property_name: 'sub_form' }), (ttype) => { return ttype.property_value; })[0];
    model.multi_record = _.map(_.filter(appConf, { table_name: ent.table_name, property_name: 'multi_record' }), (ttype) => { return ttype.property_value; })[0];
    model.table_groups.push(..._.map(_.filter(appConf, { table_name: ent.table_name, property_name: 'group_name' }), (ttype) => { return ttype.property_value; }));
    model.property.push(..._.filter(appConf, { table_name: ent.table_name }));
    models.push(model);
  });
  return models;
}

// generic filters summary report, group by, grouping function{?}
// relations, columns, subform, filters

// based on table type, does not depend on UI pattern, apply a separate operation
// default {read, write, update, delete}
// masters summary, masters detailed, masters link summary, masters link detailed, derived summary, derived detailed}
// select string, table_name, joins{to, on, type}, where{filter_field, fields, expression},
// having, grouping
// {select column to group by that column}{?}
function derivedOpProps(entity, entities, appConf) {
  let op = {
    filter: [],
    session: [],      // op_type: {add, filter}, op_column: column_name
    select_ob: [],
    join: [],
    where: [],        // framework and manual
    having: [],       // framework and manual
    grouping: [],     // framework and manual
    active: true
  }
  // masters, link masters
  // table_name, column_name, join_type, link_to
  let entityP = _.filter(entity.table_columns, { column_key: 'PRI' })[0];
  entityP = _.isEmpty(entityP) ? 'not---set' : entityP.column_name;
  let derived = _.filter(entity.relation, { relation_type: 'derived' });
  // Start Derived link masters
  _.forEach(derived, (dr) => {
    // master link
    let drE = _.filter(entities, { table_name: dr.table_name })[0];
    let joinGroup = '';
    let drP = _.filter(drE.table_columns, { column_key: 'PRI' })[0];
    let drPC = _.isEmpty(drP) ? 'not---set' : drP.column_name;
    let linkM = _.filter(appConf, { table_name: drE.table_name, property_name: 'column_type', property_value: 'link_master' })[0];
    let linkMP;
    if (!_.isEmpty(linkM)) {
      let linkC = _.filter(drE.relation, {column_name: linkM.column_name})[0];
      linkM = _.filter(entities, { table_name: linkC.table_name })[0];
      linkMP = _.filter(linkM.table_columns, { column_key: 'PRI' })[0];
      linkMP = _.isEmpty(linkMP) ? 'not---set' : linkMP.column_name;
      joinGroup = linkM.table_name;
      op.join.push({ table_one: linkM.table_name, key_one: linkMP, table_two: drE.table_name, key_two: drPC, join_type: 'left', join_group: joinGroup, active: true, column_type: 'link_master'});
    } else if ((_.isEmpty(_.filter(appConf, { table_name: drE.table_name, property_name: 'table_type', property_value: 'value_table' })) && drE.table_type == 'link_table')) {
      let linkT = _.filter(entities, { table_name: drE.table_name });
      linkTCs = _.reject(linkT.relation, { column_name: entityP.column_name });
      linkTMCs = _.filter(linkMCs, { relation_type: 'masters' });
      if (!_.isEmpty(linkTMCs)) {
        linkM = _.filter(entities, { table_name: linkTMCs[0].table_name })[0];
        linkMP = _.filter(linkM.table_columns, {column_key: 'PRI'});
        linkMP = _.isEmpty(linkMP) ? 'not---set' : linkMP.column_name;
        joinGroup = linkM.table_name;
        op.join.push({ table_one: linkM.table_name, key_one: linkMP, table_two: drE.table_name, key_two: drPC, join_type: 'left', join_group: joinGroup, active: true, column_type: 'connect' });
      }
    }
    op.join.push({ table_one: drE.table_name, key_one: drPC, table_two: entity.table_name, key_two: entityP, join_type: 'left', join_group: joinGroup, active: true });
    // select
    // entity, dr, linkM PICK ONLY THE LABEL COLUMN
    if (_.isEmpty(linkM)) {
      let labels = drE.labels[0];
      if (!_.isEmpty(labels)) {
        op.select_ob.push({ table_name: labels.table_name, column_name: labels.column_name, column_label: labels.column_label, column_op: '', visible: (labels.column_key == 'PRI' ? false : true) });
      }
      op.filter.push({ table_name: dr.table_name, column_name: drPC, active: true });
    } else {
      let labels = linkM.labels[0];
      if (!_.isEmpty(labels)) {
        op.select_ob.push({ table_name: labels.table_name, column_name: labels.column_name, column_label: labels.column_label, column_op: '', visible: (labels.column_key == 'PRI' ? false : true) });
      }
      op.filter.push({ table_name: linkM.table_name, column_name: linkMP, active: true });
    }
  });   // End Link Branching
  op.select_ob.push(..._.map(entity.table_columns, (col) => { return { table_name: col.table_name, column_name: col.column_name, column_label: col.column_label, column_op: '', visible: (col.column_key == 'PRI' ? false : true) } }));
  return op;
}
// join --> { table_one: drE.table_name, key_one: drPC, table_two: entity.table_name, key_two: entityP, join_type: 'left', join_group: joinGroup, active: true }
// filter --> { table_name: dr.table_name, column_name: drPC, active: true }
// session --> op_type: {add, filter}, op_column: column_name
// select --> { table_name: labels.table_name, column_name: labels.column_name, column_label: labels.column_label, column_op: '', visible: (labels.column_key == 'PRI' ? false : true)
function mastersOpProps(entity, entities, appConf) {
  let op = {
    filter: [],
    session: [],
    select_ob: [],
    join: [],
    where: [],
    having: [],
    grouping: []
  }
  // sub_form, multi_record
  let entityP = _.filter(entity.table_columns, { column_key: 'PRI' })[0];
  entityP = _.isEmpty(entityP) ? 'not---set' : entityP.column_name;
  let masters = _.filter(entity.relation, { relation_type: 'masters' });
  _.forEach(masters, (master) => {
    master = _.filter(entities, { table_name: master.table_name })[0];
    let mastPCol = _.filter(master.table_columns, { column_key: 'PRI' })[0];
    let mastPKey = _.isEmpty(mastPCol) ? 'not---set' : mastPCol.column_name;
    op.join.push({ table_one: master.table_name, key_one: mastPKey, table_two: entity.table_name, key_two: entityP, join_type: 'left', join_group: '', active: true });
    op.filter.push({ table_name: master.table_name, column_name: mastPKey, active: true });
    let label = '';
    if (!_.isEmpty(master.labels))
      label = master.labels[0];
    if (!_.isEmpty(label)) {
      op.select_ob.push({ table_name: label.table_name, column_name: label.column_name, column_label: label.column_label, column_op: '', visible: true });
    }
  });
  op.select_ob.push(..._.map(entity.table_columns, (col) => { return { table_name: col.table_name, column_name: col.column_name, column_label: col.column_label, column_op: '', visible: (col.column_key == 'PRI' ? false : true) } }));
  return op;
}