let _ = require('lodash');
let { readScaffold } = require('../scaff_ops/read_scaffold');
let { getThemeOps } = require('./themes_map');

exports.ciScaffold = function (commandObj, callback) {
  // commandObj properties{app_name, theme}
  let appName = '';
  _.forEach(commandObj.properties, (prop) => {
    if (prop.property_name == 'app_name')
      appName = prop.property_value[0];
    if (prop.property_name == 'theme')
      theme = prop.property_value[0];
  });
  if (_.isEmpty(appName)) {
    console.log('Please set app_name property!');
    callback();
    return;
  }
  // read files into an array
  readScaffold(appName, (err, entities) => {
    if (_.isEmpty(entities)) {
      console.log('Application ' + appName + ' not found!');
      callback();
      return;
    }
    // require theme here
    if(_.isEmpty(theme)){
      console.log('Theme not set! use theme-> property.')
      callback();
      return;
    }
    let themeMap = _.filter(getThemeOps(), {theme_name: theme})[0];
    if(_.isEmpty(themeMap)){
      console.log('Theme ' + theme + ' not found!');
      callback();
      return;
    }
    let themeMain = require(themeMap.theme_main);
    themeMain[themeMap.op_method](entities, callback);
  });
}