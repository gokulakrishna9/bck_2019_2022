// row element and column element are functions
exports.writeGrid = function(rowEl, colEl, rowSize, colSize, gridElement) {
  
}