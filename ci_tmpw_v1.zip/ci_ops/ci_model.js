let _ = require('lodash');
let { tabSpaces } = require('../helper_functions/string_function');
// HAVE ABILITY TO ACT ON COLUMNS, APPLYING DATE, FORMATTING etc...
let methodOpening = _.template(`<%= outer_tab %>function <%=method_name%>(<%=param_list%>) {`);
let methodClosing = _.template(`<%= outer_tab %>}`);
let phpVariable = _.template(`<%= inner_tab %>$<%= variable_name %>`);
let expVariable = _.template(`<%= inner_tab %>$<%=variable_name%> = <%= experssion %>`);
let arrayDeclaration = _.template(`<%= inner_tab %>$<%= array_name %> = [];`);
let sessionDataArray = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = $this->session->has_userdata('<%= key_name %>') ? $this->session->userdata('<%= key_name %>') : '';`);
let postTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = is_null($this->input->post('<%= value_variable %>')) ? '' : $this->input->post('<%= value_variable %>');`);
let postSessTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = is_null($this->input->post('<%= value_variable %>')) ? $<%= array_name %>['<%= column_name %>'] : $this->input->post('<%= value_variable %>');`);
let getTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = is_null($this->input->get('<%= value_variable %>')) ? '' : $this->input->get('<%= value_variable %>');`);
let insertTmpl = _.template(`<%= inner_tab %>$this->db->insert('<%= table_name %>', $<%= data_array_name %>);`);
let returnInsertTmpl = _.template(`<%= inner_tab %>return array('insert_id' => $this->db->insert_id(), 'input_data' => $<%= array_name %>, success => true);`);
let returnUpdateTmpl = _.template(`<%= inner_tab %>return array('affected_rows' => $this->db->affected_rows(), 'input_data' => $<%= array_name %>, success => true);`);
let returnDefault = _.template(`<%= inner_tab %>return array('success' => true);`);
let postPrimaryKey = _.template(`<%= inner_tab %>if(is_null($this->input->post('<%= value_variable %>')))`);
let returnTransFailed = _.template(`<%= inner_tab %>return {'insert_id' => '', 'input_data' => $<%= array_name %>, success => false};`);
let fieldOpTmpl = _.template(`<%= inner_tab %>$<%= array_name %>[<%= column_name %>] = <%= op_name %>($<%= column_name %>);`)
let arrayTmpl = _.template(`<%= inner_tab %>$<%= array_name %> = array(<%= array_elements %>);`);
let arrAsnStmt = _.template(`<%= inner_tab %>$<%= array_name %>['<%= key_name %>'] = <%= value_element %>;`);
let arrayElemTmpl = _.template(`<%= inner_tab %>'<%= column_name %>' => $<%= value_variable %>`);
let assignParamInptTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = $<%= value_variable %>;`);
let sessInptTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = $this->session-><%= value_variable %>;`);
let sessMstTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = $this->session->has_userdata('<%= property_name %>') ? $this->session->userdata('<%= property_name %>') : $<%= array_name %>['<%= column_name %>'];`);
let sessWhereTmpl = _.template(`<%= inner_tab %>$this->db->where('<%= table_name %>.<%= column_name %>', $this->session->userdata('<%= property_name %>'));`);
let setSessTmpl = _.template(`<%= inner_tab %>$this->session->set_userdata('<%= column_name %>', $<%= array_name %>['<%= column_name %>']);`);
let getPostTmpl = _.template(`$this->input->get_post('<%= value_variable %>')`);
let setSessValueTmpl = _.template(`<%= inner_tab %>$this->session->set_userdata('<%= column_name %>', <%= value_name %>);`);
let selectTmpl = _.template(`<%= inner_tab %>$this->db->select('<%= columns_list %>')->from('<%= table_name %>');`);
let selectColTmpl = _.template(`<%=table_name%>.<%=column_name%> AS <%=column_label%>`)
let joinTmpl = _.template(`<%= inner_tab %>$this->db->join('<%= table_one %>', '<%= table_one %>.<%= key_one %> = <%= table_two %>.<%= key_two %>', '<%= join_type %>');`);
let getResultTmpl = _.template(`<%= inner_tab %>$qry = $this->db->get();`);
let resultTmpl = _.template(`<%= inner_tab %>return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`);
let updateTmpl = _.template(`<%= inner_tab %>$this->db->update('<%= table_name %>', $<%= data_array_name %>, array(<%= filter_elements %>));`);
let checkInputTmpl = _.template(`<%= inner_tab %>if($this->input->get_post('<%= column_name %>'))`);
let whereTmpl = _.template(`<%= inner_tab %>$this->db->where('<%= table_name %>.<%= column_name %>', $<%= field_value_variable %>);`);
let whereArrTmpl = _.template(`<%= inner_tab %>$this->db->where($<%= filter_array %>);`);
let deleteTmpl = _.template(`<%= inner_tab %>$this->db->delete('<%= table_name %>', $<%= filter_array %>);`);
let groupByTmpl = _.template(`<%= inner_tab %>$this->db->group_by($<%= table_name_column_name %>);`);
let orderByTmpl = _.template(`<%= inner_tab %>$this->db->order_by('<%= table_name_column_name %>', '<%= sorting %>');`);
// The HAVING clause is often used with the GROUP BY clause to filter groups based on a specified condition. 
// If the GROUP BY clause is omitted, the HAVING clause behaves like the WHERE clause.
let havingTmpl = _.template(`<%= inner_tab %>$this->db->having('<%= table_name_column_name %>');`);
let returnStat = _.template(`<%= inner_tab %>return $rslt;`);
let modelOpeningTmpl = _.template(`<?php class <%= table_name %>_model extends CI_Model {`);
let modelClosingTmpl = _.template(`}`);
// date format template
let dateModTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = empty($<%= array_name %>['<%= column_name %>']) ? date("Y-m-d") : date("Y-m-d", strtotime($<%= array_name %>['<%= column_name %>']));`);
// time format template
let timeModTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = empty($<%= array_name %>['<%= column_name %>']) ? '23:59' : date("H:i", strtotime($<%= array_name %>['<%= column_name %>']));`);
// datetime format template
let datetimeModTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = empty($<%= array_name %>['<%= column_name %>']) ? '23:59' : date("Y-m-d H:i", strtotime($<%= array_name %>['<%= column_name %>']));`);
let phpTimeTmpl = _.template(`<%= inner_tab %>$tme = time();`);
// ACL
let currentTmeTmpl = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = date("Y-m-d H:i:s", $tme);`);
// CURRENT USER
let currentUser = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>'] = $this->session->has_userdata('<%= key_name %>') ? $this->session->userdata('<%= key_name %>') : '';`);
let getArrayElem = _.template(`<%= inner_tab %>$<%= array_name %>['<%= column_name %>']`);

//FROM NOW YOU SHOULD THINK IN TERMS OF WIRING DataStructures AND FUNCTIONS, on the basic model apply operators to BUILD THE WIRE, datastructures built from user input

// create, read, update, delete
// column props{ "db": "coders_tribe", "table": "ct_student", "type": "int", "column_name": "ct_student_id", "column_key": "PRI", "required": false, "master_table" }
let innerTab = 4;
let outerTab = 2;
exports.writeCIModel = function (defAppModel) {
  let model = [];
  _.forEach(defAppModel, (modelDef) => {
    // call DS methods here
    let md = { file_name: modelDef.table_name + '_' + 'Model', file_contents: '' };
    let file = [];
    file.push(modelOpeningTmpl({ table_name: modelDef.table_name }));
    file.push(...writeCreateMethod(modelDef));
    file.push(...writeUpdateMethod(modelDef));
    file.push(...writeDeleteMethod(modelDef));
    file.push(...writeReadMethod(modelDef));

    file.push(modelClosingTmpl({}));
    md.file_contents = _.join(file, '\n');
    model.push(md);
  });
  return model;
}

let globalProp = {
  add_record: {
    method_name: 'add_record',
    data_array: 'add_data',
    acl: { user_id_col: 'gcda_user_id' }
  },
  update_record: {
    method_name: 'update_record',
    data_array: 'update_data',
    filter_array: 'update_filter',
    acl: { user_id_col: 'gcda_user_id' }
  },
  delete_record: {
    filter_array: 'delete_filter',
    method_name: 'delete_record'
  },
  read_record: {
    method_name: 'get_record',
    filter_array: 'apply_filter'
  }
}

function aclStmts(operator) {
  if (operator == 'add_record') {
    return [currentUser({ inner_tab: tabSpaces(4), array_name: globalProp[operator].data_array, column_name: globalProp[operator].acl.user_id_col, key_name: globalProp[operator].acl.user_id_col })];
  } else if (operator == 'update_record') {
    return [currentUser({ inner_tab: tabSpaces(4), array_name: globalProp[operator].data_array, column_name: globalProp[operator].acl.user_id_col, key_name: globalProp[operator].acl.user_id_col })];
  } else if (operator == 'delete') {

  } else if (operator == 'logging') {

  }
  return [];
}
// Session reset|add to session, missing in writeCreateMethod
function writeCreateMethod(modelDef) {
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: globalProp.add_record.method_name, param_list: ' ' }));
  // create data array
  stmts.push(arrayDeclaration({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array }));
  // if sub-form get parent element column from session, has table name, get the column name with that as masters
  if (!_.isEmpty(modelDef.sub_form)) {
    // console.log(modelDef.sub_form);
    let mTC = _.filter(modelDef.column, { master_table: modelDef.sub_form });
    mTC = _.isEmpty(mTC) ? { column_name: 'not---set' } : mTC[0];
    stmts.push(sessMstTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: mTC.column_name, property_name: mTC.column_name }));
    stmts.push(postSessTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: mTC.column_name, value_variable: mTC.column_name }));
    let setSessTmpl = _.template(`<%= inner_tab %>$this->session->set_userdata('<%= column_name %>', $<%= array_name %>['<%= column_name %>']);`);
    stmts.push(setSessTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: mTC.column_name }));
    modelDef.column = _.reject(modelDef.column, { master_table: modelDef.sub_form });
  }
  _.forEach(modelDef.column, (col) => {
    // post column values, post-template()
    stmts.push(postTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
    if (col.type == 'datetime' || col.type == 'date' || col.type == 'time' || col.type == 'timestamp') {
      if (col.type == 'datetime' || col.type == 'timestamp') {
        stmts.push(datetimeModTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
      } else if (col.type == 'date') {
        stmts.push(dateModTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
      } else if (col.type == 'time') {
        stmts.push(timeModTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
      }
    }
  });
  stmts.push(...aclStmts('add_record'));
  // write insert
  stmts.push(insertTmpl({ inner_tab: tabSpaces(innerTab), data_array_name: globalProp.add_record.data_array, table_name: modelDef.table_name }));
  // return insert id
  stmts.push(returnInsertTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.add_record.data_array }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}

function writeUpdateMethod(modelDef) {
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: globalProp.update_record.method_name, param_list: ' ' }));
  // create data array
  stmts.push(arrayDeclaration({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array }));
  // if sub-form get parent element column from session, has table name, get the column name with that as masters
  if (!_.isEmpty(modelDef.sub_form)) {
    // console.log(modelDef.sub_form);
    let mTC = _.filter(modelDef.column, { master_table: modelDef.sub_form });
    mTC = _.isEmpty(mTC) ? { column_name: 'not---set' } : mTC[0];
    stmts.push(sessMstTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: mTC.column_name, property_name: modelDef.table_name + '_' + mTC.column_name }));
    stmts.push(postSessTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: mTC.column_name, value_variable: mTC.column_name }));
    stmts.push(setSessTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: mTC.column_name }));
    modelDef.column = _.reject(modelDef.column, { master_table: modelDef.sub_form });
  }
  _.forEach(modelDef.column, (col) => {
    // post column values, post-template()
    stmts.push(postTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
    if (col.type == 'datetime' || col.type == 'date' || col.type == 'time' || col.type == 'timestamp') {
      if (col.type == 'datetime' || col.type == 'timestamp') {
        stmts.push(datetimeModTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
      } else if (col.type == 'date') {
        stmts.push(dateModTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
      } else if (col.type == 'time') {
        stmts.push(timeModTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array, column_name: col.column_name, value_variable: col.column_name }));
      }
    }
  });
  stmts.push(...aclStmts('update_record'));
  // update filters{primary key} -- filter for primary key, set to not set
  // find set array elements, set array
  let pKey = _.filter(modelDef.column, { column_key: 'PRI' });
  pKey = _.isEmpty(pKey) ? 'not---set' : pKey[0].column_name;
  stmts.push(arrayDeclaration({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.filter_array }));
  stmts.push(arrAsnStmt({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.filter_array, key_name: pKey, value_element: getArrayElem({ inner_tab: tabSpaces(1), array_name: globalProp.update_record.data_array, column_name: pKey }) }));
  // write update
  let updateTmpl = _.template(`<%= inner_tab %>$this->db->update('<%= table_name %>', $<%= data_array_name %>, $<%= filter_elements %>);`);
  stmts.push(updateTmpl({ inner_tab: tabSpaces(innerTab), table_name: modelDef.table_name, data_array_name: globalProp.update_record.data_array, filter_elements: globalProp.update_record.filter_array }));
  // return insert id
  stmts.push(returnUpdateTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.update_record.data_array }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}

function writeDeleteMethod(modelDef) {
  // get primary key from post delete record
  let stmts = [];
  let pKey = _.filter(modelDef.column, { column_key: 'PRI' });
  pKey = _.isEmpty(pKey) ? 'not---set' : pKey[0].column_name;
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: globalProp.delete_record.method_name, param_list: ' ' }));
  // create filter array
  stmts.push(arrayDeclaration({ inner_tab: tabSpaces(innerTab), array_name: globalProp.delete_record.filter_array }));
  stmts.push(postTmpl({ inner_tab: tabSpaces(innerTab), array_name: globalProp.delete_record.filter_array, column_name: pKey, value_variable: pKey }));
  stmts.push(deleteTmpl({ inner_tab: tabSpaces(innerTab), table_name: modelDef.table_name, filter_array: globalProp.delete_record.filter_array }));
  stmts.push(returnDefault({ inner_tab: tabSpaces(innerTab) }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}
// select, join, where, return, get_post
let selectSize = 5;
function writeReadMethod(modelDef) {
  // get all columns, and masters columns, build select build joins
  // table_columns, default_filter, master table
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: globalProp.read_record.method_name, param_list: ' ' }));
  stmts.push(arrayDeclaration({ inner_tab: tabSpaces(innerTab), array_name: globalProp.read_record.filter_array }));
  if (!_.isEmpty(modelDef.sub_form)) {
    // console.log(modelDef.sub_form);
    let mTC = _.filter(modelDef.column, { master_table: modelDef.sub_form });
    mTC = _.isEmpty(mTC) ? { column_name: 'not---set', table_name: 'not---set' } : mTC[0];
    // check post set session, apply where on session
    stmts.push(checkInputTmpl({ inner_tab: tabSpaces(innerTab), column_name: mTC.column_name }));
    stmts.push(setSessValueTmpl({ inner_tab: tabSpaces(innerTab + 2), column_name: mTC.column_name, value_name: getPostTmpl({ value_variable: mTC.column_name }) }));
    stmts.push(sessWhereTmpl({inner_tab: tabSpaces(innerTab), table_name: mTC.table_name, column_name: mTC.table_name, property_name: mTC.table_name}));
    modelDef.op.master.filter = _.reject(modelDef.op.master.filter, { table_name: modelDef.sub_form });
  } // sub form filters done
  _.forEach(modelDef.op.master.filter, (filter) => {
    stmts.push(checkInputTmpl({ inner_tab: tabSpaces(innerTab), column_name: filter.column_name }));
    stmts.push(whereTmpl({ inner_tab: tabSpaces(innerTab + 2), table_name: filter.table_name, column_name: filter.column_name, field_value_variable: filter.column_name }));
  });
  let selectAr = [];
  selectAr.push(..._.map(modelDef.op.master.select_ob, (col) => {
    return selectColTmpl({ table_name: col.table_name, column_name: col.column_name, column_label: col.column_name });
  }));
  let selectStr = "";
  let i = 1;
  _.forEach(selectAr, (str) => {
    if (i / selectSize == 0)
      selectStr += '\n' + tabSpaces(6);
    selectStr += str + ', ';
    i++;
  });
  selectStr = _.trim(selectStr, ', ');
  stmts.push(selectTmpl({ inner_tab: tabSpaces(innerTab), columns_list: selectStr, table_name: modelDef.table_name }));
  _.forEach(modelDef.op.master.join, (jn) => {
    stmts.push(joinTmpl({ inner_tab: tabSpaces(innerTab), table_one: jn.table_one, table_two: jn.table_two, key_one: jn.key_one, key_two: jn.key_two, join_type: jn.join_type }));
  });
  stmts.push(resultTmpl({ inner_tab: tabSpaces(innerTab), filter_array: globalProp.read_record.filter_array }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}

/*
let checkInputTmpl = _.template(`<%= inner_tab %>if($this->input->get('<%= column_name %>'))`);
let whereTmpl = _.template(`<%= inner_tab %>$this->db->where('<%= table_name %>.<%= column_name %>', $<%= field_value_variable %>);`);

let whereArrTmpl = _.template(`<%= inner_tab %>$this->db->where($<%= filter_array %>);`);
let getResultTmpl = _.template(`<%= inner_tab %>$qry = $this->db->get();`);
let resultTmpl = _.template(`<%= inner_tab %>return array('result' => $qry->result(), 'filter_array' => $<%= filter_array %>);`);
*/

function writeCreateMethodMultiRecord(modelDef) {

}

// detailed report{entity ds}

// summary report{entity ds}