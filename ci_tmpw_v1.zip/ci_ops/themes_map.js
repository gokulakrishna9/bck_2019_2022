exports.getThemeOps = function () {
  return [
    {
      theme_name: 'default',
      theme_main: './default_theme/df_main',
      op_method: 'dfMain'
    }
  ]
}