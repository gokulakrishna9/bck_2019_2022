// read scaffolding files
// get the input fields assign corresponding values
let _ = require('lodash');
let { findCaseInsensitiveSubString } = require('../helper_functions/string_function');
// AVOID NESTING, easy to query
exports.viewDefault = function (modelDef) {
  // col.type, col.table_columns
  let views = []
  _.forEach(modelDef, (mdlDef) => {
    let viewDefault = {
      grid_component: {},
      file_name: mdlDef.table_name,
      table_name: mdlDef.table_name,
      db_name: '',
      primary_column: '',
      form_parent: '',
      form: {},
      filter: {},
      table: {},            // op_name, table
      parent_record: {},
      page_ops: {},
      acl_op: {}            // truthyness
    }
    viewDefault.form['default'] = formScaffold(mdlDef, modelDef);
    viewDefault.filter['default'] = filter(mdlDef, modelDef);
    viewDefault.table['default'] = table(mdlDef);
    viewDefault.parent_record['default'] = parentRecord(mdlDef, modelDef);
    views.push(viewDefault);
  });
  return views;
}

function formScaffold(mdlDef, modelDef) {
  let form = {
    component: {},
    form_property: [],    // property_name, property_value
    grid_row_class: [], grid_column_class: [],
    form_element: [],
    acl_op: []            // truthyness
  };
  _.forEach(mdlDef.column, (col, sort) => {
    if (col.master_table == mdlDef.sub_form)
      return;
    let formElement = {
      label: col.column_label, column_name: col.column_name,
      column_size: col.column_size, html_element: '',
      validation_message: '', js_event: [],
      js_op: [], php_op: [],
      js_component: [], sort_order: sort, 
      label_property: [{property_name: 'class', property_value: ''}, {property_name: 'for', property_value: col.column_name}],
      property: {
        html: [{ property_name: 'id', property_value: col.column_name }]
      },
      value: {
        table_name: '',
        value_column: '',
        label_column: ''
      },
      acl_op: [],            // truthyness
      active: true
    };
    let mstr = _.filter(mdlDef.op.master.select_ob, { table_name: col.master_table });
    // check primary
    if (col.column_key == 'PRI') {
      formElement.property.html.push({ type: 'hidden' });
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'number' });
      form.primary_column = col.column_name;
      form.db_name = col.db;
      form.form_parent = col.master_table;
    } else if (!_.isEmpty(mstr)) {        // check column in masters
      // Check for multi record
      formElement.html_element = 'select';
      let tbl = _.filter(modelDef, { table_name: mstr[0].table_name })[0];
      let mPKey = _.filter(tbl.column, { column_key: "PRI" })[0];
      formElement.value.table_name = tbl.table_name;
      formElement.value.value_column = !_.isEmpty(mPKey) ? mPKey.column_name : 'not---set';
      let label = _.filter(tbl.property, { property_name: 'column_type', property_value: 'label_column' });
      formElement.value.label_column = !_.isEmpty(label) ? label[0].column_name : 'not---set';
    } else if (findCaseInsensitiveSubString('varchar', col.type) && col.column_size <= 70) {
      // text -> varchar <= 70 chars, number -> number, textarea -> varchar > 70, date -> date
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'text' });
    } else if (findCaseInsensitiveSubString('varchar', col.type) || findCaseInsensitiveSubString('varchar', col.type) && col.column_size > 70) {
      formElement.html_element = 'textarea';
    } else if (findCaseInsensitiveSubString('int', col.type) || findCaseInsensitiveSubString('float', col.type)
      || findCaseInsensitiveSubString('decimal', col.type) || findCaseInsensitiveSubString('real', col.type)
      || findCaseInsensitiveSubString('double', col.type) && col.column_size > 70) {
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'number' });
    } else if (findCaseInsensitiveSubString('datetime', col.type) || findCaseInsensitiveSubString('timestamp', col.type)) {
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'datetime-local' });
    } else if (findCaseInsensitiveSubString('date', col.type)) {
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'date' });
    } else if (findCaseInsensitiveSubString('time', col.type)) {
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'time' });
    } else if (findCaseInsensitiveSubString('year', col.type)) {
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'month' });
    } else if (findCaseInsensitiveSubString('boolean', col.type)) {   // radio -> boolean
      formElement.html_element = 'input';
      formElement.property.html.push({ type: 'radio' });
    }
    form.form_element.push(formElement);
  });
  return form;
}

function filter(mdlDef, modelDef) {
  let filter = {
    component: {},
    filter_property: [],
    grid_row_class: [], grid_column_class: [],
    filter_element: [],
    acl_op: []            // truthyness
  };
  _.forEach(mdlDef.column, (col, sort) => {
    if (col.master_table == mdlDef.sub_form)
      return;
    let filterElement = {
      label: col.column_label, column_name: col.column_name,
      column_size: col.column_size, html_element: '',
      validation_message: '', js_event: [],
      js_op: [], php_op: [],
      js_component: '', sort_order: sort, 
      label_property: [{property_name: 'class', property_value: ''}, {property_name: 'for', property_value: col.column_name}],
      property: {
        html: [{ property_name: 'id', property_value: col.column_name }]
      },
      /*  type: '', style: '', visible_class: '', error_class: '',
        id: col.column_name, required: '', misc_attrs: '' */
      value: {
        table_name: '',
        value_column: '',
        label_column: ''
      },
      acl_op: [],            // truthyness
      active: true
    };
    let mstr = _.filter(mdlDef.op.master.select_ob, { table_name: col.master_table });
    if (!_.isEmpty(mstr)) {        // check column in masters
      // Check for multi record
      filterElement.html_element = 'select';
      let tbl = _.filter(modelDef, { table_name: mstr[0].table_name })[0];
      let mPKey = _.filter(tbl.column, { column_key: "PRI" })[0];
      filterElement.value.table_name = tbl.table_name;
      filterElement.value.value_column = !_.isEmpty(mPKey) ? mPKey.column_name : 'not---set';
      let label = _.filter(tbl.property, { property_name: 'column_type', property_value: 'label_column' });
      filterElement.value.label_column = !_.isEmpty(label) ? label[0].column_name : 'not---set';
    } else if (findCaseInsensitiveSubString('varchar', col.type) && col.column_size <= 70) {
      // text -> varchar <= 70 chars, number -> number, textarea -> varchar > 70, date -> date
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'text' });
    } else if (findCaseInsensitiveSubString('varchar', col.type) || findCaseInsensitiveSubString('varchar', col.type) && col.column_size > 70) {
      filterElement.html_element = 'textarea';
    } else if (findCaseInsensitiveSubString('int', col.type) || findCaseInsensitiveSubString('float', col.type)
      || findCaseInsensitiveSubString('decimal', col.type) || findCaseInsensitiveSubString('real', col.type)
      || findCaseInsensitiveSubString('double', col.type) && col.column_size > 70) {
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'number' });
    } else if (findCaseInsensitiveSubString('datetime', col.type) || findCaseInsensitiveSubString('timestamp', col.type)) {
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'datetime-local' });
    } else if (findCaseInsensitiveSubString('date', col.type)) {
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'date' });
    } else if (findCaseInsensitiveSubString('time', col.type)) {
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'time' });
    } else if (findCaseInsensitiveSubString('year', col.type)) {
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'month' });
    } else if (findCaseInsensitiveSubString('boolean', col.type)) {   // radio -> boolean
      filterElement.html_element = 'input';
      filterElement.property.html.push({ type: 'radio' });
    }
    filter.filter_element.push(filterElement);
  });
  return filter;
}

function table(mdlDef) {
  let table = {
    component: {},
    table_property: [],
    header_property: [],
    row_property: [],
    table_element: [],                      // header, value_key, sort-order
    element_property: [],
    acl_op: []                              // truthyness
  };
  _.forEach(mdlDef.op.master.select_ob, (slObj, sort) => {
    table.table_element.push({ header: slObj.column_label, value_key: slObj.column_name, property_name: '', property_value: '', sort_order: sort });
    table.element_property.push({value_key: slObj.column_name, property_name: '', property_value: ''});
  });
  return table;
}

function parentRecord(mdlDef, modelDef) {
  let parent = {
    component: {},
    grid_row_class: [], grid_column_class: [],
    parent_property: [],
    parent_element: [],                     // header, value_key, sort-order
    element_property: [],
    acl_op: []                              // truthyness
  };
  // get sub form value, find parent, populate parent columns, getting masters labels
  if (_.isEmpty(mdlDef.sub_form))
    return false;
  let pTbl = _.filter(modelDef, { table_name: mdlDef.sub_form })[0];
  _.forEach(pTbl.op.master.select_ob, (slObj, sort) => {
    parent.parent_element.push({ header: slObj.column_label, value_key: slObj.column_name, sort_order: sort });
    parent.element_property.push({value_key: slObj.column_name, property_name: '', property_value: ''});
  });
  return parent;
}