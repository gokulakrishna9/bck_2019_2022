let _ = require('lodash');
// group_name: [{group_name: '', type: '', table_name: table_name, sort_order: root_zero, label:, active}]
// table with no masters and derived, goto each derived check if it is a subform
// table with grouping property set group_name: [{table_name: table_name, sort_order: root_zero, label:}]
exports.routingDef = function (modelArr) {
  // table_name: ent.table_name, table_type: []
  let appDefinition = {
    route: {},
    sub_form: [],       // parent to child
    page: []
  };
  let j = 0;
  _.forEach(modelArr, (model) => {
    let i = 0;
    if (_.isEmpty(model.op.master.join)) {
      if (!_.has(appDefinition.route, model.table_name))
        appDefinition.route[model.table_name] = [];
      appDefinition.route[model.table_name].push({ table_name: model.table_name, sort_order: i, group_head: false, label: model.table_name, type: 'default', active: true });
      i++;
      _.forEach(model.op.derived.join, (jn) => {
        let tder = _.filter(modelArr, { table_name: jn.table_one })[0];
        if (!_.isEmpty(tder) && _.isEmpty(tder.sub_form)) {
          appDefinition.route[model.table_name].push({ table_name: jn.table_one, sort_order: i, group_head: false, label: jn.table_one, type: 'default', active: true });
        } 
        if (!_.isEmpty(tder) && !_.isEmpty(tder.sub_form)) {
          if(tder.sub_form == model.table_name)
            appDefinition.sub_form.push({[model.table_name]: tder.table_name});  
        }
      });
    } else if (!_.isEmpty(model.op.table_groups)) {
      _.forEach(model.op.table_groups, (grp) => {
        if (!_.has(appDefinition.route, grp))
          appDefinition.route[grp] = [];
        appDefinition.route[grp].push({ table_name: model.table_name, sort_order: i, group_head: false, label: model.table_name, type: 'labeled', active: true });
        j++;
      });
    }
  });

  // build appDefinition.route array then work on page
  _.forEach(modelArr, (model) => {
    let page = {
      file_name: model.table_name,
      route_controller: model.table_name,                          // app_name + table_name
      table_type: model.table_type,                                // based on the config props{sub_form, multi_record}
      table_group: model.table_group,                              // header under which it will appear
      table_name: model.table_name,
      sub_form: model.sub_form,
      multi_record: model.multi_record,
      group_root: '',
      component: [
        {
          component_name: '',
          acl: { acl_op: 'default', active: true },
          active: false
        },
        {
          component_name: 'form_def',
          acl: { acl_op: 'default', active: true },
          active: true
        },
        {
          component_name: 'filter_def',
          acl: { acl_op: 'default', active: true },
          active: true
        },
        {
          component_name: 'pagination_def',
          acl: { acl_op: 'default', active: true },
          active: true
        },
        {
          component_name: 'table_def',
          acl: { acl_op: 'default', active: true },
          active: true
        },
      ]
    };
    appDefinition.page.push(page);
  });
  return appDefinition;
}