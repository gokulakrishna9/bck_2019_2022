let _ = require('lodash');
// operators have to check for existence of properties if not assign default
exports.applyTheme = function (viewScaff, themeProp, operators) {
  // apply default transforms
  applyFormProp(viewScaff, themeProp);
  applyElementProp(viewScaff, themeProp);
  applyFilterProp(viewScaff, themeProp);
  applyFilterElementProp(viewScaff, themeProp);
  applyPagination(viewScaff, themeProp);
  applyTable(viewScaff, themeProp);
  applyParentGrid(viewScaff, themeProp);
  // apply new operators
  _.forEach(viewScaff, (scaff) => {
    console.log(scaff.form[themeProp.theme_name].grid_row_class);
    console.log(scaff.form[themeProp.theme_name].form_element[0].label_property);
    console.log(scaff.form[themeProp.theme_name].form_element[0].property);
  });
}

// define a grid element as well
function applyFormProp(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    vw.form[themeProp.theme_name].grid_row_class.push({ property_name: 'class', property_value: themeProp.form_grid.class.row });
    vw.form[themeProp.theme_name].grid_column_class.push({ property_name: 'class', property_value: themeProp.form_grid.class.col({ small_col: '12', md_col: '4', lg_col: '4' }) });
  });
}

function applyElementProp(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    _.forEach(vw.form[themeProp.theme_name].form_element, (ele) => {
      // pass property each of the element types avoid if's, 
      // if's only in atomic functions
      ele.label_property.push({ property_name: 'class', property_value: themeProp.form_element.class.label });
      selectProp(ele, themeProp);
      inputProp(ele, themeProp);
    });
  });
}

function applyFilterProp(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    vw.filter[themeProp.theme_name].grid_row_class.push({ property_name: 'class', property_value: themeProp.form_grid.class.row });
    vw.filter[themeProp.theme_name].grid_column_class.push({ property_name: 'class', property_value: themeProp.form_grid.class.col({ small_col: '12', md_col: '4', lg_col: '4' }) });
  });
}

function applyFilterElementProp(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    _.forEach(vw.filter[themeProp.theme_name].form_element, (ele) => {
      // pass property each of the element types avoid if's, 
      // if's only in atomic functions
      ele.label_property.push({ property_name: 'class', property_value: themeProp.form_element.class.label });
      selectProp(ele, themeProp);
      inputProp(ele, themeProp);
    });
  });
}

function inputProp(ele, themeProp) {
  // property
  if (ele.html_element != 'input')
    return;
  let type = _.filter(ele.property, { property_name: 'type' });
  if (_.isEmpty(type))
    return;
  ele.property.html.push({ property_name: 'class', property_value: themeProp.form_element.class[type[type.length - 1]] });
}

function selectProp(ele, themeProp) {
  if (ele.html_element != 'select')
    return;
  ele.property.html.push({ property_name: 'class', property_value: themeProp.form_element.class.select });
}

function applyPagination(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    vw['pagination'] = {container: [], next_page_op_property: []};
    vw.pagination.container.push(...themeProp.pagination.container_property);
    vw.pagination.next_page_op_property.push(...themeProp.pagination.next_page_op_property);
  });
}

function applyTable(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    vw.table[themeProp.theme_name].table_property.push(...themeProp.table.table);
    vw.table[themeProp.theme_name].table_property.push(...themeProp.table.thead);
  });
}

function applyParentGrid(viewScaff, themeProp) {
  _.forEach(viewScaff, (vw) => {
    if(_.isEmpty(vw.parent_record[themeProp.theme_name]))
      return;
    vw.parent_record[themeProp.theme_name].grid_row_class.push(themeProp.parent_grid.row);
    vw.parent_record[themeProp.theme_name].grid_column_class.push(themeProp.parent_grid.col({small_col: 12, md_col: 6, lg_col: 4}));
    vw.parent_record[themeProp.theme_name]['label_property'] = [];
    vw.parent_record[themeProp.theme_name]['label_property'].push(...themeProp.parent_grid.label);
    vw.parent_record[themeProp.theme_name]['paragraph_property'] = [];
    vw.parent_record[themeProp.theme_name]['paragraph_property'].push(...themeProp.parent_grid.paragraph);
  })
}