let _ = require('lodash');
let { readScaffold } = require('../scaff_ops/read_scaffold');
let { getThemeOps } = require('./themes_map');

exports.ciMain = function (commandObj, callback) {
  // commandObj properties{app_name, theme}
  let appName = '';
  let theme = '';
  _.forEach(commandObj.properties, (prop) => {
    if (prop.property_name == 'app_name')
      appName = prop.property_value[0];
    if (prop.property_name == 'theme')
      theme = prop.property_value[0];
  });
  console.log(appName);
  console.log(theme);
  // read files into an array
  readScaffold(appName, (err, entities) => {
    if (_.isEmpty(entities)) {
      console.log('Application ' + appName + ' not found!');
      callback();
      return;
    }
  });
  // write view components{acl{no access, view, update, add}, form, filter, pagination, table}
  // write controller {acl, validation, get page data, build page layout}
  // write model {filters, sessions, CRUD, reports, transactions, multi-form, multi-value}
}