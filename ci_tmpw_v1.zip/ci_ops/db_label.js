// pull out column comments and make them properties
// write config file along with default theme
let _ = require('lodash');
exports.dbLabel = function (entities) {
  // !?-- Strange why is config becomming array of arrays -!?
  let config = [];  // table_name, column_name, property_name, property_value
  _.forEach(entities, (entity) => {
    _.forEach(entity.table_columns, (col) => {
      let prop_val = _.split(col.column_comment, ';');  
      _.forEach(prop_val, (pv) => {           // acting like _.map
        if(_.isEmpty(pv))
          return;
        let props = _.split(pv, '-');
        config.push({ column_name: col.column_name, table_name: col.table_name, property_name: props[0], property_value: props[1] });
      });
    });
  });
  config = _.flatten(config, 1);
  return config;
  // {server_admin, config_master, programmer, value_table, link_master, multi_record, sub_form, acl_table, global_config_fields}
  // search column comments for table_label
}