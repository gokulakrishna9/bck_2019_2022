// state method
// authentication method
// authorization method
// validation method
// table_name_create, table_name_update, table_name_delete, table_name_get_records
let _ = require('lodash');
let { tabSpaces } = require('../helper_functions/string_function');

let controllerOpnTmpl = _.template(`<?php \n defined('BASEPATH') OR exit('No direct script access allowed'); \n class <%= table_name %>_Controller extends CI_CONTROLLER {`);
let controllerCloseTmpl = _.template(`}`);
let remapStrtTmpl = _.template(`<%= outer_tab %>public function _remap($method) {`);
let remapAuthenTmpl = _.template(`<%= inner_tab %>if(!$this->authenticate_user()) {\n<%= outer_tab %><%= inner_tab %>$this->authentication_failure();\n<%= outer_tab %><%= inner_tab %>return;\n<%= inner_tab %>}`);
let remapMetExistsTmpl = _.template(`<%= inner_tab %>if(method_exists($this, $method)) {\n<%= outer_tab %><%= inner_tab %>$this->$method();\n<%= inner_tab %>} else {\n<%= outer_tab %><%= inner_tab %>$this->default_handler($method);\n<%= inner_tab %>}`);
let remapAuthoTmpl = _.template(`<%= inner_tab %>if(!$this->authorize_user($method)) {\n<%= outer_tab %><%= inner_tab %>$this->authorization_failure();\n<%= outer_tab %><%= inner_tab %>return;\n<%= inner_tab %>}`);
let remapEnd = _.template(`<%= outer_tab %>}`);
let authenticateTmpl = _.template(`<%= outer_tab %>private function authenticate_user(){return true;}`);
let authorizeTmpl = _.template(`<%= outer_tab %>private function authorize_user(){return true;}`);
let authenticateFailureTmpl = _.template(`<%= outer_tab %>private function authentication_failure(){show_404();}`);
let authorizationFailureTmpl = _.template(`<%= outer_tab %>private function authorization_failure(){show_404();}`);
let defaultHandlerTmpl = _.template(`<%= outer_tab %>private function default_handler(){show_404();}`);

let loadModelTmpl = _.template(`<%= inner_tab %>$this->load->model('<%= model_name %>');`);
let callModelMethodTmpl = _.template(`$this-><%= model_name %>-><%= method_name %>()`);
let loadModelDataTmpl = _.template(`<%= inner_tab %>$this->data['<%= value_name %>'] = $this-><%= model_name %>-><%= method_name %>();`);
let loadDataTmpl = _.template(`<%= inner_tab %>$this->data['<%= value_name %>'] = <%= data_exp %>;`);
let loadDataTwoDTmpl = _.template(`<%= inner_tab %>$this->data['<%= first_index %>']['<%= second_index %>'] = <%= data_exp %>;`);
let loadViewTmpl = _.template(`<%= inner_tab %>$this->load->view('<%= folder_name %>/<%= grid_name %>', $this->data);`);
let echoJsonTmpl = _.template(`<%= inner_tab %>echo json_encode($this-><%= model_name %>-><%= method_name %>());`);
let validationRules = _.template(`<%= inner_tab %>$this->form_validation->set_rules('<%=field_name%>', '<%=field_label%>', '<%=validation_condition%>', '<%=error_message%>');`);
let validatingTest = _.template(`$this->form_validation->run() == FALSE`);
let getValidationErr = _.template(`validation_errors()`);

let ifTemplate = _.template(`<%= inner_tab %>if(<%= if_condition %>) {`);
let elseTemplate = _.template(`<%= inner_tab %>else {`);
let blockClosing = _.template(`<%= inner_tab %>}`);

let methodOpening = _.template(`<%= outer_tab %>function <%=method_name%>() {`);
let methodClosing = _.template(`<%= outer_tab %>}`);
let postCondTmpl = _.template(`is_null($this->input->post('<%= value_variable %>')) ? '' : $this->input->post('<%= value_variable %>')`);
let postTmpl = _.template(`$this->input->post('<%= value_variable %>')`);
let getTmpl = _.template(`$this->input->get('<%= value_variable %>')`);
let unsetPostTmpl = _.template(`<%= inner_tab %>unset($_POST['<%= value_variable %>']);`)
let expVariableTmpl = _.template(`<%= inner_tab %>$<%=variable_name%> = <%= expression %>;`);
let objAccTmpl = _.template(`$<%= object_name %>-><%= property_name %>`);
let outerTab = 2;
let innerTab = 4;

// masters, records
exports.writeCIController = function (modelDef) {
  let allController = [];
  _.forEach(modelDef, (mdlDef) => {
    controller = [];
    controller.push(controllerOpnTmpl({ table_name: mdlDef.table_name }));
    controller.push(remapStrtTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(remapAuthenTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(remapAuthoTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(remapMetExistsTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(remapEnd({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(...wCreateMethod(mdlDef, modelDef));
    controller.push(...wUpdateMethod(mdlDef));
    controller.push(...wDeleteMethod(mdlDef));    
    controller.push(...wSelectMethod(mdlDef));    
    controller.push(authenticateTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(authorizeTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(authenticateFailureTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(authorizationFailureTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(defaultHandlerTmpl({ outer_tab: tabSpaces(outerTab), inner_tab: tabSpaces(innerTab) }));
    controller.push(controllerCloseTmpl({}));
    allController.push({ file_name: mdlDef.table_name + '_Controller', file_contents: _.join(controller, '\n') });
  });
  return allController;
}

function wCreateMethod(mdlDef, modelDef) {
  // load masters
  // load table data
  // validate
  let methodName = 'add_record';      // add_record
  let modelAddRecords = 'add_record';
  let modelReadRecord = 'get_record';
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: methodName }));
  if (!_.isEmpty(mdlDef.op.master.join)) {
    _.forEach(mdlDef.op.master.join, (jn) => {
      stmts.push(loadModelTmpl({ inner_tab: tabSpaces(innerTab), model_name: jn.table_one + '_model' }));
      let mTC = mdlDef.sub_form == jn.table_one ? true : false;
      if(!mTC){
        stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: jn.table_one + '_record', model_name: jn.table_one + '_model', method_name: modelReadRecord }));
      } else if(mTC) {
        stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab), first_index: 'parent_record', second_index: jn.table_one, data_exp: callModelMethodTmpl({ model_name: jn.table_one, method_name: modelReadRecord }) }))    
      }
    });
  }
  stmts.push(loadModelTmpl({ inner_tab: tabSpaces(innerTab), model_name: mdlDef.table_name + '_model' }));
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: mdlDef.table_name + '_record', model_name: mdlDef.table_name + '_model', method_name: modelReadRecord }));
  _.forEach(mdlDef.column, (cl) => {
    if (cl.required && cl.column_key != 'PRI') {
      stmts.push(validationRules({ inner_tab: tabSpaces(innerTab), field_name: cl.column_name, field_label: cl.column_label, validation_condition: 'required', error_message: ' ' }));
    }
  });
  stmts.push(ifTemplate({ inner_tab: tabSpaces(innerTab), if_condition: validatingTest({}) }));
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab + outerTab), value_name: 'error_record', data_exp: getValidationErr({}) }));
  // add the form data
  _.forEach(mdlDef.column, (col) => {
    stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab + outerTab), first_index: 'form_data', second_index: col.column_name, data_exp: postCondTmpl({ value_variable: col.column_name }) }))
  });
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab) }));
  stmts.push(elseTemplate({ inner_tab: tabSpaces(innerTab) }));
  // Add record, have a variable holding model return, add it to data
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab + outerTab), value_name: 'add_record', model_name: mdlDef.table_name + '_model', method_name: modelAddRecords }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab) }));
  // call default view grid
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: 'method_name', data_exp: "'"+methodName+"'" }));
  stmts.push(loadViewTmpl({ inner_tab: tabSpaces(innerTab), folder_name: mdlDef.table_name + '_vwcom', grid_name: 'default_grid' }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}

function wUpdateMethod(mdlDef) {
  // load masters
  // load table data
  // validate
  let methodName = 'update_record';      // add_record
  let modelUpdateRecord = 'update_record';
  let modelReadRecord = 'get_record';
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: methodName }));
  if (!_.isEmpty(mdlDef.op.master.join)) {
    _.forEach(mdlDef.op.master.join, (jn) => {
      stmts.push(loadModelTmpl({ inner_tab: tabSpaces(innerTab), model_name: jn.table_one + '_model' }));
      let mTC = mdlDef.sub_form == jn.table_one ? true : false;
      if(!mTC){
        stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: jn.table_one + '_record', model_name: jn.table_one + '_model', method_name: modelReadRecord }));
      } else if(mTC) {
        stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab), first_index: 'parent_record', second_index: jn.table_one, data_exp: callModelMethodTmpl({ model_name: jn.table_one, method_name: modelReadRecord }) }))    
      }
    });
  }
  // if update skip validation rules
  let pkey = _.filter(mdlDef.column, { column_key: 'PRI' })[0];
  stmts.push(ifTemplate({ inner_tab: tabSpaces(innerTab), if_condition: getTmpl({ value_variable: 'get_record' }) }));
  // stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab + outerTab), value_name: mdlDef.table_name + '_record', model_name: mdlDef.table_name + '_model', method_name: modelUpdateRecord }));
  stmts.push(expVariableTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), variable_name: 'update_record', expression: callModelMethodTmpl({ model_name: mdlDef.table_name, method_name: 'get_record' }) + '[0]->result' }));
  // add the form data
  _.forEach(mdlDef.column, (col) => {
    stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), first_index: 'form_data', second_index: col.column_name, data_exp: objAccTmpl({ object_name: 'update_record', property_name: col.column_name }) }));
  });
  stmts.push(unsetPostTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), value_variable: pkey.column_name }));
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), value_name: 'method_name', data_exp: "'"+methodName+"'" }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab) }));
  stmts.push(elseTemplate({ inner_tab: tabSpaces(innerTab) }));
  // end if
  _.forEach(mdlDef.column, (cl) => {
    if (cl.required) {
      stmts.push(validationRules({ inner_tab: tabSpaces(innerTab + outerTab), field_name: cl.column_name, field_label: cl.column_label, validation_condition: 'required', error_message: ' ' }));
    }
  });
  stmts.push(ifTemplate({ inner_tab: tabSpaces(innerTab + outerTab), if_condition: validatingTest({}) }));
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab + 2* outerTab), value_name: 'error_record', data_exp: getValidationErr({}) }));
  // add the form data
  _.forEach(mdlDef.column, (col) => {
    stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), first_index: 'form_data', second_index: col.column_name, data_exp: postCondTmpl({ value_variable: col.column_name }) }))
  });
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), value_name: 'method_name', data_exp: "'"+methodName+"'" }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab + outerTab) }));
  stmts.push(elseTemplate({ inner_tab: tabSpaces(innerTab + outerTab) }));
  // Add record, have a variable holding model return, add it to data
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), value_name: 'update_record', model_name: mdlDef.table_name + '_model', method_name: modelUpdateRecord }));
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab + 2 * outerTab), value_name: 'method_name', data_exp: "'add_record'" }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab + outerTab) }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab) }));
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: mdlDef.table_name + '_record', model_name: mdlDef.table_name + '_model', method_name: modelReadRecord }));
  // call default view grid
  stmts.push(loadViewTmpl({ inner_tab: tabSpaces(innerTab), folder_name: mdlDef.table_name + '_vwcom', grid_name: 'default_grid' }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}

function wDeleteMethod(mdlDef) {
  // load masters
  // load table data
  // validate
  let methodName = 'delete_record';      // add_record
  let modelDeleteRecord = 'delete_record';
  let modelReadRecord = 'get_record';
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: methodName }));
  if (!_.isEmpty(mdlDef.op.master.join)) {
    _.forEach(mdlDef.op.master.join, (jn) => {
      stmts.push(loadModelTmpl({ inner_tab: tabSpaces(innerTab), model_name: jn.table_one + '_model' }));
      let mTC = mdlDef.sub_form == jn.table_one ? true : false;
      if(!mTC){
        stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: jn.table_one + '_record', model_name: jn.table_one + '_model', method_name: modelReadRecord }));
      } else if(mTC) {
        stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab), first_index: 'parent_record', second_index: jn.table_one, data_exp: callModelMethodTmpl({ model_name: jn.table_one, method_name: modelReadRecord }) }))    
      }
    });
  }
  let pkey = _.filter(mdlDef.column, { column_key: 'PRI' })[0];
  stmts.push(validationRules({ inner_tab: tabSpaces(innerTab), field_name: pkey.column_name, field_label: pkey.column_label, validation_condition: 'required', error_message: ' ' }));
  stmts.push(ifTemplate({ inner_tab: tabSpaces(innerTab), if_condition: validatingTest({}) }));
  stmts.push(loadDataTmpl({ inner_tab: tabSpaces(innerTab + outerTab), value_name: 'error_record', data_exp: getValidationErr({}) }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab) }));
  stmts.push(elseTemplate({ inner_tab: tabSpaces(innerTab) }));
  // Add record, have a variable holding model return, add it to data
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab + outerTab), value_name: 'delete_record', model_name: mdlDef.table_name + '_model', method_name: modelDeleteRecord }));
  stmts.push(blockClosing({ inner_tab: tabSpaces(innerTab) }));
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: mdlDef.table_name + '_record', model_name: mdlDef.table_name + '_model', method_name: modelReadRecord }));
  stmts.push(loadViewTmpl({ inner_tab: tabSpaces(innerTab), folder_name: mdlDef.table_name + '_vwcom', grid_name: 'default_grid' }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}

function wSelectMethod(mdlDef) {
  // load masters
  // load table data
  // validate
  let methodName = 'get_record';      // add_record
  let modelDeleteRecord = 'get_record';
  let modelReadRecord = 'get_record';
  let stmts = [];
  stmts.push(methodOpening({ outer_tab: tabSpaces(outerTab), method_name: methodName }));
  if (!_.isEmpty(mdlDef.op.master.join)) {
    _.forEach(mdlDef.op.master.join, (jn) => {
      stmts.push(loadModelTmpl({ inner_tab: tabSpaces(innerTab), model_name: jn.table_one + '_model' }));
      let mTC = mdlDef.sub_form == jn.table_one ? true : false;
      if(!mTC){
        stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: jn.table_one + '_record', model_name: jn.table_one + '_model', method_name: modelReadRecord }));
      } else if(mTC) {
        stmts.push(loadDataTwoDTmpl({ inner_tab: tabSpaces(innerTab), first_index: 'parent_record', second_index: jn.table_one, data_exp: callModelMethodTmpl({ model_name: jn.table_one, method_name: modelReadRecord }) }))    
      }
    });
  }
  stmts.push(loadModelDataTmpl({ inner_tab: tabSpaces(innerTab), value_name: mdlDef.table_name + '_record', model_name: mdlDef.table_name + '_model', method_name: modelReadRecord }));
  stmts.push(loadViewTmpl({ inner_tab: tabSpaces(innerTab), folder_name: mdlDef.table_name + '_vwcom', grid_name: 'default_grid' }));
  stmts.push(methodClosing({ outer_tab: tabSpaces(outerTab) }));
  return stmts;
}