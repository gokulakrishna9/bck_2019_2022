let _ = require('lodash');

// form elements
// BUILD THE ENTIRE DATA STRUCTURE THEN PASS TO TEMPLATE
let input = _.template(`<%= outer_tab %><input class="<%= class_list %>" <%= property %>">`);
let label = _.template(`<%= outer_tab %><label class="<%= class_list %>" <%= property %>><%= field_label %></label>`);
let selectStart = _.template(`<%= outer_tab %><select class="<%= class_list %>" <%= property %>>`);
let phpOptions = _.template(`<%= outer_tab %><%= option_loop_start %>`);
let defaultOption = _.template(`<%= outer_tab %><%= inner_tab %><option class="<%= class_list %>" value="" disabled selected>Choose your option</option>`);
let option = _.template(`<%= outer_tab %><%= inner_tab %><option class="<%= class_list %>" <%= property %>><%= option_label %></option>`);
let optionEnd = _.template(`<%= outer_tab %><%= option_loop_end %>`);
let selectEnd = _.template(`<%= outer_tab %></select>`);
let textArea = _.template(`<%= outer_tab %><textarea class="<%= class_list %>" ><%= field_value %></textarea>`);
let formOpen = _.template(`<%= outer_tab %><form class="<%= class_list %>" <%= property %>>`);
let formClose = _.template(`<%= outer_tab %></form>`);
let rowStart = _.template(`<%= outer_tab %><div class='w3-row w3-margin-bottom'>`);
let outerDiv = _.template(`<%= outer_tab %></div>`);
let colStart = _.template(`<%= outer_tab %><div class='w3-col w3-mobile s12 m4 l4 w3-padding-small'>`);
let innerDiv = _.template(`<%= outer_tab %><%= inner_tab %></div>`);
// class="w3-input w3-border w3-round w3-pale-green"
// class="w3-check", class="w3-radio", class="w3-select w3-border"
// class = "w3-row w3-margin-bottom"
// class = "w3-col w3-mobile s12 m4 l4 w3-padding-small"
// Will have to manually change the view
// <-- NOT MUCH CAN BE DONE WITH CURRENT SKILL LEVEL {{REACT & REDUX, Screen Size Change}} -->
let gridSize = 3;
exports.formGrid = function (viewSc, innerTab, outerTab) {
  // check for class property in the viewSc
  // viewSc.form.form_element{label: col.column_label, column_name: col.column_name, column_size: col.column_size, html_element: '',  validation_message: '', 
  // js_event: [], js_op: [], php_op: [], js_component: '', sort_order: sort, grid_column_class: '', property: { html: [{ id: col.column_name }] }, 
  // value: { table_name: '', value_column: '', label_column: ''}, acl_op: [], active: true}
  let formEle = [];
  let formClass = _.filter(viewSc.form.form_property, { property_name: 'class' });
  formClass = _.trim(_.map(formClass, (cl) => { return cl.property_value + ' ' }), ' ');
  let prp = _.reject(viewSc.form.form_property, { property_name: 'class' });
  prp = _.map(prp, (p) => { return p.property_name + '=' + p.property_value });
  formEle.push(formOpen({ outer_tab: outerTab, inner_tab: innerTab, class_list: _.trim('w3-container ' + formClass), property: prp }));
  viewSc.form.form_element.sort(function (e1, e2) {
    return e1.sort_order - e2.sort_order;
  });
  let elemLen = viewSc.form.form_element.length;
  _.forEach(viewSc.form.form_element, (ele, count) => {
    if (count % gridSize == 0) {
      // grid open
      formEle.push(rowStart({ outer_tab: outerTab, inner_tab: innerTab }));
    }
    formEle.push(colStart({ outer_tab: outerTab, inner_tab: innerTab }));
    // add label
    let properties = _.join(_.map(_.reject(ele.property.html, { property_name: 'class' }), (prop) => { return prop.property_name + '=' + prop.property_value }), ' ');
    if (ele.html_element == 'input') {
      let classList = _.map(_.filter(ele.property.html, { property_name: 'class' }), (prop) => { return prop.property_value; });
      if (_.filter(ele.property.html, { property_name: 'type', property_value: 'checkbox' })) {
        let themeClasses = 'w3-check';
        classList = _.join(classList.push(themeClasses), ' ');
        formEle.push(input({ outer_tab: outerTab, inner_tab: innerTab, class_list: classList, property: properties }));
        formEle.push(label({ outer_tab: outerTab, inner_tab: innerTab, class_list: '', property: "for='" + ele.column_name + "'" }));
      } else if (_.filter(ele.property.html, { property_name: 'type', property_value: 'radio' })) {
        let themeClasses = 'w3-radio';
        classList = _.join(classList.push(themeClasses), ' ');
        formEle.push(input({ outer_tab: outerTab, inner_tab: innerTab, class_list: classList, property: properties }));
        formEle.push(label({ outer_tab: outerTab, inner_tab: innerTab, class_list: '', property: "for='" + ele.column_name + "'" }));
      } else {
        let themeClasses = 'w3-input w3-border w3-round w3-pale-green';
        classList = _.join(classList.push(themeClasses), ' ');
        formEle.push(label({ outer_tab: outerTab, inner_tab: innerTab, class_list: '', property: "for='" + ele.column_name + "'" }));
        formEle.push(input({ outer_tab: outerTab, inner_tab: innerTab, class_list: classList, property: properties }));
      }
    } else if (ele.html_element == 'textarea') {
      let themeClasses = 'w3-input w3-border w3-round w3-pale-green';
      let classList = _.join(classList.push(themeClasses), ' ');
      formEle.push(label({ outer_tab: outerTab, inner_tab: innerTab, class_list: '', property: "for='" + ele.column_name + "'" }));
      formEle.push(textArea({ outer_tab: outerTab, inner_tab: innerTab, class_list: classList, property: properties }));
    } else if (ele.html_element == 'select') {
      let themeClasses = 'w3-input w3-border w3-round w3-pale-green';
      let classList = _.join(classList.push(themeClasses), ' ');
      formEle.push(label({ outer_tab: outerTab, inner_tab: innerTab, class_list: '', property: "for='" + ele.column_name + "'" }));
      formEle.push(selectStart({ outer_tab: outerTab, inner_tab: innerTab, class_list: classList, property: properties }));
      formEle.push(defaultOption({ outer_tab: outerTab, inner_tab: innerTab, class_list: ' ' }))
      formEle.push(phpOptions({ outer_tab: outerTab, option_loop_start: ele.option_loop_start }));
      formEle.push(option({ outer_tab: outerTab, inner_tab: innerTab, class_list: ' ', property: properties, option_label: ele.option_label }));
      formEle.push(optionEnd({ outer_tab: outerTab, inner_tab: innerTab }));
      formEle.push(selectEnd({ outer_tab: outerTab, inner_tab: innerTab }));
    }
    formEle.push(innerDiv({ outer_tab: outerTab, inner_tab: innerTab }));
    // add element
    if (count == elemLen - 1 || ((count + 1) % gridSize) == 0) {
      // close grid
      formEle.push(outerDiv({ outer_tab: outerTab, inner_tab: innerTab }));
    }
  });
  formEle.push(formClose({ inner_tab: innerTab, outer_tab: outerTab }));
}