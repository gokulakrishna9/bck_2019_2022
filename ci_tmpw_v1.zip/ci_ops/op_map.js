exports.getOps = function () {
  return [
    {
      op_name: 'write_ci_scaffold',
      op_file: './ci_ops/ci_scaffold',
      op_method: 'ciScaffold',
      help_text: 'Takes app_name, theme properties'
    },
    {
      op_name: 'write_ci',
      op_file: './ci_ops/ci_main',
      op_method: 'ciMain',
      help_text: 'Takes app_name'
    }
  ]
}